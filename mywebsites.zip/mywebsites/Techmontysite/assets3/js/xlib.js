(function(e, t) {
    function _(e) {
        var t = M[e] = {};
        return v.each(e.split(y), function(e, n) {
            t[n] = !0
        }),
        t
    }
    function H(e, n, r) {
        if (r === t && e.nodeType === 1) {
            var i = "data-" + n.replace(P, "-$1").toLowerCase();
            r = e.getAttribute(i);
            if (typeof r == "string") {
                try {
                    r = r === "true" ? !0 : r === "false" ? !1 : r === "null" ? null : +r + "" === r ? +r : D.test(r) ? v.parseJSON(r) : r
                } catch (s) {}
                v.data(e, n, r)
            } else
                r = t
        }
        return r
    }
    function B(e) {
        var t;
        for (t in e) {
            if (t === "data" && v.isEmptyObject(e[t]))
                continue;
            if (t !== "toJSON")
                return !1
        }
        return !0
    }
    function et() {
        return !1
    }
    function tt() {
        return !0
    }
    function ut(e) {
        return !e || !e.parentNode || e.parentNode.nodeType === 11
    }
    function at(e, t) {
        do
            e = e[t];
        while (e && e.nodeType !== 1);
        return e
    }
    function ft(e, t, n) {
        t = t || 0;
        if (v.isFunction(t))
            return v.grep(e, function(e, r) {
                var i = !!t.call(e, r, e);
                return i === n
            });
        if (t.nodeType)
            return v.grep(e, function(e, r) {
                return e === t === n
            });
        if (typeof t == "string") {
            var r = v.grep(e, function(e) {
                return e.nodeType === 1
            });
            if (it.test(t))
                return v.filter(t, r, !n);
            t = v.filter(t, r)
        }
        return v.grep(e, function(e, r) {
            return v.inArray(e, t) >= 0 === n
        })
    }
    function lt(e) {
        var t = ct.split("|")
          , n = e.createDocumentFragment();
        if (n.createElement)
            while (t.length)
                n.createElement(t.pop());
        return n
    }
    function Lt(e, t) {
        return e.getElementsByTagName(t)[0] || e.appendChild(e.ownerDocument.createElement(t))
    }
    function At(e, t) {
        if (t.nodeType !== 1 || !v.hasData(e))
            return;
        var n, r, i, s = v._data(e), o = v._data(t, s), u = s.events;
        if (u) {
            delete o.handle,
            o.events = {};
            for (n in u)
                for (r = 0,
                i = u[n].length; r < i; r++)
                    v.event.add(t, n, u[n][r])
        }
        o.data && (o.data = v.extend({}, o.data))
    }
    function Ot(e, t) {
        var n;
        if (t.nodeType !== 1)
            return;
        t.clearAttributes && t.clearAttributes(),
        t.mergeAttributes && t.mergeAttributes(e),
        n = t.nodeName.toLowerCase(),
        n === "object" ? (t.parentNode && (t.outerHTML = e.outerHTML),
        v.support.html5Clone && e.innerHTML && !v.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : n === "input" && Et.test(e.type) ? (t.defaultChecked = t.checked = e.checked,
        t.value !== e.value && (t.value = e.value)) : n === "option" ? t.selected = e.defaultSelected : n === "input" || n === "textarea" ? t.defaultValue = e.defaultValue : n === "script" && t.text !== e.text && (t.text = e.text),
        t.removeAttribute(v.expando)
    }
    function Mt(e) {
        return typeof e.getElementsByTagName != "undefined" ? e.getElementsByTagName("*") : typeof e.querySelectorAll != "undefined" ? e.querySelectorAll("*") : []
    }
    function _t(e) {
        Et.test(e.type) && (e.defaultChecked = e.checked)
    }
    function Qt(e, t) {
        if (t in e)
            return t;
        var n = t.charAt(0).toUpperCase() + t.slice(1)
          , r = t
          , i = Jt.length;
        while (i--) {
            t = Jt[i] + n;
            if (t in e)
                return t
        }
        return r
    }
    function Gt(e, t) {
        return e = t || e,
        v.css(e, "display") === "none" || !v.contains(e.ownerDocument, e)
    }
    function Yt(e, t) {
        var n, r, i = [], s = 0, o = e.length;
        for (; s < o; s++) {
            n = e[s];
            if (!n.style)
                continue;
            i[s] = v._data(n, "olddisplay"),
            t ? (!i[s] && n.style.display === "none" && (n.style.display = ""),
            n.style.display === "" && Gt(n) && (i[s] = v._data(n, "olddisplay", nn(n.nodeName)))) : (r = Dt(n, "display"),
            !i[s] && r !== "none" && v._data(n, "olddisplay", r))
        }
        for (s = 0; s < o; s++) {
            n = e[s];
            if (!n.style)
                continue;
            if (!t || n.style.display === "none" || n.style.display === "")
                n.style.display = t ? i[s] || "" : "none"
        }
        return e
    }
    function Zt(e, t, n) {
        var r = Rt.exec(t);
        return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
    }
    function en(e, t, n, r) {
        var i = n === (r ? "border" : "content") ? 4 : t === "width" ? 1 : 0
          , s = 0;
        for (; i < 4; i += 2)
            n === "margin" && (s += v.css(e, n + $t[i], !0)),
            r ? (n === "content" && (s -= parseFloat(Dt(e, "padding" + $t[i])) || 0),
            n !== "margin" && (s -= parseFloat(Dt(e, "border" + $t[i] + "Width")) || 0)) : (s += parseFloat(Dt(e, "padding" + $t[i])) || 0,
            n !== "padding" && (s += parseFloat(Dt(e, "border" + $t[i] + "Width")) || 0));
        return s
    }
    function tn(e, t, n) {
        var r = t === "width" ? e.offsetWidth : e.offsetHeight
          , i = !0
          , s = v.support.boxSizing && v.css(e, "boxSizing") === "border-box";
        if (r <= 0 || r == null) {
            r = Dt(e, t);
            if (r < 0 || r == null)
                r = e.style[t];
            if (Ut.test(r))
                return r;
            i = s && (v.support.boxSizingReliable || r === e.style[t]),
            r = parseFloat(r) || 0
        }
        return r + en(e, t, n || (s ? "border" : "content"), i) + "px"
    }
    function nn(e) {
        if (Wt[e])
            return Wt[e];
        var t = v("<" + e + ">").appendTo(i.body)
          , n = t.css("display");
        t.remove();
        if (n === "none" || n === "") {
            Pt = i.body.appendChild(Pt || v.extend(i.createElement("iframe"), {
                frameBorder: 0,
                width: 0,
                height: 0
            }));
            if (!Ht || !Pt.createElement)
                Ht = (Pt.contentWindow || Pt.contentDocument).document,
                Ht.write("<!doctype html><html><body>"),
                Ht.close();
            t = Ht.body.appendChild(Ht.createElement(e)),
            n = Dt(t, "display"),
            i.body.removeChild(Pt)
        }
        return Wt[e] = n,
        n
    }
    function fn(e, t, n, r) {
        var i;
        if (v.isArray(t))
            v.each(t, function(t, i) {
                n || sn.test(e) ? r(e, i) : fn(e + "[" + (typeof i == "object" ? t : "") + "]", i, n, r)
            });
        else if (!n && v.type(t) === "object")
            for (i in t)
                fn(e + "[" + i + "]", t[i], n, r);
        else
            r(e, t)
    }
    function Cn(e) {
        return function(t, n) {
            typeof t != "string" && (n = t,
            t = "*");
            var r, i, s, o = t.toLowerCase().split(y), u = 0, a = o.length;
            if (v.isFunction(n))
                for (; u < a; u++)
                    r = o[u],
                    s = /^\+/.test(r),
                    s && (r = r.substr(1) || "*"),
                    i = e[r] = e[r] || [],
                    i[s ? "unshift" : "push"](n)
        }
    }
    function kn(e, n, r, i, s, o) {
        s = s || n.dataTypes[0],
        o = o || {},
        o[s] = !0;
        var u, a = e[s], f = 0, l = a ? a.length : 0, c = e === Sn;
        for (; f < l && (c || !u); f++)
            u = a[f](n, r, i),
            typeof u == "string" && (!c || o[u] ? u = t : (n.dataTypes.unshift(u),
            u = kn(e, n, r, i, u, o)));
        return (c || !u) && !o["*"] && (u = kn(e, n, r, i, "*", o)),
        u
    }
    function Ln(e, n) {
        var r, i, s = v.ajaxSettings.flatOptions || {};
        for (r in n)
            n[r] !== t && ((s[r] ? e : i || (i = {}))[r] = n[r]);
        i && v.extend(!0, e, i)
    }
    function An(e, n, r) {
        var i, s, o, u, a = e.contents, f = e.dataTypes, l = e.responseFields;
        for (s in l)
            s in r && (n[l[s]] = r[s]);
        while (f[0] === "*")
            f.shift(),
            i === t && (i = e.mimeType || n.getResponseHeader("content-type"));
        if (i)
            for (s in a)
                if (a[s] && a[s].test(i)) {
                    f.unshift(s);
                    break
                }
        if (f[0]in r)
            o = f[0];
        else {
            for (s in r) {
                if (!f[0] || e.converters[s + " " + f[0]]) {
                    o = s;
                    break
                }
                u || (u = s)
            }
            o = o || u
        }
        if (o)
            return o !== f[0] && f.unshift(o),
            r[o]
    }
    function On(e, t) {
        var n, r, i, s, o = e.dataTypes.slice(), u = o[0], a = {}, f = 0;
        e.dataFilter && (t = e.dataFilter(t, e.dataType));
        if (o[1])
            for (n in e.converters)
                a[n.toLowerCase()] = e.converters[n];
        for (; i = o[++f]; )
            if (i !== "*") {
                if (u !== "*" && u !== i) {
                    n = a[u + " " + i] || a["* " + i];
                    if (!n)
                        for (r in a) {
                            s = r.split(" ");
                            if (s[1] === i) {
                                n = a[u + " " + s[0]] || a["* " + s[0]];
                                if (n) {
                                    n === !0 ? n = a[r] : a[r] !== !0 && (i = s[0],
                                    o.splice(f--, 0, i));
                                    break
                                }
                            }
                        }
                    if (n !== !0)
                        if (n && e["throws"])
                            t = n(t);
                        else
                            try {
                                t = n(t)
                            } catch (l) {
                                return {
                                    state: "parsererror",
                                    error: n ? l : "No conversion from " + u + " to " + i
                                }
                            }
                }
                u = i
            }
        return {
            state: "success",
            data: t
        }
    }
    function Fn() {
        try {
            return new e.XMLHttpRequest
        } catch (t) {}
    }
    function In() {
        try {
            return new e.ActiveXObject("Microsoft.XMLHTTP")
        } catch (t) {}
    }
    function $n() {
        return setTimeout(function() {
            qn = t
        }, 0),
        qn = v.now()
    }
    function Jn(e, t) {
        v.each(t, function(t, n) {
            var r = (Vn[t] || []).concat(Vn["*"])
              , i = 0
              , s = r.length;
            for (; i < s; i++)
                if (r[i].call(e, t, n))
                    return
        })
    }
    function Kn(e, t, n) {
        var r, i = 0, s = 0, o = Xn.length, u = v.Deferred().always(function() {
            delete a.elem
        }), a = function() {
            var t = qn || $n()
              , n = Math.max(0, f.startTime + f.duration - t)
              , r = n / f.duration || 0
              , i = 1 - r
              , s = 0
              , o = f.tweens.length;
            for (; s < o; s++)
                f.tweens[s].run(i);
            return u.notifyWith(e, [f, i, n]),
            i < 1 && o ? n : (u.resolveWith(e, [f]),
            !1)
        }, f = u.promise({
            elem: e,
            props: v.extend({}, t),
            opts: v.extend(!0, {
                specialEasing: {}
            }, n),
            originalProperties: t,
            originalOptions: n,
            startTime: qn || $n(),
            duration: n.duration,
            tweens: [],
            createTween: function(t, n, r) {
                var i = v.Tween(e, f.opts, t, n, f.opts.specialEasing[t] || f.opts.easing);
                return f.tweens.push(i),
                i
            },
            stop: function(t) {
                var n = 0
                  , r = t ? f.tweens.length : 0;
                for (; n < r; n++)
                    f.tweens[n].run(1);
                return t ? u.resolveWith(e, [f, t]) : u.rejectWith(e, [f, t]),
                this
            }
        }), l = f.props;
        Qn(l, f.opts.specialEasing);
        for (; i < o; i++) {
            r = Xn[i].call(f, e, l, f.opts);
            if (r)
                return r
        }
        return Jn(f, l),
        v.isFunction(f.opts.start) && f.opts.start.call(e, f),
        v.fx.timer(v.extend(a, {
            anim: f,
            queue: f.opts.queue,
            elem: e
        })),
        f.progress(f.opts.progress).done(f.opts.done, f.opts.complete).fail(f.opts.fail).always(f.opts.always)
    }
    function Qn(e, t) {
        var n, r, i, s, o;
        for (n in e) {
            r = v.camelCase(n),
            i = t[r],
            s = e[n],
            v.isArray(s) && (i = s[1],
            s = e[n] = s[0]),
            n !== r && (e[r] = s,
            delete e[n]),
            o = v.cssHooks[r];
            if (o && "expand"in o) {
                s = o.expand(s),
                delete e[r];
                for (n in s)
                    n in e || (e[n] = s[n],
                    t[n] = i)
            } else
                t[r] = i
        }
    }
    function Gn(e, t, n) {
        var r, i, s, o, u, a, f, l, c, h = this, p = e.style, d = {}, m = [], g = e.nodeType && Gt(e);
        n.queue || (l = v._queueHooks(e, "fx"),
        l.unqueued == null && (l.unqueued = 0,
        c = l.empty.fire,
        l.empty.fire = function() {
            l.unqueued || c()
        }
        ),
        l.unqueued++,
        h.always(function() {
            h.always(function() {
                l.unqueued--,
                v.queue(e, "fx").length || l.empty.fire()
            })
        })),
        e.nodeType === 1 && ("height"in t || "width"in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY],
        v.css(e, "display") === "inline" && v.css(e, "float") === "none" && (!v.support.inlineBlockNeedsLayout || nn(e.nodeName) === "inline" ? p.display = "inline-block" : p.zoom = 1)),
        n.overflow && (p.overflow = "hidden",
        v.support.shrinkWrapBlocks || h.done(function() {
            p.overflow = n.overflow[0],
            p.overflowX = n.overflow[1],
            p.overflowY = n.overflow[2]
        }));
        for (r in t) {
            s = t[r];
            if (Un.exec(s)) {
                delete t[r],
                a = a || s === "toggle";
                if (s === (g ? "hide" : "show"))
                    continue;
                m.push(r)
            }
        }
        o = m.length;
        if (o) {
            u = v._data(e, "fxshow") || v._data(e, "fxshow", {}),
            "hidden"in u && (g = u.hidden),
            a && (u.hidden = !g),
            g ? v(e).show() : h.done(function() {
                v(e).hide()
            }),
            h.done(function() {
                var t;
                v.removeData(e, "fxshow", !0);
                for (t in d)
                    v.style(e, t, d[t])
            });
            for (r = 0; r < o; r++)
                i = m[r],
                f = h.createTween(i, g ? u[i] : 0),
                d[i] = u[i] || v.style(e, i),
                i in u || (u[i] = f.start,
                g && (f.end = f.start,
                f.start = i === "width" || i === "height" ? 1 : 0))
        }
    }
    function Yn(e, t, n, r, i) {
        return new Yn.prototype.init(e,t,n,r,i)
    }
    function Zn(e, t) {
        var n, r = {
            height: e
        }, i = 0;
        t = t ? 1 : 0;
        for (; i < 4; i += 2 - t)
            n = $t[i],
            r["margin" + n] = r["padding" + n] = e;
        return t && (r.opacity = r.width = e),
        r
    }
    function tr(e) {
        return v.isWindow(e) ? e : e.nodeType === 9 ? e.defaultView || e.parentWindow : !1
    }
    var n, r, i = e.document, s = e.location, o = e.navigator, u = e.jQuery, a = e.$, f = Array.prototype.push, l = Array.prototype.slice, c = Array.prototype.indexOf, h = Object.prototype.toString, p = Object.prototype.hasOwnProperty, d = String.prototype.trim, v = function(e, t) {
        return new v.fn.init(e,t,n)
    }, m = /[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source, g = /\S/, y = /\s+/, b = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, w = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/, E = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, S = /^[\],:{}\s]*$/, x = /(?:^|:|,)(?:\s*\[)+/g, T = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g, N = /"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g, C = /^-ms-/, k = /-([\da-z])/gi, L = function(e, t) {
        return (t + "").toUpperCase()
    }, A = function() {
        i.addEventListener ? (i.removeEventListener("DOMContentLoaded", A, !1),
        v.ready()) : i.readyState === "complete" && (i.detachEvent("onreadystatechange", A),
        v.ready())
    }, O = {};
    v.fn = v.prototype = {
        constructor: v,
        init: function(e, n, r) {
            var s, o, u, a;
            if (!e)
                return this;
            if (e.nodeType)
                return this.context = this[0] = e,
                this.length = 1,
                this;
            if (typeof e == "string") {
                e.charAt(0) === "<" && e.charAt(e.length - 1) === ">" && e.length >= 3 ? s = [null, e, null] : s = w.exec(e);
                if (s && (s[1] || !n)) {
                    if (s[1])
                        return n = n instanceof v ? n[0] : n,
                        a = n && n.nodeType ? n.ownerDocument || n : i,
                        e = v.parseHTML(s[1], a, !0),
                        E.test(s[1]) && v.isPlainObject(n) && this.attr.call(e, n, !0),
                        v.merge(this, e);
                    o = i.getElementById(s[2]);
                    if (o && o.parentNode) {
                        if (o.id !== s[2])
                            return r.find(e);
                        this.length = 1,
                        this[0] = o
                    }
                    return this.context = i,
                    this.selector = e,
                    this
                }
                return !n || n.jquery ? (n || r).find(e) : this.constructor(n).find(e)
            }
            return v.isFunction(e) ? r.ready(e) : (e.selector !== t && (this.selector = e.selector,
            this.context = e.context),
            v.makeArray(e, this))
        },
        selector: "",
        jquery: "1.8.3",
        length: 0,
        size: function() {
            return this.length
        },
        toArray: function() {
            return l.call(this)
        },
        get: function(e) {
            return e == null ? this.toArray() : e < 0 ? this[this.length + e] : this[e]
        },
        pushStack: function(e, t, n) {
            var r = v.merge(this.constructor(), e);
            return r.prevObject = this,
            r.context = this.context,
            t === "find" ? r.selector = this.selector + (this.selector ? " " : "") + n : t && (r.selector = this.selector + "." + t + "(" + n + ")"),
            r
        },
        each: function(e, t) {
            return v.each(this, e, t)
        },
        ready: function(e) {
            return v.ready.promise().done(e),
            this
        },
        eq: function(e) {
            return e = +e,
            e === -1 ? this.slice(e) : this.slice(e, e + 1)
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        slice: function() {
            return this.pushStack(l.apply(this, arguments), "slice", l.call(arguments).join(","))
        },
        map: function(e) {
            return this.pushStack(v.map(this, function(t, n) {
                return e.call(t, n, t)
            }))
        },
        end: function() {
            return this.prevObject || this.constructor(null)
        },
        push: f,
        sort: [].sort,
        splice: [].splice
    },
    v.fn.init.prototype = v.fn,
    v.extend = v.fn.extend = function() {
        var e, n, r, i, s, o, u = arguments[0] || {}, a = 1, f = arguments.length, l = !1;
        typeof u == "boolean" && (l = u,
        u = arguments[1] || {},
        a = 2),
        typeof u != "object" && !v.isFunction(u) && (u = {}),
        f === a && (u = this,
        --a);
        for (; a < f; a++)
            if ((e = arguments[a]) != null)
                for (n in e) {
                    r = u[n],
                    i = e[n];
                    if (u === i)
                        continue;
                    l && i && (v.isPlainObject(i) || (s = v.isArray(i))) ? (s ? (s = !1,
                    o = r && v.isArray(r) ? r : []) : o = r && v.isPlainObject(r) ? r : {},
                    u[n] = v.extend(l, o, i)) : i !== t && (u[n] = i)
                }
        return u
    }
    ,
    v.extend({
        noConflict: function(t) {
            return e.$ === v && (e.$ = a),
            t && e.jQuery === v && (e.jQuery = u),
            v
        },
        isReady: !1,
        readyWait: 1,
        holdReady: function(e) {
            e ? v.readyWait++ : v.ready(!0)
        },
        ready: function(e) {
            if (e === !0 ? --v.readyWait : v.isReady)
                return;
            if (!i.body)
                return setTimeout(v.ready, 1);
            v.isReady = !0;
            if (e !== !0 && --v.readyWait > 0)
                return;
            r.resolveWith(i, [v]),
            v.fn.trigger && v(i).trigger("ready").off("ready")
        },
        isFunction: function(e) {
            return v.type(e) === "function"
        },
        isArray: Array.isArray || function(e) {
            return v.type(e) === "array"
        }
        ,
        isWindow: function(e) {
            return e != null && e == e.window
        },
        isNumeric: function(e) {
            return !isNaN(parseFloat(e)) && isFinite(e)
        },
        type: function(e) {
            return e == null ? String(e) : O[h.call(e)] || "object"
        },
        isPlainObject: function(e) {
            if (!e || v.type(e) !== "object" || e.nodeType || v.isWindow(e))
                return !1;
            try {
                if (e.constructor && !p.call(e, "constructor") && !p.call(e.constructor.prototype, "isPrototypeOf"))
                    return !1
            } catch (n) {
                return !1
            }
            var r;
            for (r in e)
                ;
            return r === t || p.call(e, r)
        },
        isEmptyObject: function(e) {
            var t;
            for (t in e)
                return !1;
            return !0
        },
        error: function(e) {
            throw new Error(e)
        },
        parseHTML: function(e, t, n) {
            var r;
            return !e || typeof e != "string" ? null : (typeof t == "boolean" && (n = t,
            t = 0),
            t = t || i,
            (r = E.exec(e)) ? [t.createElement(r[1])] : (r = v.buildFragment([e], t, n ? null : []),
            v.merge([], (r.cacheable ? v.clone(r.fragment) : r.fragment).childNodes)))
        },
        parseJSON: function(t) {
            if (!t || typeof t != "string")
                return null;
            t = v.trim(t);
            if (e.JSON && e.JSON.parse)
                return e.JSON.parse(t);
            if (S.test(t.replace(T, "@").replace(N, "]").replace(x, "")))
                return (new Function("return " + t))();
            v.error("Invalid JSON: " + t)
        },
        parseXML: function(n) {
            var r, i;
            if (!n || typeof n != "string")
                return null;
            try {
                e.DOMParser ? (i = new DOMParser,
                r = i.parseFromString(n, "text/xml")) : (r = new ActiveXObject("Microsoft.XMLDOM"),
                r.async = "false",
                r.loadXML(n))
            } catch (s) {
                r = t
            }
            return (!r || !r.documentElement || r.getElementsByTagName("parsererror").length) && v.error("Invalid XML: " + n),
            r
        },
        noop: function() {},
        globalEval: function(t) {
            t && g.test(t) && (e.execScript || function(t) {
                e.eval.call(e, t)
            }
            )(t)
        },
        camelCase: function(e) {
            return e.replace(C, "ms-").replace(k, L)
        },
        nodeName: function(e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        },
        each: function(e, n, r) {
            var i, s = 0, o = e.length, u = o === t || v.isFunction(e);
            if (r) {
                if (u) {
                    for (i in e)
                        if (n.apply(e[i], r) === !1)
                            break
                } else
                    for (; s < o; )
                        if (n.apply(e[s++], r) === !1)
                            break
            } else if (u) {
                for (i in e)
                    if (n.call(e[i], i, e[i]) === !1)
                        break
            } else
                for (; s < o; )
                    if (n.call(e[s], s, e[s++]) === !1)
                        break;
            return e
        },
        trim: d && !d.call("\ufeff\u00a0") ? function(e) {
            return e == null ? "" : d.call(e)
        }
        : function(e) {
            return e == null ? "" : (e + "").replace(b, "")
        }
        ,
        makeArray: function(e, t) {
            var n, r = t || [];
            return e != null && (n = v.type(e),
            e.length == null || n === "string" || n === "function" || n === "regexp" || v.isWindow(e) ? f.call(r, e) : v.merge(r, e)),
            r
        },
        inArray: function(e, t, n) {
            var r;
            if (t) {
                if (c)
                    return c.call(t, e, n);
                r = t.length,
                n = n ? n < 0 ? Math.max(0, r + n) : n : 0;
                for (; n < r; n++)
                    if (n in t && t[n] === e)
                        return n
            }
            return -1
        },
        merge: function(e, n) {
            var r = n.length
              , i = e.length
              , s = 0;
            if (typeof r == "number")
                for (; s < r; s++)
                    e[i++] = n[s];
            else
                while (n[s] !== t)
                    e[i++] = n[s++];
            return e.length = i,
            e
        },
        grep: function(e, t, n) {
            var r, i = [], s = 0, o = e.length;
            n = !!n;
            for (; s < o; s++)
                r = !!t(e[s], s),
                n !== r && i.push(e[s]);
            return i
        },
        map: function(e, n, r) {
            var i, s, o = [], u = 0, a = e.length, f = e instanceof v || a !== t && typeof a == "number" && (a > 0 && e[0] && e[a - 1] || a === 0 || v.isArray(e));
            if (f)
                for (; u < a; u++)
                    i = n(e[u], u, r),
                    i != null && (o[o.length] = i);
            else
                for (s in e)
                    i = n(e[s], s, r),
                    i != null && (o[o.length] = i);
            return o.concat.apply([], o)
        },
        guid: 1,
        proxy: function(e, n) {
            var r, i, s;
            return typeof n == "string" && (r = e[n],
            n = e,
            e = r),
            v.isFunction(e) ? (i = l.call(arguments, 2),
            s = function() {
                return e.apply(n, i.concat(l.call(arguments)))
            }
            ,
            s.guid = e.guid = e.guid || v.guid++,
            s) : t
        },
        access: function(e, n, r, i, s, o, u) {
            var a, f = r == null, l = 0, c = e.length;
            if (r && typeof r == "object") {
                for (l in r)
                    v.access(e, n, l, r[l], 1, o, i);
                s = 1
            } else if (i !== t) {
                a = u === t && v.isFunction(i),
                f && (a ? (a = n,
                n = function(e, t, n) {
                    return a.call(v(e), n)
                }
                ) : (n.call(e, i),
                n = null));
                if (n)
                    for (; l < c; l++)
                        n(e[l], r, a ? i.call(e[l], l, n(e[l], r)) : i, u);
                s = 1
            }
            return s ? e : f ? n.call(e) : c ? n(e[0], r) : o
        },
        now: function() {
            return (new Date).getTime()
        }
    }),
    v.ready.promise = function(t) {
        if (!r) {
            r = v.Deferred();
            if (i.readyState === "complete")
                setTimeout(v.ready, 1);
            else if (i.addEventListener)
                i.addEventListener("DOMContentLoaded", A, !1),
                e.addEventListener("load", v.ready, !1);
            else {
                i.attachEvent("onreadystatechange", A),
                e.attachEvent("onload", v.ready);
                var n = !1;
                try {
                    n = e.frameElement == null && i.documentElement
                } catch (s) {}
                n && n.doScroll && function o() {
                    if (!v.isReady) {
                        try {
                            n.doScroll("left")
                        } catch (e) {
                            return setTimeout(o, 50)
                        }
                        v.ready()
                    }
                }()
            }
        }
        return r.promise(t)
    }
    ,
    v.each("Boolean Number String Function Array Date RegExp Object".split(" "), function(e, t) {
        O["[object " + t + "]"] = t.toLowerCase()
    }),
    n = v(i);
    var M = {};
    v.Callbacks = function(e) {
        e = typeof e == "string" ? M[e] || _(e) : v.extend({}, e);
        var n, r, i, s, o, u, a = [], f = !e.once && [], l = function(t) {
            n = e.memory && t,
            r = !0,
            u = s || 0,
            s = 0,
            o = a.length,
            i = !0;
            for (; a && u < o; u++)
                if (a[u].apply(t[0], t[1]) === !1 && e.stopOnFalse) {
                    n = !1;
                    break
                }
            i = !1,
            a && (f ? f.length && l(f.shift()) : n ? a = [] : c.disable())
        }, c = {
            add: function() {
                if (a) {
                    var t = a.length;
                    (function r(t) {
                        v.each(t, function(t, n) {
                            var i = v.type(n);
                            i === "function" ? (!e.unique || !c.has(n)) && a.push(n) : n && n.length && i !== "string" && r(n)
                        })
                    }
                    )(arguments),
                    i ? o = a.length : n && (s = t,
                    l(n))
                }
                return this
            },
            remove: function() {
                return a && v.each(arguments, function(e, t) {
                    var n;
                    while ((n = v.inArray(t, a, n)) > -1)
                        a.splice(n, 1),
                        i && (n <= o && o--,
                        n <= u && u--)
                }),
                this
            },
            has: function(e) {
                return v.inArray(e, a) > -1
            },
            empty: function() {
                return a = [],
                this
            },
            disable: function() {
                return a = f = n = t,
                this
            },
            disabled: function() {
                return !a
            },
            lock: function() {
                return f = t,
                n || c.disable(),
                this
            },
            locked: function() {
                return !f
            },
            fireWith: function(e, t) {
                return t = t || [],
                t = [e, t.slice ? t.slice() : t],
                a && (!r || f) && (i ? f.push(t) : l(t)),
                this
            },
            fire: function() {
                return c.fireWith(this, arguments),
                this
            },
            fired: function() {
                return !!r
            }
        };
        return c
    }
    ,
    v.extend({
        Deferred: function(e) {
            var t = [["resolve", "done", v.Callbacks("once memory"), "resolved"], ["reject", "fail", v.Callbacks("once memory"), "rejected"], ["notify", "progress", v.Callbacks("memory")]]
              , n = "pending"
              , r = {
                state: function() {
                    return n
                },
                always: function() {
                    return i.done(arguments).fail(arguments),
                    this
                },
                then: function() {
                    var e = arguments;
                    return v.Deferred(function(n) {
                        v.each(t, function(t, r) {
                            var s = r[0]
                              , o = e[t];
                            i[r[1]](v.isFunction(o) ? function() {
                                var e = o.apply(this, arguments);
                                e && v.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[s + "With"](this === i ? n : this, [e])
                            }
                            : n[s])
                        }),
                        e = null
                    }).promise()
                },
                promise: function(e) {
                    return e != null ? v.extend(e, r) : r
                }
            }
              , i = {};
            return r.pipe = r.then,
            v.each(t, function(e, s) {
                var o = s[2]
                  , u = s[3];
                r[s[1]] = o.add,
                u && o.add(function() {
                    n = u
                }, t[e ^ 1][2].disable, t[2][2].lock),
                i[s[0]] = o.fire,
                i[s[0] + "With"] = o.fireWith
            }),
            r.promise(i),
            e && e.call(i, i),
            i
        },
        when: function(e) {
            var t = 0, n = l.call(arguments), r = n.length, i = r !== 1 || e && v.isFunction(e.promise) ? r : 0, s = i === 1 ? e : v.Deferred(), o = function(e, t, n) {
                return function(r) {
                    t[e] = this,
                    n[e] = arguments.length > 1 ? l.call(arguments) : r,
                    n === u ? s.notifyWith(t, n) : --i || s.resolveWith(t, n)
                }
            }, u, a, f;
            if (r > 1) {
                u = new Array(r),
                a = new Array(r),
                f = new Array(r);
                for (; t < r; t++)
                    n[t] && v.isFunction(n[t].promise) ? n[t].promise().done(o(t, f, n)).fail(s.reject).progress(o(t, a, u)) : --i
            }
            return i || s.resolveWith(f, n),
            s.promise()
        }
    }),
    v.support = function() {
        var t, n, r, s, o, u, a, f, l, c, h, p = i.createElement("div");
        p.setAttribute("className", "t"),
        p.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",
        n = p.getElementsByTagName("*"),
        r = p.getElementsByTagName("a")[0];
        if (!n || !r || !n.length)
            return {};
        s = i.createElement("select"),
        o = s.appendChild(i.createElement("option")),
        u = p.getElementsByTagName("input")[0],
        r.style.cssText = "top:1px;float:left;opacity:.5",
        t = {
            leadingWhitespace: p.firstChild.nodeType === 3,
            tbody: !p.getElementsByTagName("tbody").length,
            htmlSerialize: !!p.getElementsByTagName("link").length,
            style: /top/.test(r.getAttribute("style")),
            hrefNormalized: r.getAttribute("href") === "/a",
            opacity: /^0.5/.test(r.style.opacity),
            cssFloat: !!r.style.cssFloat,
            checkOn: u.value === "on",
            optSelected: o.selected,
            getSetAttribute: p.className !== "t",
            enctype: !!i.createElement("form").enctype,
            html5Clone: i.createElement("nav").cloneNode(!0).outerHTML !== "<:nav></:nav>",
            boxModel: i.compatMode === "CSS1Compat",
            submitBubbles: !0,
            changeBubbles: !0,
            focusinBubbles: !1,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0,
            boxSizingReliable: !0,
            pixelPosition: !1
        },
        u.checked = !0,
        t.noCloneChecked = u.cloneNode(!0).checked,
        s.disabled = !0,
        t.optDisabled = !o.disabled;
        try {
            delete p.test
        } catch (d) {
            t.deleteExpando = !1
        }
        !p.addEventListener && p.attachEvent && p.fireEvent && (p.attachEvent("onclick", h = function() {
            t.noCloneEvent = !1
        }
        ),
        p.cloneNode(!0).fireEvent("onclick"),
        p.detachEvent("onclick", h)),
        u = i.createElement("input"),
        u.value = "t",
        u.setAttribute("type", "radio"),
        t.radioValue = u.value === "t",
        u.setAttribute("checked", "checked"),
        u.setAttribute("name", "t"),
        p.appendChild(u),
        a = i.createDocumentFragment(),
        a.appendChild(p.lastChild),
        t.checkClone = a.cloneNode(!0).cloneNode(!0).lastChild.checked,
        t.appendChecked = u.checked,
        a.removeChild(u),
        a.appendChild(p);
        if (p.attachEvent)
            for (l in {
                submit: !0,
                change: !0,
                focusin: !0
            })
                f = "on" + l,
                c = f in p,
                c || (p.setAttribute(f, "return;"),
                c = typeof p[f] == "function"),
                t[l + "Bubbles"] = c;
        return v(function() {
            var n, r, s, o, u = "padding:0;margin:0;border:0;display:block;overflow:hidden;", a = i.getElementsByTagName("body")[0];
            if (!a)
                return;
            n = i.createElement("div"),
            n.style.cssText = "visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px",
            a.insertBefore(n, a.firstChild),
            r = i.createElement("div"),
            n.appendChild(r),
            r.innerHTML = "<table><tr><td></td><td>t</td></tr></table>",
            s = r.getElementsByTagName("td"),
            s[0].style.cssText = "padding:0;margin:0;border:0;display:none",
            c = s[0].offsetHeight === 0,
            s[0].style.display = "",
            s[1].style.display = "none",
            t.reliableHiddenOffsets = c && s[0].offsetHeight === 0,
            r.innerHTML = "",
            r.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",
            t.boxSizing = r.offsetWidth === 4,
            t.doesNotIncludeMarginInBodyOffset = a.offsetTop !== 1,
            e.getComputedStyle && (t.pixelPosition = (e.getComputedStyle(r, null) || {}).top !== "1%",
            t.boxSizingReliable = (e.getComputedStyle(r, null) || {
                width: "4px"
            }).width === "4px",
            o = i.createElement("div"),
            o.style.cssText = r.style.cssText = u,
            o.style.marginRight = o.style.width = "0",
            r.style.width = "1px",
            r.appendChild(o),
            t.reliableMarginRight = !parseFloat((e.getComputedStyle(o, null) || {}).marginRight)),
            typeof r.style.zoom != "undefined" && (r.innerHTML = "",
            r.style.cssText = u + "width:1px;padding:1px;display:inline;zoom:1",
            t.inlineBlockNeedsLayout = r.offsetWidth === 3,
            r.style.display = "block",
            r.style.overflow = "visible",
            r.innerHTML = "<div></div>",
            r.firstChild.style.width = "5px",
            t.shrinkWrapBlocks = r.offsetWidth !== 3,
            n.style.zoom = 1),
            a.removeChild(n),
            n = r = s = o = null
        }),
        a.removeChild(p),
        n = r = s = o = u = a = p = null,
        t
    }();
    var D = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/
      , P = /([A-Z])/g;
    v.extend({
        cache: {},
        deletedIds: [],
        uuid: 0,
        expando: "jQuery" + (v.fn.jquery + Math.random()).replace(/\D/g, ""),
        noData: {
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: !0
        },
        hasData: function(e) {
            return e = e.nodeType ? v.cache[e[v.expando]] : e[v.expando],
            !!e && !B(e)
        },
        data: function(e, n, r, i) {
            if (!v.acceptData(e))
                return;
            var s, o, u = v.expando, a = typeof n == "string", f = e.nodeType, l = f ? v.cache : e, c = f ? e[u] : e[u] && u;
            if ((!c || !l[c] || !i && !l[c].data) && a && r === t)
                return;
            c || (f ? e[u] = c = v.deletedIds.pop() || v.guid++ : c = u),
            l[c] || (l[c] = {},
            f || (l[c].toJSON = v.noop));
            if (typeof n == "object" || typeof n == "function")
                i ? l[c] = v.extend(l[c], n) : l[c].data = v.extend(l[c].data, n);
            return s = l[c],
            i || (s.data || (s.data = {}),
            s = s.data),
            r !== t && (s[v.camelCase(n)] = r),
            a ? (o = s[n],
            o == null && (o = s[v.camelCase(n)])) : o = s,
            o
        },
        removeData: function(e, t, n) {
            if (!v.acceptData(e))
                return;
            var r, i, s, o = e.nodeType, u = o ? v.cache : e, a = o ? e[v.expando] : v.expando;
            if (!u[a])
                return;
            if (t) {
                r = n ? u[a] : u[a].data;
                if (r) {
                    v.isArray(t) || (t in r ? t = [t] : (t = v.camelCase(t),
                    t in r ? t = [t] : t = t.split(" ")));
                    for (i = 0,
                    s = t.length; i < s; i++)
                        delete r[t[i]];
                    if (!(n ? B : v.isEmptyObject)(r))
                        return
                }
            }
            if (!n) {
                delete u[a].data;
                if (!B(u[a]))
                    return
            }
            o ? v.cleanData([e], !0) : v.support.deleteExpando || u != u.window ? delete u[a] : u[a] = null
        },
        _data: function(e, t, n) {
            return v.data(e, t, n, !0)
        },
        acceptData: function(e) {
            var t = e.nodeName && v.noData[e.nodeName.toLowerCase()];
            return !t || t !== !0 && e.getAttribute("classid") === t
        }
    }),
    v.fn.extend({
        data: function(e, n) {
            var r, i, s, o, u, a = this[0], f = 0, l = null;
            if (e === t) {
                if (this.length) {
                    l = v.data(a);
                    if (a.nodeType === 1 && !v._data(a, "parsedAttrs")) {
                        s = a.attributes;
                        for (u = s.length; f < u; f++)
                            o = s[f].name,
                            o.indexOf("data-") || (o = v.camelCase(o.substring(5)),
                            H(a, o, l[o]));
                        v._data(a, "parsedAttrs", !0)
                    }
                }
                return l
            }
            return typeof e == "object" ? this.each(function() {
                v.data(this, e)
            }) : (r = e.split(".", 2),
            r[1] = r[1] ? "." + r[1] : "",
            i = r[1] + "!",
            v.access(this, function(n) {
                if (n === t)
                    return l = this.triggerHandler("getData" + i, [r[0]]),
                    l === t && a && (l = v.data(a, e),
                    l = H(a, e, l)),
                    l === t && r[1] ? this.data(r[0]) : l;
                r[1] = n,
                this.each(function() {
                    var t = v(this);
                    t.triggerHandler("setData" + i, r),
                    v.data(this, e, n),
                    t.triggerHandler("changeData" + i, r)
                })
            }, null, n, arguments.length > 1, null, !1))
        },
        removeData: function(e) {
            return this.each(function() {
                v.removeData(this, e)
            })
        }
    }),
    v.extend({
        queue: function(e, t, n) {
            var r;
            if (e)
                return t = (t || "fx") + "queue",
                r = v._data(e, t),
                n && (!r || v.isArray(n) ? r = v._data(e, t, v.makeArray(n)) : r.push(n)),
                r || []
        },
        dequeue: function(e, t) {
            t = t || "fx";
            var n = v.queue(e, t)
              , r = n.length
              , i = n.shift()
              , s = v._queueHooks(e, t)
              , o = function() {
                v.dequeue(e, t)
            };
            i === "inprogress" && (i = n.shift(),
            r--),
            i && (t === "fx" && n.unshift("inprogress"),
            delete s.stop,
            i.call(e, o, s)),
            !r && s && s.empty.fire()
        },
        _queueHooks: function(e, t) {
            var n = t + "queueHooks";
            return v._data(e, n) || v._data(e, n, {
                empty: v.Callbacks("once memory").add(function() {
                    v.removeData(e, t + "queue", !0),
                    v.removeData(e, n, !0)
                })
            })
        }
    }),
    v.fn.extend({
        queue: function(e, n) {
            var r = 2;
            return typeof e != "string" && (n = e,
            e = "fx",
            r--),
            arguments.length < r ? v.queue(this[0], e) : n === t ? this : this.each(function() {
                var t = v.queue(this, e, n);
                v._queueHooks(this, e),
                e === "fx" && t[0] !== "inprogress" && v.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                v.dequeue(this, e)
            })
        },
        delay: function(e, t) {
            return e = v.fx ? v.fx.speeds[e] || e : e,
            t = t || "fx",
            this.queue(t, function(t, n) {
                var r = setTimeout(t, e);
                n.stop = function() {
                    clearTimeout(r)
                }
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, n) {
            var r, i = 1, s = v.Deferred(), o = this, u = this.length, a = function() {
                --i || s.resolveWith(o, [o])
            };
            typeof e != "string" && (n = e,
            e = t),
            e = e || "fx";
            while (u--)
                r = v._data(o[u], e + "queueHooks"),
                r && r.empty && (i++,
                r.empty.add(a));
            return a(),
            s.promise(n)
        }
    });
    var j, F, I, q = /[\t\r\n]/g, R = /\r/g, U = /^(?:button|input)$/i, z = /^(?:button|input|object|select|textarea)$/i, W = /^a(?:rea|)$/i, X = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i, V = v.support.getSetAttribute;
    v.fn.extend({
        attr: function(e, t) {
            return v.access(this, v.attr, e, t, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each(function() {
                v.removeAttr(this, e)
            })
        },
        prop: function(e, t) {
            return v.access(this, v.prop, e, t, arguments.length > 1)
        },
        removeProp: function(e) {
            return e = v.propFix[e] || e,
            this.each(function() {
                try {
                    this[e] = t,
                    delete this[e]
                } catch (n) {}
            })
        },
        addClass: function(e) {
            var t, n, r, i, s, o, u;
            if (v.isFunction(e))
                return this.each(function(t) {
                    v(this).addClass(e.call(this, t, this.className))
                });
            if (e && typeof e == "string") {
                t = e.split(y);
                for (n = 0,
                r = this.length; n < r; n++) {
                    i = this[n];
                    if (i.nodeType === 1)
                        if (!i.className && t.length === 1)
                            i.className = e;
                        else {
                            s = " " + i.className + " ";
                            for (o = 0,
                            u = t.length; o < u; o++)
                                s.indexOf(" " + t[o] + " ") < 0 && (s += t[o] + " ");
                            i.className = v.trim(s)
                        }
                }
            }
            return this
        },
        removeClass: function(e) {
            var n, r, i, s, o, u, a;
            if (v.isFunction(e))
                return this.each(function(t) {
                    v(this).removeClass(e.call(this, t, this.className))
                });
            if (e && typeof e == "string" || e === t) {
                n = (e || "").split(y);
                for (u = 0,
                a = this.length; u < a; u++) {
                    i = this[u];
                    if (i.nodeType === 1 && i.className) {
                        r = (" " + i.className + " ").replace(q, " ");
                        for (s = 0,
                        o = n.length; s < o; s++)
                            while (r.indexOf(" " + n[s] + " ") >= 0)
                                r = r.replace(" " + n[s] + " ", " ");
                        i.className = e ? v.trim(r) : ""
                    }
                }
            }
            return this
        },
        toggleClass: function(e, t) {
            var n = typeof e
              , r = typeof t == "boolean";
            return v.isFunction(e) ? this.each(function(n) {
                v(this).toggleClass(e.call(this, n, this.className, t), t)
            }) : this.each(function() {
                if (n === "string") {
                    var i, s = 0, o = v(this), u = t, a = e.split(y);
                    while (i = a[s++])
                        u = r ? u : !o.hasClass(i),
                        o[u ? "addClass" : "removeClass"](i)
                } else if (n === "undefined" || n === "boolean")
                    this.className && v._data(this, "__className__", this.className),
                    this.className = this.className || e === !1 ? "" : v._data(this, "__className__") || ""
            })
        },
        hasClass: function(e) {
            var t = " " + e + " "
              , n = 0
              , r = this.length;
            for (; n < r; n++)
                if (this[n].nodeType === 1 && (" " + this[n].className + " ").replace(q, " ").indexOf(t) >= 0)
                    return !0;
            return !1
        },
        val: function(e) {
            var n, r, i, s = this[0];
            if (!arguments.length) {
                if (s)
                    return n = v.valHooks[s.type] || v.valHooks[s.nodeName.toLowerCase()],
                    n && "get"in n && (r = n.get(s, "value")) !== t ? r : (r = s.value,
                    typeof r == "string" ? r.replace(R, "") : r == null ? "" : r);
                return
            }
            return i = v.isFunction(e),
            this.each(function(r) {
                var s, o = v(this);
                if (this.nodeType !== 1)
                    return;
                i ? s = e.call(this, r, o.val()) : s = e,
                s == null ? s = "" : typeof s == "number" ? s += "" : v.isArray(s) && (s = v.map(s, function(e) {
                    return e == null ? "" : e + ""
                })),
                n = v.valHooks[this.type] || v.valHooks[this.nodeName.toLowerCase()];
                if (!n || !("set"in n) || n.set(this, s, "value") === t)
                    this.value = s
            })
        }
    }),
    v.extend({
        valHooks: {
            option: {
                get: function(e) {
                    var t = e.attributes.value;
                    return !t || t.specified ? e.value : e.text
                }
            },
            select: {
                get: function(e) {
                    var t, n, r = e.options, i = e.selectedIndex, s = e.type === "select-one" || i < 0, o = s ? null : [], u = s ? i + 1 : r.length, a = i < 0 ? u : s ? i : 0;
                    for (; a < u; a++) {
                        n = r[a];
                        if ((n.selected || a === i) && (v.support.optDisabled ? !n.disabled : n.getAttribute("disabled") === null) && (!n.parentNode.disabled || !v.nodeName(n.parentNode, "optgroup"))) {
                            t = v(n).val();
                            if (s)
                                return t;
                            o.push(t)
                        }
                    }
                    return o
                },
                set: function(e, t) {
                    var n = v.makeArray(t);
                    return v(e).find("option").each(function() {
                        this.selected = v.inArray(v(this).val(), n) >= 0
                    }),
                    n.length || (e.selectedIndex = -1),
                    n
                }
            }
        },
        attrFn: {},
        attr: function(e, n, r, i) {
            var s, o, u, a = e.nodeType;
            if (!e || a === 3 || a === 8 || a === 2)
                return;
            if (i && v.isFunction(v.fn[n]))
                return v(e)[n](r);
            if (typeof e.getAttribute == "undefined")
                return v.prop(e, n, r);
            u = a !== 1 || !v.isXMLDoc(e),
            u && (n = n.toLowerCase(),
            o = v.attrHooks[n] || (X.test(n) ? F : j));
            if (r !== t) {
                if (r === null) {
                    v.removeAttr(e, n);
                    return
                }
                return o && "set"in o && u && (s = o.set(e, r, n)) !== t ? s : (e.setAttribute(n, r + ""),
                r)
            }
            return o && "get"in o && u && (s = o.get(e, n)) !== null ? s : (s = e.getAttribute(n),
            s === null ? t : s)
        },
        removeAttr: function(e, t) {
            var n, r, i, s, o = 0;
            if (t && e.nodeType === 1) {
                r = t.split(y);
                for (; o < r.length; o++)
                    i = r[o],
                    i && (n = v.propFix[i] || i,
                    s = X.test(i),
                    s || v.attr(e, i, ""),
                    e.removeAttribute(V ? i : n),
                    s && n in e && (e[n] = !1))
            }
        },
        attrHooks: {
            type: {
                set: function(e, t) {
                    if (U.test(e.nodeName) && e.parentNode)
                        v.error("type property can't be changed");
                    else if (!v.support.radioValue && t === "radio" && v.nodeName(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t),
                        n && (e.value = n),
                        t
                    }
                }
            },
            value: {
                get: function(e, t) {
                    return j && v.nodeName(e, "button") ? j.get(e, t) : t in e ? e.value : null
                },
                set: function(e, t, n) {
                    if (j && v.nodeName(e, "button"))
                        return j.set(e, t, n);
                    e.value = t
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            "for": "htmlFor",
            "class": "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function(e, n, r) {
            var i, s, o, u = e.nodeType;
            if (!e || u === 3 || u === 8 || u === 2)
                return;
            return o = u !== 1 || !v.isXMLDoc(e),
            o && (n = v.propFix[n] || n,
            s = v.propHooks[n]),
            r !== t ? s && "set"in s && (i = s.set(e, r, n)) !== t ? i : e[n] = r : s && "get"in s && (i = s.get(e, n)) !== null ? i : e[n]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var n = e.getAttributeNode("tabindex");
                    return n && n.specified ? parseInt(n.value, 10) : z.test(e.nodeName) || W.test(e.nodeName) && e.href ? 0 : t
                }
            }
        }
    }),
    F = {
        get: function(e, n) {
            var r, i = v.prop(e, n);
            return i === !0 || typeof i != "boolean" && (r = e.getAttributeNode(n)) && r.nodeValue !== !1 ? n.toLowerCase() : t
        },
        set: function(e, t, n) {
            var r;
            return t === !1 ? v.removeAttr(e, n) : (r = v.propFix[n] || n,
            r in e && (e[r] = !0),
            e.setAttribute(n, n.toLowerCase())),
            n
        }
    },
    V || (I = {
        name: !0,
        id: !0,
        coords: !0
    },
    j = v.valHooks.button = {
        get: function(e, n) {
            var r;
            return r = e.getAttributeNode(n),
            r && (I[n] ? r.value !== "" : r.specified) ? r.value : t
        },
        set: function(e, t, n) {
            var r = e.getAttributeNode(n);
            return r || (r = i.createAttribute(n),
            e.setAttributeNode(r)),
            r.value = t + ""
        }
    },
    v.each(["width", "height"], function(e, t) {
        v.attrHooks[t] = v.extend(v.attrHooks[t], {
            set: function(e, n) {
                if (n === "")
                    return e.setAttribute(t, "auto"),
                    n
            }
        })
    }),
    v.attrHooks.contenteditable = {
        get: j.get,
        set: function(e, t, n) {
            t === "" && (t = "false"),
            j.set(e, t, n)
        }
    }),
    v.support.hrefNormalized || v.each(["href", "src", "width", "height"], function(e, n) {
        v.attrHooks[n] = v.extend(v.attrHooks[n], {
            get: function(e) {
                var r = e.getAttribute(n, 2);
                return r === null ? t : r
            }
        })
    }),
    v.support.style || (v.attrHooks.style = {
        get: function(e) {
            return e.style.cssText.toLowerCase() || t
        },
        set: function(e, t) {
            return e.style.cssText = t + ""
        }
    }),
    v.support.optSelected || (v.propHooks.selected = v.extend(v.propHooks.selected, {
        get: function(e) {
            var t = e.parentNode;
            return t && (t.selectedIndex,
            t.parentNode && t.parentNode.selectedIndex),
            null
        }
    })),
    v.support.enctype || (v.propFix.enctype = "encoding"),
    v.support.checkOn || v.each(["radio", "checkbox"], function() {
        v.valHooks[this] = {
            get: function(e) {
                return e.getAttribute("value") === null ? "on" : e.value
            }
        }
    }),
    v.each(["radio", "checkbox"], function() {
        v.valHooks[this] = v.extend(v.valHooks[this], {
            set: function(e, t) {
                if (v.isArray(t))
                    return e.checked = v.inArray(v(e).val(), t) >= 0
            }
        })
    });
    var $ = /^(?:textarea|input|select)$/i
      , J = /^([^\.]*|)(?:\.(.+)|)$/
      , K = /(?:^|\s)hover(\.\S+|)\b/
      , Q = /^key/
      , G = /^(?:mouse|contextmenu)|click/
      , Y = /^(?:focusinfocus|focusoutblur)$/
      , Z = function(e) {
        return v.event.special.hover ? e : e.replace(K, "mouseenter$1 mouseleave$1")
    };
    v.event = {
        add: function(e, n, r, i, s) {
            var o, u, a, f, l, c, h, p, d, m, g;
            if (e.nodeType === 3 || e.nodeType === 8 || !n || !r || !(o = v._data(e)))
                return;
            r.handler && (d = r,
            r = d.handler,
            s = d.selector),
            r.guid || (r.guid = v.guid++),
            a = o.events,
            a || (o.events = a = {}),
            u = o.handle,
            u || (o.handle = u = function(e) {
                return typeof v == "undefined" || !!e && v.event.triggered === e.type ? t : v.event.dispatch.apply(u.elem, arguments)
            }
            ,
            u.elem = e),
            n = v.trim(Z(n)).split(" ");
            for (f = 0; f < n.length; f++) {
                l = J.exec(n[f]) || [],
                c = l[1],
                h = (l[2] || "").split(".").sort(),
                g = v.event.special[c] || {},
                c = (s ? g.delegateType : g.bindType) || c,
                g = v.event.special[c] || {},
                p = v.extend({
                    type: c,
                    origType: l[1],
                    data: i,
                    handler: r,
                    guid: r.guid,
                    selector: s,
                    needsContext: s && v.expr.match.needsContext.test(s),
                    namespace: h.join(".")
                }, d),
                m = a[c];
                if (!m) {
                    m = a[c] = [],
                    m.delegateCount = 0;
                    if (!g.setup || g.setup.call(e, i, h, u) === !1)
                        e.addEventListener ? e.addEventListener(c, u, !1) : e.attachEvent && e.attachEvent("on" + c, u)
                }
                g.add && (g.add.call(e, p),
                p.handler.guid || (p.handler.guid = r.guid)),
                s ? m.splice(m.delegateCount++, 0, p) : m.push(p),
                v.event.global[c] = !0
            }
            e = null
        },
        global: {},
        remove: function(e, t, n, r, i) {
            var s, o, u, a, f, l, c, h, p, d, m, g = v.hasData(e) && v._data(e);
            if (!g || !(h = g.events))
                return;
            t = v.trim(Z(t || "")).split(" ");
            for (s = 0; s < t.length; s++) {
                o = J.exec(t[s]) || [],
                u = a = o[1],
                f = o[2];
                if (!u) {
                    for (u in h)
                        v.event.remove(e, u + t[s], n, r, !0);
                    continue
                }
                p = v.event.special[u] || {},
                u = (r ? p.delegateType : p.bindType) || u,
                d = h[u] || [],
                l = d.length,
                f = f ? new RegExp("(^|\\.)" + f.split(".").sort().join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
                for (c = 0; c < d.length; c++)
                    m = d[c],
                    (i || a === m.origType) && (!n || n.guid === m.guid) && (!f || f.test(m.namespace)) && (!r || r === m.selector || r === "**" && m.selector) && (d.splice(c--, 1),
                    m.selector && d.delegateCount--,
                    p.remove && p.remove.call(e, m));
                d.length === 0 && l !== d.length && ((!p.teardown || p.teardown.call(e, f, g.handle) === !1) && v.removeEvent(e, u, g.handle),
                delete h[u])
            }
            v.isEmptyObject(h) && (delete g.handle,
            v.removeData(e, "events", !0))
        },
        customEvent: {
            getData: !0,
            setData: !0,
            changeData: !0
        },
        trigger: function(n, r, s, o) {
            if (!s || s.nodeType !== 3 && s.nodeType !== 8) {
                var u, a, f, l, c, h, p, d, m, g, y = n.type || n, b = [];
                if (Y.test(y + v.event.triggered))
                    return;
                y.indexOf("!") >= 0 && (y = y.slice(0, -1),
                a = !0),
                y.indexOf(".") >= 0 && (b = y.split("."),
                y = b.shift(),
                b.sort());
                if ((!s || v.event.customEvent[y]) && !v.event.global[y])
                    return;
                n = typeof n == "object" ? n[v.expando] ? n : new v.Event(y,n) : new v.Event(y),
                n.type = y,
                n.isTrigger = !0,
                n.exclusive = a,
                n.namespace = b.join("."),
                n.namespace_re = n.namespace ? new RegExp("(^|\\.)" + b.join("\\.(?:.*\\.|)") + "(\\.|$)") : null,
                h = y.indexOf(":") < 0 ? "on" + y : "";
                if (!s) {
                    u = v.cache;
                    for (f in u)
                        u[f].events && u[f].events[y] && v.event.trigger(n, r, u[f].handle.elem, !0);
                    return
                }
                n.result = t,
                n.target || (n.target = s),
                r = r != null ? v.makeArray(r) : [],
                r.unshift(n),
                p = v.event.special[y] || {};
                if (p.trigger && p.trigger.apply(s, r) === !1)
                    return;
                m = [[s, p.bindType || y]];
                if (!o && !p.noBubble && !v.isWindow(s)) {
                    g = p.delegateType || y,
                    l = Y.test(g + y) ? s : s.parentNode;
                    for (c = s; l; l = l.parentNode)
                        m.push([l, g]),
                        c = l;
                    c === (s.ownerDocument || i) && m.push([c.defaultView || c.parentWindow || e, g])
                }
                for (f = 0; f < m.length && !n.isPropagationStopped(); f++)
                    l = m[f][0],
                    n.type = m[f][1],
                    d = (v._data(l, "events") || {})[n.type] && v._data(l, "handle"),
                    d && d.apply(l, r),
                    d = h && l[h],
                    d && v.acceptData(l) && d.apply && d.apply(l, r) === !1 && n.preventDefault();
                return n.type = y,
                !o && !n.isDefaultPrevented() && (!p._default || p._default.apply(s.ownerDocument, r) === !1) && (y !== "click" || !v.nodeName(s, "a")) && v.acceptData(s) && h && s[y] && (y !== "focus" && y !== "blur" || n.target.offsetWidth !== 0) && !v.isWindow(s) && (c = s[h],
                c && (s[h] = null),
                v.event.triggered = y,
                s[y](),
                v.event.triggered = t,
                c && (s[h] = c)),
                n.result
            }
            return
        },
        dispatch: function(n) {
            n = v.event.fix(n || e.event);
            var r, i, s, o, u, a, f, c, h, p, d = (v._data(this, "events") || {})[n.type] || [], m = d.delegateCount, g = l.call(arguments), y = !n.exclusive && !n.namespace, b = v.event.special[n.type] || {}, w = [];
            g[0] = n,
            n.delegateTarget = this;
            if (b.preDispatch && b.preDispatch.call(this, n) === !1)
                return;
            if (m && (!n.button || n.type !== "click"))
                for (s = n.target; s != this; s = s.parentNode || this)
                    if (s.disabled !== !0 || n.type !== "click") {
                        u = {},
                        f = [];
                        for (r = 0; r < m; r++)
                            c = d[r],
                            h = c.selector,
                            u[h] === t && (u[h] = c.needsContext ? v(h, this).index(s) >= 0 : v.find(h, this, null, [s]).length),
                            u[h] && f.push(c);
                        f.length && w.push({
                            elem: s,
                            matches: f
                        })
                    }
            d.length > m && w.push({
                elem: this,
                matches: d.slice(m)
            });
            for (r = 0; r < w.length && !n.isPropagationStopped(); r++) {
                a = w[r],
                n.currentTarget = a.elem;
                for (i = 0; i < a.matches.length && !n.isImmediatePropagationStopped(); i++) {
                    c = a.matches[i];
                    if (y || !n.namespace && !c.namespace || n.namespace_re && n.namespace_re.test(c.namespace))
                        n.data = c.data,
                        n.handleObj = c,
                        o = ((v.event.special[c.origType] || {}).handle || c.handler).apply(a.elem, g),
                        o !== t && (n.result = o,
                        o === !1 && (n.preventDefault(),
                        n.stopPropagation()))
                }
            }
            return b.postDispatch && b.postDispatch.call(this, n),
            n.result
        },
        props: "attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function(e, t) {
                return e.which == null && (e.which = t.charCode != null ? t.charCode : t.keyCode),
                e
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function(e, n) {
                var r, s, o, u = n.button, a = n.fromElement;
                return e.pageX == null && n.clientX != null && (r = e.target.ownerDocument || i,
                s = r.documentElement,
                o = r.body,
                e.pageX = n.clientX + (s && s.scrollLeft || o && o.scrollLeft || 0) - (s && s.clientLeft || o && o.clientLeft || 0),
                e.pageY = n.clientY + (s && s.scrollTop || o && o.scrollTop || 0) - (s && s.clientTop || o && o.clientTop || 0)),
                !e.relatedTarget && a && (e.relatedTarget = a === e.target ? n.toElement : a),
                !e.which && u !== t && (e.which = u & 1 ? 1 : u & 2 ? 3 : u & 4 ? 2 : 0),
                e
            }
        },
        fix: function(e) {
            if (e[v.expando])
                return e;
            var t, n, r = e, s = v.event.fixHooks[e.type] || {}, o = s.props ? this.props.concat(s.props) : this.props;
            e = v.Event(r);
            for (t = o.length; t; )
                n = o[--t],
                e[n] = r[n];
            return e.target || (e.target = r.srcElement || i),
            e.target.nodeType === 3 && (e.target = e.target.parentNode),
            e.metaKey = !!e.metaKey,
            s.filter ? s.filter(e, r) : e
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                delegateType: "focusin"
            },
            blur: {
                delegateType: "focusout"
            },
            beforeunload: {
                setup: function(e, t, n) {
                    v.isWindow(this) && (this.onbeforeunload = n)
                },
                teardown: function(e, t) {
                    this.onbeforeunload === t && (this.onbeforeunload = null)
                }
            }
        },
        simulate: function(e, t, n, r) {
            var i = v.extend(new v.Event, n, {
                type: e,
                isSimulated: !0,
                originalEvent: {}
            });
            r ? v.event.trigger(i, null, t) : v.event.dispatch.call(t, i),
            i.isDefaultPrevented() && n.preventDefault()
        }
    },
    v.event.handle = v.event.dispatch,
    v.removeEvent = i.removeEventListener ? function(e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n, !1)
    }
    : function(e, t, n) {
        var r = "on" + t;
        e.detachEvent && (typeof e[r] == "undefined" && (e[r] = null),
        e.detachEvent(r, n))
    }
    ,
    v.Event = function(e, t) {
        if (!(this instanceof v.Event))
            return new v.Event(e,t);
        e && e.type ? (this.originalEvent = e,
        this.type = e.type,
        this.isDefaultPrevented = e.defaultPrevented || e.returnValue === !1 || e.getPreventDefault && e.getPreventDefault() ? tt : et) : this.type = e,
        t && v.extend(this, t),
        this.timeStamp = e && e.timeStamp || v.now(),
        this[v.expando] = !0
    }
    ,
    v.Event.prototype = {
        preventDefault: function() {
            this.isDefaultPrevented = tt;
            var e = this.originalEvent;
            if (!e)
                return;
            e.preventDefault ? e.preventDefault() : e.returnValue = !1
        },
        stopPropagation: function() {
            this.isPropagationStopped = tt;
            var e = this.originalEvent;
            if (!e)
                return;
            e.stopPropagation && e.stopPropagation(),
            e.cancelBubble = !0
        },
        stopImmediatePropagation: function() {
            this.isImmediatePropagationStopped = tt,
            this.stopPropagation()
        },
        isDefaultPrevented: et,
        isPropagationStopped: et,
        isImmediatePropagationStopped: et
    },
    v.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function(e, t) {
        v.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function(e) {
                var n, r = this, i = e.relatedTarget, s = e.handleObj, o = s.selector;
                if (!i || i !== r && !v.contains(r, i))
                    e.type = s.origType,
                    n = s.handler.apply(this, arguments),
                    e.type = t;
                return n
            }
        }
    }),
    v.support.submitBubbles || (v.event.special.submit = {
        setup: function() {
            if (v.nodeName(this, "form"))
                return !1;
            v.event.add(this, "click._submit keypress._submit", function(e) {
                var n = e.target
                  , r = v.nodeName(n, "input") || v.nodeName(n, "button") ? n.form : t;
                r && !v._data(r, "_submit_attached") && (v.event.add(r, "submit._submit", function(e) {
                    e._submit_bubble = !0
                }),
                v._data(r, "_submit_attached", !0))
            })
        },
        postDispatch: function(e) {
            e._submit_bubble && (delete e._submit_bubble,
            this.parentNode && !e.isTrigger && v.event.simulate("submit", this.parentNode, e, !0))
        },
        teardown: function() {
            if (v.nodeName(this, "form"))
                return !1;
            v.event.remove(this, "._submit")
        }
    }),
    v.support.changeBubbles || (v.event.special.change = {
        setup: function() {
            if ($.test(this.nodeName)) {
                if (this.type === "checkbox" || this.type === "radio")
                    v.event.add(this, "propertychange._change", function(e) {
                        e.originalEvent.propertyName === "checked" && (this._just_changed = !0)
                    }),
                    v.event.add(this, "click._change", function(e) {
                        this._just_changed && !e.isTrigger && (this._just_changed = !1),
                        v.event.simulate("change", this, e, !0)
                    });
                return !1
            }
            v.event.add(this, "beforeactivate._change", function(e) {
                var t = e.target;
                $.test(t.nodeName) && !v._data(t, "_change_attached") && (v.event.add(t, "change._change", function(e) {
                    this.parentNode && !e.isSimulated && !e.isTrigger && v.event.simulate("change", this.parentNode, e, !0)
                }),
                v._data(t, "_change_attached", !0))
            })
        },
        handle: function(e) {
            var t = e.target;
            if (this !== t || e.isSimulated || e.isTrigger || t.type !== "radio" && t.type !== "checkbox")
                return e.handleObj.handler.apply(this, arguments)
        },
        teardown: function() {
            return v.event.remove(this, "._change"),
            !$.test(this.nodeName)
        }
    }),
    v.support.focusinBubbles || v.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, t) {
        var n = 0
          , r = function(e) {
            v.event.simulate(t, e.target, v.event.fix(e), !0)
        };
        v.event.special[t] = {
            setup: function() {
                n++ === 0 && i.addEventListener(e, r, !0)
            },
            teardown: function() {
                --n === 0 && i.removeEventListener(e, r, !0)
            }
        }
    }),
    v.fn.extend({
        on: function(e, n, r, i, s) {
            var o, u;
            if (typeof e == "object") {
                typeof n != "string" && (r = r || n,
                n = t);
                for (u in e)
                    this.on(u, n, r, e[u], s);
                return this
            }
            r == null && i == null ? (i = n,
            r = n = t) : i == null && (typeof n == "string" ? (i = r,
            r = t) : (i = r,
            r = n,
            n = t));
            if (i === !1)
                i = et;
            else if (!i)
                return this;
            return s === 1 && (o = i,
            i = function(e) {
                return v().off(e),
                o.apply(this, arguments)
            }
            ,
            i.guid = o.guid || (o.guid = v.guid++)),
            this.each(function() {
                v.event.add(this, e, i, r, n)
            })
        },
        one: function(e, t, n, r) {
            return this.on(e, t, n, r, 1)
        },
        off: function(e, n, r) {
            var i, s;
            if (e && e.preventDefault && e.handleObj)
                return i = e.handleObj,
                v(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler),
                this;
            if (typeof e == "object") {
                for (s in e)
                    this.off(s, n, e[s]);
                return this
            }
            if (n === !1 || typeof n == "function")
                r = n,
                n = t;
            return r === !1 && (r = et),
            this.each(function() {
                v.event.remove(this, e, r, n)
            })
        },
        bind: function(e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function(e, t) {
            return this.off(e, null, t)
        },
        live: function(e, t, n) {
            return v(this.context).on(e, this.selector, t, n),
            this
        },
        die: function(e, t) {
            return v(this.context).off(e, this.selector || "**", t),
            this
        },
        delegate: function(e, t, n, r) {
            return this.on(t, e, n, r)
        },
        undelegate: function(e, t, n) {
            return arguments.length === 1 ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        trigger: function(e, t) {
            return this.each(function() {
                v.event.trigger(e, t, this)
            })
        },
        triggerHandler: function(e, t) {
            if (this[0])
                return v.event.trigger(e, t, this[0], !0)
        },
        toggle: function(e) {
            var t = arguments
              , n = e.guid || v.guid++
              , r = 0
              , i = function(n) {
                var i = (v._data(this, "lastToggle" + e.guid) || 0) % r;
                return v._data(this, "lastToggle" + e.guid, i + 1),
                n.preventDefault(),
                t[i].apply(this, arguments) || !1
            };
            i.guid = n;
            while (r < t.length)
                t[r++].guid = n;
            return this.click(i)
        },
        hover: function(e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        }
    }),
    v.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function(e, t) {
        v.fn[t] = function(e, n) {
            return n == null && (n = e,
            e = null),
            arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }
        ,
        Q.test(t) && (v.event.fixHooks[t] = v.event.keyHooks),
        G.test(t) && (v.event.fixHooks[t] = v.event.mouseHooks)
    }),
    function(e, t) {
        function nt(e, t, n, r) {
            n = n || [],
            t = t || g;
            var i, s, a, f, l = t.nodeType;
            if (!e || typeof e != "string")
                return n;
            if (l !== 1 && l !== 9)
                return [];
            a = o(t);
            if (!a && !r)
                if (i = R.exec(e))
                    if (f = i[1]) {
                        if (l === 9) {
                            s = t.getElementById(f);
                            if (!s || !s.parentNode)
                                return n;
                            if (s.id === f)
                                return n.push(s),
                                n
                        } else if (t.ownerDocument && (s = t.ownerDocument.getElementById(f)) && u(t, s) && s.id === f)
                            return n.push(s),
                            n
                    } else {
                        if (i[2])
                            return S.apply(n, x.call(t.getElementsByTagName(e), 0)),
                            n;
                        if ((f = i[3]) && Z && t.getElementsByClassName)
                            return S.apply(n, x.call(t.getElementsByClassName(f), 0)),
                            n
                    }
            return vt(e.replace(j, "$1"), t, n, r, a)
        }
        function rt(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return n === "input" && t.type === e
            }
        }
        function it(e) {
            return function(t) {
                var n = t.nodeName.toLowerCase();
                return (n === "input" || n === "button") && t.type === e
            }
        }
        function st(e) {
            return N(function(t) {
                return t = +t,
                N(function(n, r) {
                    var i, s = e([], n.length, t), o = s.length;
                    while (o--)
                        n[i = s[o]] && (n[i] = !(r[i] = n[i]))
                })
            })
        }
        function ot(e, t, n) {
            if (e === t)
                return n;
            var r = e.nextSibling;
            while (r) {
                if (r === t)
                    return -1;
                r = r.nextSibling
            }
            return 1
        }
        function ut(e, t) {
            var n, r, s, o, u, a, f, l = L[d][e + " "];
            if (l)
                return t ? 0 : l.slice(0);
            u = e,
            a = [],
            f = i.preFilter;
            while (u) {
                if (!n || (r = F.exec(u)))
                    r && (u = u.slice(r[0].length) || u),
                    a.push(s = []);
                n = !1;
                if (r = I.exec(u))
                    s.push(n = new m(r.shift())),
                    u = u.slice(n.length),
                    n.type = r[0].replace(j, " ");
                for (o in i.filter)
                    (r = J[o].exec(u)) && (!f[o] || (r = f[o](r))) && (s.push(n = new m(r.shift())),
                    u = u.slice(n.length),
                    n.type = o,
                    n.matches = r);
                if (!n)
                    break
            }
            return t ? u.length : u ? nt.error(e) : L(e, a).slice(0)
        }
        function at(e, t, r) {
            var i = t.dir
              , s = r && t.dir === "parentNode"
              , o = w++;
            return t.first ? function(t, n, r) {
                while (t = t[i])
                    if (s || t.nodeType === 1)
                        return e(t, n, r)
            }
            : function(t, r, u) {
                if (!u) {
                    var a, f = b + " " + o + " ", l = f + n;
                    while (t = t[i])
                        if (s || t.nodeType === 1) {
                            if ((a = t[d]) === l)
                                return t.sizset;
                            if (typeof a == "string" && a.indexOf(f) === 0) {
                                if (t.sizset)
                                    return t
                            } else {
                                t[d] = l;
                                if (e(t, r, u))
                                    return t.sizset = !0,
                                    t;
                                t.sizset = !1
                            }
                        }
                } else
                    while (t = t[i])
                        if (s || t.nodeType === 1)
                            if (e(t, r, u))
                                return t
            }
        }
        function ft(e) {
            return e.length > 1 ? function(t, n, r) {
                var i = e.length;
                while (i--)
                    if (!e[i](t, n, r))
                        return !1;
                return !0
            }
            : e[0]
        }
        function lt(e, t, n, r, i) {
            var s, o = [], u = 0, a = e.length, f = t != null;
            for (; u < a; u++)
                if (s = e[u])
                    if (!n || n(s, r, i))
                        o.push(s),
                        f && t.push(u);
            return o
        }
        function ct(e, t, n, r, i, s) {
            return r && !r[d] && (r = ct(r)),
            i && !i[d] && (i = ct(i, s)),
            N(function(s, o, u, a) {
                var f, l, c, h = [], p = [], d = o.length, v = s || dt(t || "*", u.nodeType ? [u] : u, []), m = e && (s || !t) ? lt(v, h, e, u, a) : v, g = n ? i || (s ? e : d || r) ? [] : o : m;
                n && n(m, g, u, a);
                if (r) {
                    f = lt(g, p),
                    r(f, [], u, a),
                    l = f.length;
                    while (l--)
                        if (c = f[l])
                            g[p[l]] = !(m[p[l]] = c)
                }
                if (s) {
                    if (i || e) {
                        if (i) {
                            f = [],
                            l = g.length;
                            while (l--)
                                (c = g[l]) && f.push(m[l] = c);
                            i(null, g = [], f, a)
                        }
                        l = g.length;
                        while (l--)
                            (c = g[l]) && (f = i ? T.call(s, c) : h[l]) > -1 && (s[f] = !(o[f] = c))
                    }
                } else
                    g = lt(g === o ? g.splice(d, g.length) : g),
                    i ? i(null, o, g, a) : S.apply(o, g)
            })
        }
        function ht(e) {
            var t, n, r, s = e.length, o = i.relative[e[0].type], u = o || i.relative[" "], a = o ? 1 : 0, f = at(function(e) {
                return e === t
            }, u, !0), l = at(function(e) {
                return T.call(t, e) > -1
            }, u, !0), h = [function(e, n, r) {
                return !o && (r || n !== c) || ((t = n).nodeType ? f(e, n, r) : l(e, n, r))
            }
            ];
            for (; a < s; a++)
                if (n = i.relative[e[a].type])
                    h = [at(ft(h), n)];
                else {
                    n = i.filter[e[a].type].apply(null, e[a].matches);
                    if (n[d]) {
                        r = ++a;
                        for (; r < s; r++)
                            if (i.relative[e[r].type])
                                break;
                        return ct(a > 1 && ft(h), a > 1 && e.slice(0, a - 1).join("").replace(j, "$1"), n, a < r && ht(e.slice(a, r)), r < s && ht(e = e.slice(r)), r < s && e.join(""))
                    }
                    h.push(n)
                }
            return ft(h)
        }
        function pt(e, t) {
            var r = t.length > 0
              , s = e.length > 0
              , o = function(u, a, f, l, h) {
                var p, d, v, m = [], y = 0, w = "0", x = u && [], T = h != null, N = c, C = u || s && i.find.TAG("*", h && a.parentNode || a), k = b += N == null ? 1 : Math.E;
                T && (c = a !== g && a,
                n = o.el);
                for (; (p = C[w]) != null; w++) {
                    if (s && p) {
                        for (d = 0; v = e[d]; d++)
                            if (v(p, a, f)) {
                                l.push(p);
                                break
                            }
                        T && (b = k,
                        n = ++o.el)
                    }
                    r && ((p = !v && p) && y--,
                    u && x.push(p))
                }
                y += w;
                if (r && w !== y) {
                    for (d = 0; v = t[d]; d++)
                        v(x, m, a, f);
                    if (u) {
                        if (y > 0)
                            while (w--)
                                !x[w] && !m[w] && (m[w] = E.call(l));
                        m = lt(m)
                    }
                    S.apply(l, m),
                    T && !u && m.length > 0 && y + t.length > 1 && nt.uniqueSort(l)
                }
                return T && (b = k,
                c = N),
                x
            };
            return o.el = 0,
            r ? N(o) : o
        }
        function dt(e, t, n) {
            var r = 0
              , i = t.length;
            for (; r < i; r++)
                nt(e, t[r], n);
            return n
        }
        function vt(e, t, n, r, s) {
            var o, u, f, l, c, h = ut(e), p = h.length;
            if (!r && h.length === 1) {
                u = h[0] = h[0].slice(0);
                if (u.length > 2 && (f = u[0]).type === "ID" && t.nodeType === 9 && !s && i.relative[u[1].type]) {
                    t = i.find.ID(f.matches[0].replace($, ""), t, s)[0];
                    if (!t)
                        return n;
                    e = e.slice(u.shift().length)
                }
                for (o = J.POS.test(e) ? -1 : u.length - 1; o >= 0; o--) {
                    f = u[o];
                    if (i.relative[l = f.type])
                        break;
                    if (c = i.find[l])
                        if (r = c(f.matches[0].replace($, ""), z.test(u[0].type) && t.parentNode || t, s)) {
                            u.splice(o, 1),
                            e = r.length && u.join("");
                            if (!e)
                                return S.apply(n, x.call(r, 0)),
                                n;
                            break
                        }
                }
            }
            return a(e, h)(r, t, s, n, z.test(e)),
            n
        }
        function mt() {}
        var n, r, i, s, o, u, a, f, l, c, h = !0, p = "undefined", d = ("sizcache" + Math.random()).replace(".", ""), m = String, g = e.document, y = g.documentElement, b = 0, w = 0, E = [].pop, S = [].push, x = [].slice, T = [].indexOf || function(e) {
            var t = 0
              , n = this.length;
            for (; t < n; t++)
                if (this[t] === e)
                    return t;
            return -1
        }
        , N = function(e, t) {
            return e[d] = t == null || t,
            e
        }, C = function() {
            var e = {}
              , t = [];
            return N(function(n, r) {
                return t.push(n) > i.cacheLength && delete e[t.shift()],
                e[n + " "] = r
            }, e)
        }, k = C(), L = C(), A = C(), O = "[\\x20\\t\\r\\n\\f]", M = "(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+", _ = M.replace("w", "w#"), D = "([*^$|!~]?=)", P = "\\[" + O + "*(" + M + ")" + O + "*(?:" + D + O + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + _ + ")|)|)" + O + "*\\]", H = ":(" + M + ")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:" + P + ")|[^:]|\\\\.)*|.*))\\)|)", B = ":(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + O + "*((?:-\\d)?\\d*)" + O + "*\\)|)(?=[^-]|$)", j = new RegExp("^" + O + "+|((?:^|[^\\\\])(?:\\\\.)*)" + O + "+$","g"), F = new RegExp("^" + O + "*," + O + "*"), I = new RegExp("^" + O + "*([\\x20\\t\\r\\n\\f>+~])" + O + "*"), q = new RegExp(H), R = /^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/, U = /^:not/, z = /[\x20\t\r\n\f]*[+~]/, W = /:not\($/, X = /h\d/i, V = /input|select|textarea|button/i, $ = /\\(?!\\)/g, J = {
            ID: new RegExp("^#(" + M + ")"),
            CLASS: new RegExp("^\\.(" + M + ")"),
            NAME: new RegExp("^\\[name=['\"]?(" + M + ")['\"]?\\]"),
            TAG: new RegExp("^(" + M.replace("w", "w*") + ")"),
            ATTR: new RegExp("^" + P),
            PSEUDO: new RegExp("^" + H),
            POS: new RegExp(B,"i"),
            CHILD: new RegExp("^:(only|nth|first|last)-child(?:\\(" + O + "*(even|odd|(([+-]|)(\\d*)n|)" + O + "*(?:([+-]|)" + O + "*(\\d+)|))" + O + "*\\)|)","i"),
            needsContext: new RegExp("^" + O + "*[>+~]|" + B,"i")
        }, K = function(e) {
            var t = g.createElement("div");
            try {
                return e(t)
            } catch (n) {
                return !1
            } finally {
                t = null
            }
        }, Q = K(function(e) {
            return e.appendChild(g.createComment("")),
            !e.getElementsByTagName("*").length
        }), G = K(function(e) {
            return e.innerHTML = "<a href='#'></a>",
            e.firstChild && typeof e.firstChild.getAttribute !== p && e.firstChild.getAttribute("href") === "#"
        }), Y = K(function(e) {
            e.innerHTML = "<select></select>";
            var t = typeof e.lastChild.getAttribute("multiple");
            return t !== "boolean" && t !== "string"
        }), Z = K(function(e) {
            return e.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>",
            !e.getElementsByClassName || !e.getElementsByClassName("e").length ? !1 : (e.lastChild.className = "e",
            e.getElementsByClassName("e").length === 2)
        }), et = K(function(e) {
            e.id = d + 0,
            e.innerHTML = "<a name='" + d + "'></a><div name='" + d + "'></div>",
            y.insertBefore(e, y.firstChild);
            var t = g.getElementsByName && g.getElementsByName(d).length === 2 + g.getElementsByName(d + 0).length;
            return r = !g.getElementById(d),
            y.removeChild(e),
            t
        });
        try {
            x.call(y.childNodes, 0)[0].nodeType
        } catch (tt) {
            x = function(e) {
                var t, n = [];
                for (; t = this[e]; e++)
                    n.push(t);
                return n
            }
        }
        nt.matches = function(e, t) {
            return nt(e, null, null, t)
        }
        ,
        nt.matchesSelector = function(e, t) {
            return nt(t, null, null, [e]).length > 0
        }
        ,
        s = nt.getText = function(e) {
            var t, n = "", r = 0, i = e.nodeType;
            if (i) {
                if (i === 1 || i === 9 || i === 11) {
                    if (typeof e.textContent == "string")
                        return e.textContent;
                    for (e = e.firstChild; e; e = e.nextSibling)
                        n += s(e)
                } else if (i === 3 || i === 4)
                    return e.nodeValue
            } else
                for (; t = e[r]; r++)
                    n += s(t);
            return n
        }
        ,
        o = nt.isXML = function(e) {
            var t = e && (e.ownerDocument || e).documentElement;
            return t ? t.nodeName !== "HTML" : !1
        }
        ,
        u = nt.contains = y.contains ? function(e, t) {
            var n = e.nodeType === 9 ? e.documentElement : e
              , r = t && t.parentNode;
            return e === r || !!(r && r.nodeType === 1 && n.contains && n.contains(r))
        }
        : y.compareDocumentPosition ? function(e, t) {
            return t && !!(e.compareDocumentPosition(t) & 16)
        }
        : function(e, t) {
            while (t = t.parentNode)
                if (t === e)
                    return !0;
            return !1
        }
        ,
        nt.attr = function(e, t) {
            var n, r = o(e);
            return r || (t = t.toLowerCase()),
            (n = i.attrHandle[t]) ? n(e) : r || Y ? e.getAttribute(t) : (n = e.getAttributeNode(t),
            n ? typeof e[t] == "boolean" ? e[t] ? t : null : n.specified ? n.value : null : null)
        }
        ,
        i = nt.selectors = {
            cacheLength: 50,
            createPseudo: N,
            match: J,
            attrHandle: G ? {} : {
                href: function(e) {
                    return e.getAttribute("href", 2)
                },
                type: function(e) {
                    return e.getAttribute("type")
                }
            },
            find: {
                ID: r ? function(e, t, n) {
                    if (typeof t.getElementById !== p && !n) {
                        var r = t.getElementById(e);
                        return r && r.parentNode ? [r] : []
                    }
                }
                : function(e, n, r) {
                    if (typeof n.getElementById !== p && !r) {
                        var i = n.getElementById(e);
                        return i ? i.id === e || typeof i.getAttributeNode !== p && i.getAttributeNode("id").value === e ? [i] : t : []
                    }
                }
                ,
                TAG: Q ? function(e, t) {
                    if (typeof t.getElementsByTagName !== p)
                        return t.getElementsByTagName(e)
                }
                : function(e, t) {
                    var n = t.getElementsByTagName(e);
                    if (e === "*") {
                        var r, i = [], s = 0;
                        for (; r = n[s]; s++)
                            r.nodeType === 1 && i.push(r);
                        return i
                    }
                    return n
                }
                ,
                NAME: et && function(e, t) {
                    if (typeof t.getElementsByName !== p)
                        return t.getElementsByName(name)
                }
                ,
                CLASS: Z && function(e, t, n) {
                    if (typeof t.getElementsByClassName !== p && !n)
                        return t.getElementsByClassName(e)
                }
            },
            relative: {
                ">": {
                    dir: "parentNode",
                    first: !0
                },
                " ": {
                    dir: "parentNode"
                },
                "+": {
                    dir: "previousSibling",
                    first: !0
                },
                "~": {
                    dir: "previousSibling"
                }
            },
            preFilter: {
                ATTR: function(e) {
                    return e[1] = e[1].replace($, ""),
                    e[3] = (e[4] || e[5] || "").replace($, ""),
                    e[2] === "~=" && (e[3] = " " + e[3] + " "),
                    e.slice(0, 4)
                },
                CHILD: function(e) {
                    return e[1] = e[1].toLowerCase(),
                    e[1] === "nth" ? (e[2] || nt.error(e[0]),
                    e[3] = +(e[3] ? e[4] + (e[5] || 1) : 2 * (e[2] === "even" || e[2] === "odd")),
                    e[4] = +(e[6] + e[7] || e[2] === "odd")) : e[2] && nt.error(e[0]),
                    e
                },
                PSEUDO: function(e) {
                    var t, n;
                    if (J.CHILD.test(e[0]))
                        return null;
                    if (e[3])
                        e[2] = e[3];
                    else if (t = e[4])
                        q.test(t) && (n = ut(t, !0)) && (n = t.indexOf(")", t.length - n) - t.length) && (t = t.slice(0, n),
                        e[0] = e[0].slice(0, n)),
                        e[2] = t;
                    return e.slice(0, 3)
                }
            },
            filter: {
                ID: r ? function(e) {
                    return e = e.replace($, ""),
                    function(t) {
                        return t.getAttribute("id") === e
                    }
                }
                : function(e) {
                    return e = e.replace($, ""),
                    function(t) {
                        var n = typeof t.getAttributeNode !== p && t.getAttributeNode("id");
                        return n && n.value === e
                    }
                }
                ,
                TAG: function(e) {
                    return e === "*" ? function() {
                        return !0
                    }
                    : (e = e.replace($, "").toLowerCase(),
                    function(t) {
                        return t.nodeName && t.nodeName.toLowerCase() === e
                    }
                    )
                },
                CLASS: function(e) {
                    var t = k[d][e + " "];
                    return t || (t = new RegExp("(^|" + O + ")" + e + "(" + O + "|$)")) && k(e, function(e) {
                        return t.test(e.className || typeof e.getAttribute !== p && e.getAttribute("class") || "")
                    })
                },
                ATTR: function(e, t, n) {
                    return function(r, i) {
                        var s = nt.attr(r, e);
                        return s == null ? t === "!=" : t ? (s += "",
                        t === "=" ? s === n : t === "!=" ? s !== n : t === "^=" ? n && s.indexOf(n) === 0 : t === "*=" ? n && s.indexOf(n) > -1 : t === "$=" ? n && s.substr(s.length - n.length) === n : t === "~=" ? (" " + s + " ").indexOf(n) > -1 : t === "|=" ? s === n || s.substr(0, n.length + 1) === n + "-" : !1) : !0
                    }
                },
                CHILD: function(e, t, n, r) {
                    return e === "nth" ? function(e) {
                        var t, i, s = e.parentNode;
                        if (n === 1 && r === 0)
                            return !0;
                        if (s) {
                            i = 0;
                            for (t = s.firstChild; t; t = t.nextSibling)
                                if (t.nodeType === 1) {
                                    i++;
                                    if (e === t)
                                        break
                                }
                        }
                        return i -= r,
                        i === n || i % n === 0 && i / n >= 0
                    }
                    : function(t) {
                        var n = t;
                        switch (e) {
                        case "only":
                        case "first":
                            while (n = n.previousSibling)
                                if (n.nodeType === 1)
                                    return !1;
                            if (e === "first")
                                return !0;
                            n = t;
                        case "last":
                            while (n = n.nextSibling)
                                if (n.nodeType === 1)
                                    return !1;
                            return !0
                        }
                    }
                },
                PSEUDO: function(e, t) {
                    var n, r = i.pseudos[e] || i.setFilters[e.toLowerCase()] || nt.error("unsupported pseudo: " + e);
                    return r[d] ? r(t) : r.length > 1 ? (n = [e, e, "", t],
                    i.setFilters.hasOwnProperty(e.toLowerCase()) ? N(function(e, n) {
                        var i, s = r(e, t), o = s.length;
                        while (o--)
                            i = T.call(e, s[o]),
                            e[i] = !(n[i] = s[o])
                    }) : function(e) {
                        return r(e, 0, n)
                    }
                    ) : r
                }
            },
            pseudos: {
                not: N(function(e) {
                    var t = []
                      , n = []
                      , r = a(e.replace(j, "$1"));
                    return r[d] ? N(function(e, t, n, i) {
                        var s, o = r(e, null, i, []), u = e.length;
                        while (u--)
                            if (s = o[u])
                                e[u] = !(t[u] = s)
                    }) : function(e, i, s) {
                        return t[0] = e,
                        r(t, null, s, n),
                        !n.pop()
                    }
                }),
                has: N(function(e) {
                    return function(t) {
                        return nt(e, t).length > 0
                    }
                }),
                contains: N(function(e) {
                    return function(t) {
                        return (t.textContent || t.innerText || s(t)).indexOf(e) > -1
                    }
                }),
                enabled: function(e) {
                    return e.disabled === !1
                },
                disabled: function(e) {
                    return e.disabled === !0
                },
                checked: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return t === "input" && !!e.checked || t === "option" && !!e.selected
                },
                selected: function(e) {
                    return e.parentNode && e.parentNode.selectedIndex,
                    e.selected === !0
                },
                parent: function(e) {
                    return !i.pseudos.empty(e)
                },
                empty: function(e) {
                    var t;
                    e = e.firstChild;
                    while (e) {
                        if (e.nodeName > "@" || (t = e.nodeType) === 3 || t === 4)
                            return !1;
                        e = e.nextSibling
                    }
                    return !0
                },
                header: function(e) {
                    return X.test(e.nodeName)
                },
                text: function(e) {
                    var t, n;
                    return e.nodeName.toLowerCase() === "input" && (t = e.type) === "text" && ((n = e.getAttribute("type")) == null || n.toLowerCase() === t)
                },
                radio: rt("radio"),
                checkbox: rt("checkbox"),
                file: rt("file"),
                password: rt("password"),
                image: rt("image"),
                submit: it("submit"),
                reset: it("reset"),
                button: function(e) {
                    var t = e.nodeName.toLowerCase();
                    return t === "input" && e.type === "button" || t === "button"
                },
                input: function(e) {
                    return V.test(e.nodeName)
                },
                focus: function(e) {
                    var t = e.ownerDocument;
                    return e === t.activeElement && (!t.hasFocus || t.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                },
                active: function(e) {
                    return e === e.ownerDocument.activeElement
                },
                first: st(function() {
                    return [0]
                }),
                last: st(function(e, t) {
                    return [t - 1]
                }),
                eq: st(function(e, t, n) {
                    return [n < 0 ? n + t : n]
                }),
                even: st(function(e, t) {
                    for (var n = 0; n < t; n += 2)
                        e.push(n);
                    return e
                }),
                odd: st(function(e, t) {
                    for (var n = 1; n < t; n += 2)
                        e.push(n);
                    return e
                }),
                lt: st(function(e, t, n) {
                    for (var r = n < 0 ? n + t : n; --r >= 0; )
                        e.push(r);
                    return e
                }),
                gt: st(function(e, t, n) {
                    for (var r = n < 0 ? n + t : n; ++r < t; )
                        e.push(r);
                    return e
                })
            }
        },
        f = y.compareDocumentPosition ? function(e, t) {
            return e === t ? (l = !0,
            0) : (!e.compareDocumentPosition || !t.compareDocumentPosition ? e.compareDocumentPosition : e.compareDocumentPosition(t) & 4) ? -1 : 1
        }
        : function(e, t) {
            if (e === t)
                return l = !0,
                0;
            if (e.sourceIndex && t.sourceIndex)
                return e.sourceIndex - t.sourceIndex;
            var n, r, i = [], s = [], o = e.parentNode, u = t.parentNode, a = o;
            if (o === u)
                return ot(e, t);
            if (!o)
                return -1;
            if (!u)
                return 1;
            while (a)
                i.unshift(a),
                a = a.parentNode;
            a = u;
            while (a)
                s.unshift(a),
                a = a.parentNode;
            n = i.length,
            r = s.length;
            for (var f = 0; f < n && f < r; f++)
                if (i[f] !== s[f])
                    return ot(i[f], s[f]);
            return f === n ? ot(e, s[f], -1) : ot(i[f], t, 1)
        }
        ,
        [0, 0].sort(f),
        h = !l,
        nt.uniqueSort = function(e) {
            var t, n = [], r = 1, i = 0;
            l = h,
            e.sort(f);
            if (l) {
                for (; t = e[r]; r++)
                    t === e[r - 1] && (i = n.push(r));
                while (i--)
                    e.splice(n[i], 1)
            }
            return e
        }
        ,
        nt.error = function(e) {
            throw new Error("Syntax error, unrecognized expression: " + e)
        }
        ,
        a = nt.compile = function(e, t) {
            var n, r = [], i = [], s = A[d][e + " "];
            if (!s) {
                t || (t = ut(e)),
                n = t.length;
                while (n--)
                    s = ht(t[n]),
                    s[d] ? r.push(s) : i.push(s);
                s = A(e, pt(i, r))
            }
            return s
        }
        ,
        g.querySelectorAll && function() {
            var e, t = vt, n = /'|\\/g, r = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g, i = [":focus"], s = [":active"], u = y.matchesSelector || y.mozMatchesSelector || y.webkitMatchesSelector || y.oMatchesSelector || y.msMatchesSelector;
            K(function(e) {
                e.innerHTML = "<select><option selected=''></option></select>",
                e.querySelectorAll("[selected]").length || i.push("\\[" + O + "*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),
                e.querySelectorAll(":checked").length || i.push(":checked")
            }),
            K(function(e) {
                e.innerHTML = "<p test=''></p>",
                e.querySelectorAll("[test^='']").length && i.push("[*^$]=" + O + "*(?:\"\"|'')"),
                e.innerHTML = "<input type='hidden'/>",
                e.querySelectorAll(":enabled").length || i.push(":enabled", ":disabled")
            }),
            i = new RegExp(i.join("|")),
            vt = function(e, r, s, o, u) {
                if (!o && !u && !i.test(e)) {
                    var a, f, l = !0, c = d, h = r, p = r.nodeType === 9 && e;
                    if (r.nodeType === 1 && r.nodeName.toLowerCase() !== "object") {
                        a = ut(e),
                        (l = r.getAttribute("id")) ? c = l.replace(n, "\\$&") : r.setAttribute("id", c),
                        c = "[id='" + c + "'] ",
                        f = a.length;
                        while (f--)
                            a[f] = c + a[f].join("");
                        h = z.test(e) && r.parentNode || r,
                        p = a.join(",")
                    }
                    if (p)
                        try {
                            return S.apply(s, x.call(h.querySelectorAll(p), 0)),
                            s
                        } catch (v) {} finally {
                            l || r.removeAttribute("id")
                        }
                }
                return t(e, r, s, o, u)
            }
            ,
            u && (K(function(t) {
                e = u.call(t, "div");
                try {
                    u.call(t, "[test!='']:sizzle"),
                    s.push("!=", H)
                } catch (n) {}
            }),
            s = new RegExp(s.join("|")),
            nt.matchesSelector = function(t, n) {
                n = n.replace(r, "='$1']");
                if (!o(t) && !s.test(n) && !i.test(n))
                    try {
                        var a = u.call(t, n);
                        if (a || e || t.document && t.document.nodeType !== 11)
                            return a
                    } catch (f) {}
                return nt(n, null, null, [t]).length > 0
            }
            )
        }(),
        i.pseudos.nth = i.pseudos.eq,
        i.filters = mt.prototype = i.pseudos,
        i.setFilters = new mt,
        nt.attr = v.attr,
        v.find = nt,
        v.expr = nt.selectors,
        v.expr[":"] = v.expr.pseudos,
        v.unique = nt.uniqueSort,
        v.text = nt.getText,
        v.isXMLDoc = nt.isXML,
        v.contains = nt.contains
    }(e);
    var nt = /Until$/
      , rt = /^(?:parents|prev(?:Until|All))/
      , it = /^.[^:#\[\.,]*$/
      , st = v.expr.match.needsContext
      , ot = {
        children: !0,
        contents: !0,
        next: !0,
        prev: !0
    };
    v.fn.extend({
        find: function(e) {
            var t, n, r, i, s, o, u = this;
            if (typeof e != "string")
                return v(e).filter(function() {
                    for (t = 0,
                    n = u.length; t < n; t++)
                        if (v.contains(u[t], this))
                            return !0
                });
            o = this.pushStack("", "find", e);
            for (t = 0,
            n = this.length; t < n; t++) {
                r = o.length,
                v.find(e, this[t], o);
                if (t > 0)
                    for (i = r; i < o.length; i++)
                        for (s = 0; s < r; s++)
                            if (o[s] === o[i]) {
                                o.splice(i--, 1);
                                break
                            }
            }
            return o
        },
        has: function(e) {
            var t, n = v(e, this), r = n.length;
            return this.filter(function() {
                for (t = 0; t < r; t++)
                    if (v.contains(this, n[t]))
                        return !0
            })
        },
        not: function(e) {
            return this.pushStack(ft(this, e, !1), "not", e)
        },
        filter: function(e) {
            return this.pushStack(ft(this, e, !0), "filter", e)
        },
        is: function(e) {
            return !!e && (typeof e == "string" ? st.test(e) ? v(e, this.context).index(this[0]) >= 0 : v.filter(e, this).length > 0 : this.filter(e).length > 0)
        },
        closest: function(e, t) {
            var n, r = 0, i = this.length, s = [], o = st.test(e) || typeof e != "string" ? v(e, t || this.context) : 0;
            for (; r < i; r++) {
                n = this[r];
                while (n && n.ownerDocument && n !== t && n.nodeType !== 11) {
                    if (o ? o.index(n) > -1 : v.find.matchesSelector(n, e)) {
                        s.push(n);
                        break
                    }
                    n = n.parentNode
                }
            }
            return s = s.length > 1 ? v.unique(s) : s,
            this.pushStack(s, "closest", e)
        },
        index: function(e) {
            return e ? typeof e == "string" ? v.inArray(this[0], v(e)) : v.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.prevAll().length : -1
        },
        add: function(e, t) {
            var n = typeof e == "string" ? v(e, t) : v.makeArray(e && e.nodeType ? [e] : e)
              , r = v.merge(this.get(), n);
            return this.pushStack(ut(n[0]) || ut(r[0]) ? r : v.unique(r))
        },
        addBack: function(e) {
            return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
        }
    }),
    v.fn.andSelf = v.fn.addBack,
    v.each({
        parent: function(e) {
            var t = e.parentNode;
            return t && t.nodeType !== 11 ? t : null
        },
        parents: function(e) {
            return v.dir(e, "parentNode")
        },
        parentsUntil: function(e, t, n) {
            return v.dir(e, "parentNode", n)
        },
        next: function(e) {
            return at(e, "nextSibling")
        },
        prev: function(e) {
            return at(e, "previousSibling")
        },
        nextAll: function(e) {
            return v.dir(e, "nextSibling")
        },
        prevAll: function(e) {
            return v.dir(e, "previousSibling")
        },
        nextUntil: function(e, t, n) {
            return v.dir(e, "nextSibling", n)
        },
        prevUntil: function(e, t, n) {
            return v.dir(e, "previousSibling", n)
        },
        siblings: function(e) {
            return v.sibling((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return v.sibling(e.firstChild)
        },
        contents: function(e) {
            return v.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : v.merge([], e.childNodes)
        }
    }, function(e, t) {
        v.fn[e] = function(n, r) {
            var i = v.map(this, t, n);
            return nt.test(e) || (r = n),
            r && typeof r == "string" && (i = v.filter(r, i)),
            i = this.length > 1 && !ot[e] ? v.unique(i) : i,
            this.length > 1 && rt.test(e) && (i = i.reverse()),
            this.pushStack(i, e, l.call(arguments).join(","))
        }
    }),
    v.extend({
        filter: function(e, t, n) {
            return n && (e = ":not(" + e + ")"),
            t.length === 1 ? v.find.matchesSelector(t[0], e) ? [t[0]] : [] : v.find.matches(e, t)
        },
        dir: function(e, n, r) {
            var i = []
              , s = e[n];
            while (s && s.nodeType !== 9 && (r === t || s.nodeType !== 1 || !v(s).is(r)))
                s.nodeType === 1 && i.push(s),
                s = s[n];
            return i
        },
        sibling: function(e, t) {
            var n = [];
            for (; e; e = e.nextSibling)
                e.nodeType === 1 && e !== t && n.push(e);
            return n
        }
    });
    var ct = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video"
      , ht = / jQuery\d+="(?:null|\d+)"/g
      , pt = /^\s+/
      , dt = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi
      , vt = /<([\w:]+)/
      , mt = /<tbody/i
      , gt = /<|&#?\w+;/
      , yt = /<(?:script|style|link)/i
      , bt = /<(?:script|object|embed|option|style)/i
      , wt = new RegExp("<(?:" + ct + ")[\\s/>]","i")
      , Et = /^(?:checkbox|radio)$/
      , St = /checked\s*(?:[^=]|=\s*.checked.)/i
      , xt = /\/(java|ecma)script/i
      , Tt = /^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g
      , Nt = {
        option: [1, "<select multiple='multiple'>", "</select>"],
        legend: [1, "<fieldset>", "</fieldset>"],
        thead: [1, "<table>", "</table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
        area: [1, "<map>", "</map>"],
        _default: [0, "", ""]
    }
      , Ct = lt(i)
      , kt = Ct.appendChild(i.createElement("div"));
    Nt.optgroup = Nt.option,
    Nt.tbody = Nt.tfoot = Nt.colgroup = Nt.caption = Nt.thead,
    Nt.th = Nt.td,
    v.support.htmlSerialize || (Nt._default = [1, "X<div>", "</div>"]),
    v.fn.extend({
        text: function(e) {
            return v.access(this, function(e) {
                return e === t ? v.text(this) : this.empty().append((this[0] && this[0].ownerDocument || i).createTextNode(e))
            }, null, e, arguments.length)
        },
        wrapAll: function(e) {
            if (v.isFunction(e))
                return this.each(function(t) {
                    v(this).wrapAll(e.call(this, t))
                });
            if (this[0]) {
                var t = v(e, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && t.insertBefore(this[0]),
                t.map(function() {
                    var e = this;
                    while (e.firstChild && e.firstChild.nodeType === 1)
                        e = e.firstChild;
                    return e
                }).append(this)
            }
            return this
        },
        wrapInner: function(e) {
            return v.isFunction(e) ? this.each(function(t) {
                v(this).wrapInner(e.call(this, t))
            }) : this.each(function() {
                var t = v(this)
                  , n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            })
        },
        wrap: function(e) {
            var t = v.isFunction(e);
            return this.each(function(n) {
                v(this).wrapAll(t ? e.call(this, n) : e)
            })
        },
        unwrap: function() {
            return this.parent().each(function() {
                v.nodeName(this, "body") || v(this).replaceWith(this.childNodes)
            }).end()
        },
        append: function() {
            return this.domManip(arguments, !0, function(e) {
                (this.nodeType === 1 || this.nodeType === 11) && this.appendChild(e)
            })
        },
        prepend: function() {
            return this.domManip(arguments, !0, function(e) {
                (this.nodeType === 1 || this.nodeType === 11) && this.insertBefore(e, this.firstChild)
            })
        },
        before: function() {
            if (!ut(this[0]))
                return this.domManip(arguments, !1, function(e) {
                    this.parentNode.insertBefore(e, this)
                });
            if (arguments.length) {
                var e = v.clean(arguments);
                return this.pushStack(v.merge(e, this), "before", this.selector)
            }
        },
        after: function() {
            if (!ut(this[0]))
                return this.domManip(arguments, !1, function(e) {
                    this.parentNode.insertBefore(e, this.nextSibling)
                });
            if (arguments.length) {
                var e = v.clean(arguments);
                return this.pushStack(v.merge(this, e), "after", this.selector)
            }
        },
        remove: function(e, t) {
            var n, r = 0;
            for (; (n = this[r]) != null; r++)
                if (!e || v.filter(e, [n]).length)
                    !t && n.nodeType === 1 && (v.cleanData(n.getElementsByTagName("*")),
                    v.cleanData([n])),
                    n.parentNode && n.parentNode.removeChild(n);
            return this
        },
        empty: function() {
            var e, t = 0;
            for (; (e = this[t]) != null; t++) {
                e.nodeType === 1 && v.cleanData(e.getElementsByTagName("*"));
                while (e.firstChild)
                    e.removeChild(e.firstChild)
            }
            return this
        },
        clone: function(e, t) {
            return e = e == null ? !1 : e,
            t = t == null ? e : t,
            this.map(function() {
                return v.clone(this, e, t)
            })
        },
        html: function(e) {
            return v.access(this, function(e) {
                var n = this[0] || {}
                  , r = 0
                  , i = this.length;
                if (e === t)
                    return n.nodeType === 1 ? n.innerHTML.replace(ht, "") : t;
                if (typeof e == "string" && !yt.test(e) && (v.support.htmlSerialize || !wt.test(e)) && (v.support.leadingWhitespace || !pt.test(e)) && !Nt[(vt.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = e.replace(dt, "<$1></$2>");
                    try {
                        for (; r < i; r++)
                            n = this[r] || {},
                            n.nodeType === 1 && (v.cleanData(n.getElementsByTagName("*")),
                            n.innerHTML = e);
                        n = 0
                    } catch (s) {}
                }
                n && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function(e) {
            return ut(this[0]) ? this.length ? this.pushStack(v(v.isFunction(e) ? e() : e), "replaceWith", e) : this : v.isFunction(e) ? this.each(function(t) {
                var n = v(this)
                  , r = n.html();
                n.replaceWith(e.call(this, t, r))
            }) : (typeof e != "string" && (e = v(e).detach()),
            this.each(function() {
                var t = this.nextSibling
                  , n = this.parentNode;
                v(this).remove(),
                t ? v(t).before(e) : v(n).append(e)
            }))
        },
        detach: function(e) {
            return this.remove(e, !0)
        },
        domManip: function(e, n, r) {
            e = [].concat.apply([], e);
            var i, s, o, u, a = 0, f = e[0], l = [], c = this.length;
            if (!v.support.checkClone && c > 1 && typeof f == "string" && St.test(f))
                return this.each(function() {
                    v(this).domManip(e, n, r)
                });
            if (v.isFunction(f))
                return this.each(function(i) {
                    var s = v(this);
                    e[0] = f.call(this, i, n ? s.html() : t),
                    s.domManip(e, n, r)
                });
            if (this[0]) {
                i = v.buildFragment(e, this, l),
                o = i.fragment,
                s = o.firstChild,
                o.childNodes.length === 1 && (o = s);
                if (s) {
                    n = n && v.nodeName(s, "tr");
                    for (u = i.cacheable || c - 1; a < c; a++)
                        r.call(n && v.nodeName(this[a], "table") ? Lt(this[a], "tbody") : this[a], a === u ? o : v.clone(o, !0, !0))
                }
                o = s = null,
                l.length && v.each(l, function(e, t) {
                    t.src ? v.ajax ? v.ajax({
                        url: t.src,
                        type: "GET",
                        dataType: "script",
                        async: !1,
                        global: !1,
                        "throws": !0
                    }) : v.error("no ajax") : v.globalEval((t.text || t.textContent || t.innerHTML || "").replace(Tt, "")),
                    t.parentNode && t.parentNode.removeChild(t)
                })
            }
            return this
        }
    }),
    v.buildFragment = function(e, n, r) {
        var s, o, u, a = e[0];
        return n = n || i,
        n = !n.nodeType && n[0] || n,
        n = n.ownerDocument || n,
        e.length === 1 && typeof a == "string" && a.length < 512 && n === i && a.charAt(0) === "<" && !bt.test(a) && (v.support.checkClone || !St.test(a)) && (v.support.html5Clone || !wt.test(a)) && (o = !0,
        s = v.fragments[a],
        u = s !== t),
        s || (s = n.createDocumentFragment(),
        v.clean(e, n, s, r),
        o && (v.fragments[a] = u && s)),
        {
            fragment: s,
            cacheable: o
        }
    }
    ,
    v.fragments = {},
    v.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(e, t) {
        v.fn[e] = function(n) {
            var r, i = 0, s = [], o = v(n), u = o.length, a = this.length === 1 && this[0].parentNode;
            if ((a == null || a && a.nodeType === 11 && a.childNodes.length === 1) && u === 1)
                return o[t](this[0]),
                this;
            for (; i < u; i++)
                r = (i > 0 ? this.clone(!0) : this).get(),
                v(o[i])[t](r),
                s = s.concat(r);
            return this.pushStack(s, e, o.selector)
        }
    }),
    v.extend({
        clone: function(e, t, n) {
            var r, i, s, o;
            v.support.html5Clone || v.isXMLDoc(e) || !wt.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (kt.innerHTML = e.outerHTML,
            kt.removeChild(o = kt.firstChild));
            if ((!v.support.noCloneEvent || !v.support.noCloneChecked) && (e.nodeType === 1 || e.nodeType === 11) && !v.isXMLDoc(e)) {
                Ot(e, o),
                r = Mt(e),
                i = Mt(o);
                for (s = 0; r[s]; ++s)
                    i[s] && Ot(r[s], i[s])
            }
            if (t) {
                At(e, o);
                if (n) {
                    r = Mt(e),
                    i = Mt(o);
                    for (s = 0; r[s]; ++s)
                        At(r[s], i[s])
                }
            }
            return r = i = null,
            o
        },
        clean: function(e, t, n, r) {
            var s, o, u, a, f, l, c, h, p, d, m, g, y = t === i && Ct, b = [];
            if (!t || typeof t.createDocumentFragment == "undefined")
                t = i;
            for (s = 0; (u = e[s]) != null; s++) {
                typeof u == "number" && (u += "");
                if (!u)
                    continue;
                if (typeof u == "string")
                    if (!gt.test(u))
                        u = t.createTextNode(u);
                    else {
                        y = y || lt(t),
                        c = t.createElement("div"),
                        y.appendChild(c),
                        u = u.replace(dt, "<$1></$2>"),
                        a = (vt.exec(u) || ["", ""])[1].toLowerCase(),
                        f = Nt[a] || Nt._default,
                        l = f[0],
                        c.innerHTML = f[1] + u + f[2];
                        while (l--)
                            c = c.lastChild;
                        if (!v.support.tbody) {
                            h = mt.test(u),
                            p = a === "table" && !h ? c.firstChild && c.firstChild.childNodes : f[1] === "<table>" && !h ? c.childNodes : [];
                            for (o = p.length - 1; o >= 0; --o)
                                v.nodeName(p[o], "tbody") && !p[o].childNodes.length && p[o].parentNode.removeChild(p[o])
                        }
                        !v.support.leadingWhitespace && pt.test(u) && c.insertBefore(t.createTextNode(pt.exec(u)[0]), c.firstChild),
                        u = c.childNodes,
                        c.parentNode.removeChild(c)
                    }
                u.nodeType ? b.push(u) : v.merge(b, u)
            }
            c && (u = c = y = null);
            if (!v.support.appendChecked)
                for (s = 0; (u = b[s]) != null; s++)
                    v.nodeName(u, "input") ? _t(u) : typeof u.getElementsByTagName != "undefined" && v.grep(u.getElementsByTagName("input"), _t);
            if (n) {
                m = function(e) {
                    if (!e.type || xt.test(e.type))
                        return r ? r.push(e.parentNode ? e.parentNode.removeChild(e) : e) : n.appendChild(e)
                }
                ;
                for (s = 0; (u = b[s]) != null; s++)
                    if (!v.nodeName(u, "script") || !m(u))
                        n.appendChild(u),
                        typeof u.getElementsByTagName != "undefined" && (g = v.grep(v.merge([], u.getElementsByTagName("script")), m),
                        b.splice.apply(b, [s + 1, 0].concat(g)),
                        s += g.length)
            }
            return b
        },
        cleanData: function(e, t) {
            var n, r, i, s, o = 0, u = v.expando, a = v.cache, f = v.support.deleteExpando, l = v.event.special;
            for (; (i = e[o]) != null; o++)
                if (t || v.acceptData(i)) {
                    r = i[u],
                    n = r && a[r];
                    if (n) {
                        if (n.events)
                            for (s in n.events)
                                l[s] ? v.event.remove(i, s) : v.removeEvent(i, s, n.handle);
                        a[r] && (delete a[r],
                        f ? delete i[u] : i.removeAttribute ? i.removeAttribute(u) : i[u] = null,
                        v.deletedIds.push(r))
                    }
                }
        }
    }),
    function() {
        var e, t;
        v.uaMatch = function(e) {
            e = e.toLowerCase();
            var t = /(chrome)[ \/]([\w.]+)/.exec(e) || /(webkit)[ \/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(msie) ([\w.]+)/.exec(e) || e.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e) || [];
            return {
                browser: t[1] || "",
                version: t[2] || "0"
            }
        }
        ,
        e = v.uaMatch(o.userAgent),
        t = {},
        e.browser && (t[e.browser] = !0,
        t.version = e.version),
        t.chrome ? t.webkit = !0 : t.webkit && (t.safari = !0),
        v.browser = t,
        v.sub = function() {
            function e(t, n) {
                return new e.fn.init(t,n)
            }
            v.extend(!0, e, this),
            e.superclass = this,
            e.fn = e.prototype = this(),
            e.fn.constructor = e,
            e.sub = this.sub,
            e.fn.init = function(r, i) {
                return i && i instanceof v && !(i instanceof e) && (i = e(i)),
                v.fn.init.call(this, r, i, t)
            }
            ,
            e.fn.init.prototype = e.fn;
            var t = e(i);
            return e
        }
    }();
    var Dt, Pt, Ht, Bt = /alpha\([^)]*\)/i, jt = /opacity=([^)]*)/, Ft = /^(top|right|bottom|left)$/, It = /^(none|table(?!-c[ea]).+)/, qt = /^margin/, Rt = new RegExp("^(" + m + ")(.*)$","i"), Ut = new RegExp("^(" + m + ")(?!px)[a-z%]+$","i"), zt = new RegExp("^([-+])=(" + m + ")","i"), Wt = {
        BODY: "block"
    }, Xt = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    }, Vt = {
        letterSpacing: 0,
        fontWeight: 400
    }, $t = ["Top", "Right", "Bottom", "Left"], Jt = ["Webkit", "O", "Moz", "ms"], Kt = v.fn.toggle;
    v.fn.extend({
        css: function(e, n) {
            return v.access(this, function(e, n, r) {
                return r !== t ? v.style(e, n, r) : v.css(e, n)
            }, e, n, arguments.length > 1)
        },
        show: function() {
            return Yt(this, !0)
        },
        hide: function() {
            return Yt(this)
        },
        toggle: function(e, t) {
            var n = typeof e == "boolean";
            return v.isFunction(e) && v.isFunction(t) ? Kt.apply(this, arguments) : this.each(function() {
                (n ? e : Gt(this)) ? v(this).show() : v(this).hide()
            })
        }
    }),
    v.extend({
        cssHooks: {
            opacity: {
                get: function(e, t) {
                    if (t) {
                        var n = Dt(e, "opacity");
                        return n === "" ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": v.support.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function(e, n, r, i) {
            if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style)
                return;
            var s, o, u, a = v.camelCase(n), f = e.style;
            n = v.cssProps[a] || (v.cssProps[a] = Qt(f, a)),
            u = v.cssHooks[n] || v.cssHooks[a];
            if (r === t)
                return u && "get"in u && (s = u.get(e, !1, i)) !== t ? s : f[n];
            o = typeof r,
            o === "string" && (s = zt.exec(r)) && (r = (s[1] + 1) * s[2] + parseFloat(v.css(e, n)),
            o = "number");
            if (r == null || o === "number" && isNaN(r))
                return;
            o === "number" && !v.cssNumber[a] && (r += "px");
            if (!u || !("set"in u) || (r = u.set(e, r, i)) !== t)
                try {
                    f[n] = r
                } catch (l) {}
        },
        css: function(e, n, r, i) {
            var s, o, u, a = v.camelCase(n);
            return n = v.cssProps[a] || (v.cssProps[a] = Qt(e.style, a)),
            u = v.cssHooks[n] || v.cssHooks[a],
            u && "get"in u && (s = u.get(e, !0, i)),
            s === t && (s = Dt(e, n)),
            s === "normal" && n in Vt && (s = Vt[n]),
            r || i !== t ? (o = parseFloat(s),
            r || v.isNumeric(o) ? o || 0 : s) : s
        },
        swap: function(e, t, n) {
            var r, i, s = {};
            for (i in t)
                s[i] = e.style[i],
                e.style[i] = t[i];
            r = n.call(e);
            for (i in t)
                e.style[i] = s[i];
            return r
        }
    }),
    e.getComputedStyle ? Dt = function(t, n) {
        var r, i, s, o, u = e.getComputedStyle(t, null), a = t.style;
        return u && (r = u.getPropertyValue(n) || u[n],
        r === "" && !v.contains(t.ownerDocument, t) && (r = v.style(t, n)),
        Ut.test(r) && qt.test(n) && (i = a.width,
        s = a.minWidth,
        o = a.maxWidth,
        a.minWidth = a.maxWidth = a.width = r,
        r = u.width,
        a.width = i,
        a.minWidth = s,
        a.maxWidth = o)),
        r
    }
    : i.documentElement.currentStyle && (Dt = function(e, t) {
        var n, r, i = e.currentStyle && e.currentStyle[t], s = e.style;
        return i == null && s && s[t] && (i = s[t]),
        Ut.test(i) && !Ft.test(t) && (n = s.left,
        r = e.runtimeStyle && e.runtimeStyle.left,
        r && (e.runtimeStyle.left = e.currentStyle.left),
        s.left = t === "fontSize" ? "1em" : i,
        i = s.pixelLeft + "px",
        s.left = n,
        r && (e.runtimeStyle.left = r)),
        i === "" ? "auto" : i
    }
    ),
    v.each(["height", "width"], function(e, t) {
        v.cssHooks[t] = {
            get: function(e, n, r) {
                if (n)
                    return e.offsetWidth === 0 && It.test(Dt(e, "display")) ? v.swap(e, Xt, function() {
                        return tn(e, t, r)
                    }) : tn(e, t, r)
            },
            set: function(e, n, r) {
                return Zt(e, n, r ? en(e, t, r, v.support.boxSizing && v.css(e, "boxSizing") === "border-box") : 0)
            }
        }
    }),
    v.support.opacity || (v.cssHooks.opacity = {
        get: function(e, t) {
            return jt.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
        },
        set: function(e, t) {
            var n = e.style
              , r = e.currentStyle
              , i = v.isNumeric(t) ? "alpha(opacity=" + t * 100 + ")" : ""
              , s = r && r.filter || n.filter || "";
            n.zoom = 1;
            if (t >= 1 && v.trim(s.replace(Bt, "")) === "" && n.removeAttribute) {
                n.removeAttribute("filter");
                if (r && !r.filter)
                    return
            }
            n.filter = Bt.test(s) ? s.replace(Bt, i) : s + " " + i
        }
    }),
    v(function() {
        v.support.reliableMarginRight || (v.cssHooks.marginRight = {
            get: function(e, t) {
                return v.swap(e, {
                    display: "inline-block"
                }, function() {
                    if (t)
                        return Dt(e, "marginRight")
                })
            }
        }),
        !v.support.pixelPosition && v.fn.position && v.each(["top", "left"], function(e, t) {
            v.cssHooks[t] = {
                get: function(e, n) {
                    if (n) {
                        var r = Dt(e, t);
                        return Ut.test(r) ? v(e).position()[t] + "px" : r
                    }
                }
            }
        })
    }),
    v.expr && v.expr.filters && (v.expr.filters.hidden = function(e) {
        return e.offsetWidth === 0 && e.offsetHeight === 0 || !v.support.reliableHiddenOffsets && (e.style && e.style.display || Dt(e, "display")) === "none"
    }
    ,
    v.expr.filters.visible = function(e) {
        return !v.expr.filters.hidden(e)
    }
    ),
    v.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(e, t) {
        v.cssHooks[e + t] = {
            expand: function(n) {
                var r, i = typeof n == "string" ? n.split(" ") : [n], s = {};
                for (r = 0; r < 4; r++)
                    s[e + $t[r] + t] = i[r] || i[r - 2] || i[0];
                return s
            }
        },
        qt.test(e) || (v.cssHooks[e + t].set = Zt)
    });
    var rn = /%20/g
      , sn = /\[\]$/
      , on = /\r?\n/g
      , un = /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i
      , an = /^(?:select|textarea)/i;
    v.fn.extend({
        serialize: function() {
            return v.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                return this.elements ? v.makeArray(this.elements) : this
            }).filter(function() {
                return this.name && !this.disabled && (this.checked || an.test(this.nodeName) || un.test(this.type))
            }).map(function(e, t) {
                var n = v(this).val();
                return n == null ? null : v.isArray(n) ? v.map(n, function(e, n) {
                    return {
                        name: t.name,
                        value: e.replace(on, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(on, "\r\n")
                }
            }).get()
        }
    }),
    v.param = function(e, n) {
        var r, i = [], s = function(e, t) {
            t = v.isFunction(t) ? t() : t == null ? "" : t,
            i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
        };
        n === t && (n = v.ajaxSettings && v.ajaxSettings.traditional);
        if (v.isArray(e) || e.jquery && !v.isPlainObject(e))
            v.each(e, function() {
                s(this.name, this.value)
            });
        else
            for (r in e)
                fn(r, e[r], n, s);
        return i.join("&").replace(rn, "+")
    }
    ;
    var ln, cn, hn = /#.*$/, pn = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg, dn = /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/, vn = /^(?:GET|HEAD)$/, mn = /^\/\//, gn = /\?/, yn = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, bn = /([?&])_=[^&]*/, wn = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/, En = v.fn.load, Sn = {}, xn = {}, Tn = ["*/"] + ["*"];
    try {
        cn = s.href
    } catch (Nn) {
        cn = i.createElement("a"),
        cn.href = "",
        cn = cn.href
    }
    ln = wn.exec(cn.toLowerCase()) || [],
    v.fn.load = function(e, n, r) {
        if (typeof e != "string" && En)
            return En.apply(this, arguments);
        if (!this.length)
            return this;
        var i, s, o, u = this, a = e.indexOf(" ");
        return a >= 0 && (i = e.slice(a, e.length),
        e = e.slice(0, a)),
        v.isFunction(n) ? (r = n,
        n = t) : n && typeof n == "object" && (s = "POST"),
        v.ajax({
            url: e,
            type: s,
            dataType: "html",
            data: n,
            complete: function(e, t) {
                r && u.each(r, o || [e.responseText, t, e])
            }
        }).done(function(e) {
            o = arguments,
            u.html(i ? v("<div>").append(e.replace(yn, "")).find(i) : e)
        }),
        this
    }
    ,
    v.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function(e, t) {
        v.fn[t] = function(e) {
            return this.on(t, e)
        }
    }),
    v.each(["get", "post"], function(e, n) {
        v[n] = function(e, r, i, s) {
            return v.isFunction(r) && (s = s || i,
            i = r,
            r = t),
            v.ajax({
                type: n,
                url: e,
                data: r,
                success: i,
                dataType: s
            })
        }
    }),
    v.extend({
        getScript: function(e, n) {
            return v.get(e, t, n, "script")
        },
        getJSON: function(e, t, n) {
            return v.get(e, t, n, "json")
        },
        ajaxSetup: function(e, t) {
            return t ? Ln(e, v.ajaxSettings) : (t = e,
            e = v.ajaxSettings),
            Ln(e, t),
            e
        },
        ajaxSettings: {
            url: cn,
            isLocal: dn.test(ln[1]),
            global: !0,
            type: "GET",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            processData: !0,
            async: !0,
            accepts: {
                xml: "application/xml, text/xml",
                html: "text/html",
                text: "text/plain",
                json: "application/json, text/javascript",
                "*": Tn
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText"
            },
            converters: {
                "* text": e.String,
                "text html": !0,
                "text json": v.parseJSON,
                "text xml": v.parseXML
            },
            flatOptions: {
                context: !0,
                url: !0
            }
        },
        ajaxPrefilter: Cn(Sn),
        ajaxTransport: Cn(xn),
        ajax: function(e, n) {
            function T(e, n, s, a) {
                var l, y, b, w, S, T = n;
                if (E === 2)
                    return;
                E = 2,
                u && clearTimeout(u),
                o = t,
                i = a || "",
                x.readyState = e > 0 ? 4 : 0,
                s && (w = An(c, x, s));
                if (e >= 200 && e < 300 || e === 304)
                    c.ifModified && (S = x.getResponseHeader("Last-Modified"),
                    S && (v.lastModified[r] = S),
                    S = x.getResponseHeader("Etag"),
                    S && (v.etag[r] = S)),
                    e === 304 ? (T = "notmodified",
                    l = !0) : (l = On(c, w),
                    T = l.state,
                    y = l.data,
                    b = l.error,
                    l = !b);
                else {
                    b = T;
                    if (!T || e)
                        T = "error",
                        e < 0 && (e = 0)
                }
                x.status = e,
                x.statusText = (n || T) + "",
                l ? d.resolveWith(h, [y, T, x]) : d.rejectWith(h, [x, T, b]),
                x.statusCode(g),
                g = t,
                f && p.trigger("ajax" + (l ? "Success" : "Error"), [x, c, l ? y : b]),
                m.fireWith(h, [x, T]),
                f && (p.trigger("ajaxComplete", [x, c]),
                --v.active || v.event.trigger("ajaxStop"))
            }
            typeof e == "object" && (n = e,
            e = t),
            n = n || {};
            var r, i, s, o, u, a, f, l, c = v.ajaxSetup({}, n), h = c.context || c, p = h !== c && (h.nodeType || h instanceof v) ? v(h) : v.event, d = v.Deferred(), m = v.Callbacks("once memory"), g = c.statusCode || {}, b = {}, w = {}, E = 0, S = "canceled", x = {
                readyState: 0,
                setRequestHeader: function(e, t) {
                    if (!E) {
                        var n = e.toLowerCase();
                        e = w[n] = w[n] || e,
                        b[e] = t
                    }
                    return this
                },
                getAllResponseHeaders: function() {
                    return E === 2 ? i : null
                },
                getResponseHeader: function(e) {
                    var n;
                    if (E === 2) {
                        if (!s) {
                            s = {};
                            while (n = pn.exec(i))
                                s[n[1].toLowerCase()] = n[2]
                        }
                        n = s[e.toLowerCase()]
                    }
                    return n === t ? null : n
                },
                overrideMimeType: function(e) {
                    return E || (c.mimeType = e),
                    this
                },
                abort: function(e) {
                    return e = e || S,
                    o && o.abort(e),
                    T(0, e),
                    this
                }
            };
            d.promise(x),
            x.success = x.done,
            x.error = x.fail,
            x.complete = m.add,
            x.statusCode = function(e) {
                if (e) {
                    var t;
                    if (E < 2)
                        for (t in e)
                            g[t] = [g[t], e[t]];
                    else
                        t = e[x.status],
                        x.always(t)
                }
                return this
            }
            ,
            c.url = ((e || c.url) + "").replace(hn, "").replace(mn, ln[1] + "//"),
            c.dataTypes = v.trim(c.dataType || "*").toLowerCase().split(y),
            c.crossDomain == null && (a = wn.exec(c.url.toLowerCase()),
            c.crossDomain = !(!a || a[1] === ln[1] && a[2] === ln[2] && (a[3] || (a[1] === "http:" ? 80 : 443)) == (ln[3] || (ln[1] === "http:" ? 80 : 443)))),
            c.data && c.processData && typeof c.data != "string" && (c.data = v.param(c.data, c.traditional)),
            kn(Sn, c, n, x);
            if (E === 2)
                return x;
            f = c.global,
            c.type = c.type.toUpperCase(),
            c.hasContent = !vn.test(c.type),
            f && v.active++ === 0 && v.event.trigger("ajaxStart");
            if (!c.hasContent) {
                c.data && (c.url += (gn.test(c.url) ? "&" : "?") + c.data,
                delete c.data),
                r = c.url;
                if (c.cache === !1) {
                    var N = v.now()
                      , C = c.url.replace(bn, "$1_=" + N);
                    c.url = C + (C === c.url ? (gn.test(c.url) ? "&" : "?") + "_=" + N : "")
                }
            }
            (c.data && c.hasContent && c.contentType !== !1 || n.contentType) && x.setRequestHeader("Content-Type", c.contentType),
            c.ifModified && (r = r || c.url,
            v.lastModified[r] && x.setRequestHeader("If-Modified-Since", v.lastModified[r]),
            v.etag[r] && x.setRequestHeader("If-None-Match", v.etag[r])),
            x.setRequestHeader("Accept", c.dataTypes[0] && c.accepts[c.dataTypes[0]] ? c.accepts[c.dataTypes[0]] + (c.dataTypes[0] !== "*" ? ", " + Tn + "; q=0.01" : "") : c.accepts["*"]);
            for (l in c.headers)
                x.setRequestHeader(l, c.headers[l]);
            if (!c.beforeSend || c.beforeSend.call(h, x, c) !== !1 && E !== 2) {
                S = "abort";
                for (l in {
                    success: 1,
                    error: 1,
                    complete: 1
                })
                    x[l](c[l]);
                o = kn(xn, c, n, x);
                if (!o)
                    T(-1, "No Transport");
                else {
                    x.readyState = 1,
                    f && p.trigger("ajaxSend", [x, c]),
                    c.async && c.timeout > 0 && (u = setTimeout(function() {
                        x.abort("timeout")
                    }, c.timeout));
                    try {
                        E = 1,
                        o.send(b, T)
                    } catch (k) {
                        if (!(E < 2))
                            throw k;
                        T(-1, k)
                    }
                }
                return x
            }
            return x.abort()
        },
        active: 0,
        lastModified: {},
        etag: {}
    });
    var Mn = []
      , _n = /\?/
      , Dn = /(=)\?(?=&|$)|\?\?/
      , Pn = v.now();
    v.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = Mn.pop() || v.expando + "_" + Pn++;
            return this[e] = !0,
            e
        }
    }),
    v.ajaxPrefilter("json jsonp", function(n, r, i) {
        var s, o, u, a = n.data, f = n.url, l = n.jsonp !== !1, c = l && Dn.test(f), h = l && !c && typeof a == "string" && !(n.contentType || "").indexOf("application/x-www-form-urlencoded") && Dn.test(a);
        if (n.dataTypes[0] === "jsonp" || c || h)
            return s = n.jsonpCallback = v.isFunction(n.jsonpCallback) ? n.jsonpCallback() : n.jsonpCallback,
            o = e[s],
            c ? n.url = f.replace(Dn, "$1" + s) : h ? n.data = a.replace(Dn, "$1" + s) : l && (n.url += (_n.test(f) ? "&" : "?") + n.jsonp + "=" + s),
            n.converters["script json"] = function() {
                return u || v.error(s + " was not called"),
                u[0]
            }
            ,
            n.dataTypes[0] = "json",
            e[s] = function() {
                u = arguments
            }
            ,
            i.always(function() {
                e[s] = o,
                n[s] && (n.jsonpCallback = r.jsonpCallback,
                Mn.push(s)),
                u && v.isFunction(o) && o(u[0]),
                u = o = t
            }),
            "script"
    }),
    v.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /javascript|ecmascript/
        },
        converters: {
            "text script": function(e) {
                return v.globalEval(e),
                e
            }
        }
    }),
    v.ajaxPrefilter("script", function(e) {
        e.cache === t && (e.cache = !1),
        e.crossDomain && (e.type = "GET",
        e.global = !1)
    }),
    v.ajaxTransport("script", function(e) {
        if (e.crossDomain) {
            var n, r = i.head || i.getElementsByTagName("head")[0] || i.documentElement;
            return {
                send: function(s, o) {
                    n = i.createElement("script"),
                    n.async = "async",
                    e.scriptCharset && (n.charset = e.scriptCharset),
                    n.src = e.url,
                    n.onload = n.onreadystatechange = function(e, i) {
                        if (i || !n.readyState || /loaded|complete/.test(n.readyState))
                            n.onload = n.onreadystatechange = null,
                            r && n.parentNode && r.removeChild(n),
                            n = t,
                            i || o(200, "success")
                    }
                    ,
                    r.insertBefore(n, r.firstChild)
                },
                abort: function() {
                    n && n.onload(0, 1)
                }
            }
        }
    });
    var Hn, Bn = e.ActiveXObject ? function() {
        for (var e in Hn)
            Hn[e](0, 1)
    }
    : !1, jn = 0;
    v.ajaxSettings.xhr = e.ActiveXObject ? function() {
        return !this.isLocal && Fn() || In()
    }
    : Fn,
    function(e) {
        v.extend(v.support, {
            ajax: !!e,
            cors: !!e && "withCredentials"in e
        })
    }(v.ajaxSettings.xhr()),
    v.support.ajax && v.ajaxTransport(function(n) {
        if (!n.crossDomain || v.support.cors) {
            var r;
            return {
                send: function(i, s) {
                    var o, u, a = n.xhr();
                    n.username ? a.open(n.type, n.url, n.async, n.username, n.password) : a.open(n.type, n.url, n.async);
                    if (n.xhrFields)
                        for (u in n.xhrFields)
                            a[u] = n.xhrFields[u];
                    n.mimeType && a.overrideMimeType && a.overrideMimeType(n.mimeType),
                    !n.crossDomain && !i["X-Requested-With"] && (i["X-Requested-With"] = "XMLHttpRequest");
                    try {
                        for (u in i)
                            a.setRequestHeader(u, i[u])
                    } catch (f) {}
                    a.send(n.hasContent && n.data || null),
                    r = function(e, i) {
                        var u, f, l, c, h;
                        try {
                            if (r && (i || a.readyState === 4)) {
                                r = t,
                                o && (a.onreadystatechange = v.noop,
                                Bn && delete Hn[o]);
                                if (i)
                                    a.readyState !== 4 && a.abort();
                                else {
                                    u = a.status,
                                    l = a.getAllResponseHeaders(),
                                    c = {},
                                    h = a.responseXML,
                                    h && h.documentElement && (c.xml = h);
                                    try {
                                        c.text = a.responseText
                                    } catch (p) {}
                                    try {
                                        f = a.statusText
                                    } catch (p) {
                                        f = ""
                                    }
                                    !u && n.isLocal && !n.crossDomain ? u = c.text ? 200 : 404 : u === 1223 && (u = 204)
                                }
                            }
                        } catch (d) {
                            i || s(-1, d)
                        }
                        c && s(u, f, c, l)
                    }
                    ,
                    n.async ? a.readyState === 4 ? setTimeout(r, 0) : (o = ++jn,
                    Bn && (Hn || (Hn = {},
                    v(e).unload(Bn)),
                    Hn[o] = r),
                    a.onreadystatechange = r) : r()
                },
                abort: function() {
                    r && r(0, 1)
                }
            }
        }
    });
    var qn, Rn, Un = /^(?:toggle|show|hide)$/, zn = new RegExp("^(?:([-+])=|)(" + m + ")([a-z%]*)$","i"), Wn = /queueHooks$/, Xn = [Gn], Vn = {
        "*": [function(e, t) {
            var n, r, i = this.createTween(e, t), s = zn.exec(t), o = i.cur(), u = +o || 0, a = 1, f = 20;
            if (s) {
                n = +s[2],
                r = s[3] || (v.cssNumber[e] ? "" : "px");
                if (r !== "px" && u) {
                    u = v.css(i.elem, e, !0) || n || 1;
                    do
                        a = a || ".5",
                        u /= a,
                        v.style(i.elem, e, u + r);
                    while (a !== (a = i.cur() / o) && a !== 1 && --f)
                }
                i.unit = r,
                i.start = u,
                i.end = s[1] ? u + (s[1] + 1) * n : n
            }
            return i
        }
        ]
    };
    v.Animation = v.extend(Kn, {
        tweener: function(e, t) {
            v.isFunction(e) ? (t = e,
            e = ["*"]) : e = e.split(" ");
            var n, r = 0, i = e.length;
            for (; r < i; r++)
                n = e[r],
                Vn[n] = Vn[n] || [],
                Vn[n].unshift(t)
        },
        prefilter: function(e, t) {
            t ? Xn.unshift(e) : Xn.push(e)
        }
    }),
    v.Tween = Yn,
    Yn.prototype = {
        constructor: Yn,
        init: function(e, t, n, r, i, s) {
            this.elem = e,
            this.prop = n,
            this.easing = i || "swing",
            this.options = t,
            this.start = this.now = this.cur(),
            this.end = r,
            this.unit = s || (v.cssNumber[n] ? "" : "px")
        },
        cur: function() {
            var e = Yn.propHooks[this.prop];
            return e && e.get ? e.get(this) : Yn.propHooks._default.get(this)
        },
        run: function(e) {
            var t, n = Yn.propHooks[this.prop];
            return this.options.duration ? this.pos = t = v.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e,
            this.now = (this.end - this.start) * t + this.start,
            this.options.step && this.options.step.call(this.elem, this.now, this),
            n && n.set ? n.set(this) : Yn.propHooks._default.set(this),
            this
        }
    },
    Yn.prototype.init.prototype = Yn.prototype,
    Yn.propHooks = {
        _default: {
            get: function(e) {
                var t;
                return e.elem[e.prop] == null || !!e.elem.style && e.elem.style[e.prop] != null ? (t = v.css(e.elem, e.prop, !1, ""),
                !t || t === "auto" ? 0 : t) : e.elem[e.prop]
            },
            set: function(e) {
                v.fx.step[e.prop] ? v.fx.step[e.prop](e) : e.elem.style && (e.elem.style[v.cssProps[e.prop]] != null || v.cssHooks[e.prop]) ? v.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
            }
        }
    },
    Yn.propHooks.scrollTop = Yn.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    },
    v.each(["toggle", "show", "hide"], function(e, t) {
        var n = v.fn[t];
        v.fn[t] = function(r, i, s) {
            return r == null || typeof r == "boolean" || !e && v.isFunction(r) && v.isFunction(i) ? n.apply(this, arguments) : this.animate(Zn(t, !0), r, i, s)
        }
    }),
    v.fn.extend({
        fadeTo: function(e, t, n, r) {
            return this.filter(Gt).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, r)
        },
        animate: function(e, t, n, r) {
            var i = v.isEmptyObject(e)
              , s = v.speed(t, n, r)
              , o = function() {
                var t = Kn(this, v.extend({}, e), s);
                i && t.stop(!0)
            };
            return i || s.queue === !1 ? this.each(o) : this.queue(s.queue, o)
        },
        stop: function(e, n, r) {
            var i = function(e) {
                var t = e.stop;
                delete e.stop,
                t(r)
            };
            return typeof e != "string" && (r = n,
            n = e,
            e = t),
            n && e !== !1 && this.queue(e || "fx", []),
            this.each(function() {
                var t = !0
                  , n = e != null && e + "queueHooks"
                  , s = v.timers
                  , o = v._data(this);
                if (n)
                    o[n] && o[n].stop && i(o[n]);
                else
                    for (n in o)
                        o[n] && o[n].stop && Wn.test(n) && i(o[n]);
                for (n = s.length; n--; )
                    s[n].elem === this && (e == null || s[n].queue === e) && (s[n].anim.stop(r),
                    t = !1,
                    s.splice(n, 1));
                (t || !r) && v.dequeue(this, e)
            })
        }
    }),
    v.each({
        slideDown: Zn("show"),
        slideUp: Zn("hide"),
        slideToggle: Zn("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function(e, t) {
        v.fn[e] = function(e, n, r) {
            return this.animate(t, e, n, r)
        }
    }),
    v.speed = function(e, t, n) {
        var r = e && typeof e == "object" ? v.extend({}, e) : {
            complete: n || !n && t || v.isFunction(e) && e,
            duration: e,
            easing: n && t || t && !v.isFunction(t) && t
        };
        r.duration = v.fx.off ? 0 : typeof r.duration == "number" ? r.duration : r.duration in v.fx.speeds ? v.fx.speeds[r.duration] : v.fx.speeds._default;
        if (r.queue == null || r.queue === !0)
            r.queue = "fx";
        return r.old = r.complete,
        r.complete = function() {
            v.isFunction(r.old) && r.old.call(this),
            r.queue && v.dequeue(this, r.queue)
        }
        ,
        r
    }
    ,
    v.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        }
    },
    v.timers = [],
    v.fx = Yn.prototype.init,
    v.fx.tick = function() {
        var e, n = v.timers, r = 0;
        qn = v.now();
        for (; r < n.length; r++)
            e = n[r],
            !e() && n[r] === e && n.splice(r--, 1);
        n.length || v.fx.stop(),
        qn = t
    }
    ,
    v.fx.timer = function(e) {
        e() && v.timers.push(e) && !Rn && (Rn = setInterval(v.fx.tick, v.fx.interval))
    }
    ,
    v.fx.interval = 13,
    v.fx.stop = function() {
        clearInterval(Rn),
        Rn = null
    }
    ,
    v.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    },
    v.fx.step = {},
    v.expr && v.expr.filters && (v.expr.filters.animated = function(e) {
        return v.grep(v.timers, function(t) {
            return e === t.elem
        }).length
    }
    );
    var er = /^(?:body|html)$/i;
    v.fn.offset = function(e) {
        if (arguments.length)
            return e === t ? this : this.each(function(t) {
                v.offset.setOffset(this, e, t)
            });
        var n, r, i, s, o, u, a, f = {
            top: 0,
            left: 0
        }, l = this[0], c = l && l.ownerDocument;
        if (!c)
            return;
        return (r = c.body) === l ? v.offset.bodyOffset(l) : (n = c.documentElement,
        v.contains(n, l) ? (typeof l.getBoundingClientRect != "undefined" && (f = l.getBoundingClientRect()),
        i = tr(c),
        s = n.clientTop || r.clientTop || 0,
        o = n.clientLeft || r.clientLeft || 0,
        u = i.pageYOffset || n.scrollTop,
        a = i.pageXOffset || n.scrollLeft,
        {
            top: f.top + u - s,
            left: f.left + a - o
        }) : f)
    }
    ,
    v.offset = {
        bodyOffset: function(e) {
            var t = e.offsetTop
              , n = e.offsetLeft;
            return v.support.doesNotIncludeMarginInBodyOffset && (t += parseFloat(v.css(e, "marginTop")) || 0,
            n += parseFloat(v.css(e, "marginLeft")) || 0),
            {
                top: t,
                left: n
            }
        },
        setOffset: function(e, t, n) {
            var r = v.css(e, "position");
            r === "static" && (e.style.position = "relative");
            var i = v(e), s = i.offset(), o = v.css(e, "top"), u = v.css(e, "left"), a = (r === "absolute" || r === "fixed") && v.inArray("auto", [o, u]) > -1, f = {}, l = {}, c, h;
            a ? (l = i.position(),
            c = l.top,
            h = l.left) : (c = parseFloat(o) || 0,
            h = parseFloat(u) || 0),
            v.isFunction(t) && (t = t.call(e, n, s)),
            t.top != null && (f.top = t.top - s.top + c),
            t.left != null && (f.left = t.left - s.left + h),
            "using"in t ? t.using.call(e, f) : i.css(f)
        }
    },
    v.fn.extend({
        position: function() {
            if (!this[0])
                return;
            var e = this[0]
              , t = this.offsetParent()
              , n = this.offset()
              , r = er.test(t[0].nodeName) ? {
                top: 0,
                left: 0
            } : t.offset();
            return n.top -= parseFloat(v.css(e, "marginTop")) || 0,
            n.left -= parseFloat(v.css(e, "marginLeft")) || 0,
            r.top += parseFloat(v.css(t[0], "borderTopWidth")) || 0,
            r.left += parseFloat(v.css(t[0], "borderLeftWidth")) || 0,
            {
                top: n.top - r.top,
                left: n.left - r.left
            }
        },
        offsetParent: function() {
            return this.map(function() {
                var e = this.offsetParent || i.body;
                while (e && !er.test(e.nodeName) && v.css(e, "position") === "static")
                    e = e.offsetParent;
                return e || i.body
            })
        }
    }),
    v.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(e, n) {
        var r = /Y/.test(n);
        v.fn[e] = function(i) {
            return v.access(this, function(e, i, s) {
                var o = tr(e);
                if (s === t)
                    return o ? n in o ? o[n] : o.document.documentElement[i] : e[i];
                o ? o.scrollTo(r ? v(o).scrollLeft() : s, r ? s : v(o).scrollTop()) : e[i] = s
            }, e, i, arguments.length, null)
        }
    }),
    v.each({
        Height: "height",
        Width: "width"
    }, function(e, n) {
        v.each({
            padding: "inner" + e,
            content: n,
            "": "outer" + e
        }, function(r, i) {
            v.fn[i] = function(i, s) {
                var o = arguments.length && (r || typeof i != "boolean")
                  , u = r || (i === !0 || s === !0 ? "margin" : "border");
                return v.access(this, function(n, r, i) {
                    var s;
                    return v.isWindow(n) ? n.document.documentElement["client" + e] : n.nodeType === 9 ? (s = n.documentElement,
                    Math.max(n.body["scroll" + e], s["scroll" + e], n.body["offset" + e], s["offset" + e], s["client" + e])) : i === t ? v.css(n, r, i, u) : v.style(n, r, i, u)
                }, n, o ? i : t, o, null)
            }
        })
    }),
    e.jQuery = e.$ = v,
    typeof define == "function" && define.amd && define.amd.jQuery && define("jquery", [], function() {
        return v
    })
}
)(window);
jQuery.easing.jswing = jQuery.easing.swing;
jQuery.extend(jQuery.easing, {
    def: "easeOutQuad",
    swing: function(e, a, c, b, d) {
        return jQuery.easing[jQuery.easing.def](e, a, c, b, d)
    },
    easeInQuad: function(e, a, c, b, d) {
        return b * (a /= d) * a + c
    },
    easeOutQuad: function(e, a, c, b, d) {
        return -b * (a /= d) * (a - 2) + c
    },
    easeInOutQuad: function(e, a, c, b, d) {
        if ((a /= d / 2) < 1)
            return b / 2 * a * a + c;
        return -b / 2 * (--a * (a - 2) - 1) + c
    },
    easeInCubic: function(e, a, c, b, d) {
        return b * (a /= d) * a * a + c
    },
    easeOutCubic: function(e, a, c, b, d) {
        return b * ((a = a / d - 1) * a * a + 1) + c
    },
    easeInOutCubic: function(e, a, c, b, d) {
        if ((a /= d / 2) < 1)
            return b / 2 * a * a * a + c;
        return b / 2 * ((a -= 2) * a * a + 2) + c
    },
    easeInQuart: function(e, a, c, b, d) {
        return b * (a /= d) * a * a * a + c
    },
    easeOutQuart: function(e, a, c, b, d) {
        return -b * ((a = a / d - 1) * a * a * a - 1) + c
    },
    easeInOutQuart: function(e, a, c, b, d) {
        if ((a /= d / 2) < 1)
            return b / 2 * a * a * a * a + c;
        return -b / 2 * ((a -= 2) * a * a * a - 2) + c
    },
    easeInQuint: function(e, a, c, b, d) {
        return b * (a /= d) * a * a * a * a + c
    },
    easeOutQuint: function(e, a, c, b, d) {
        return b * ((a = a / d - 1) * a * a * a * a + 1) + c
    },
    easeInOutQuint: function(e, a, c, b, d) {
        if ((a /= d / 2) < 1)
            return b / 2 * a * a * a * a * a + c;
        return b / 2 * ((a -= 2) * a * a * a * a + 2) + c
    },
    easeInSine: function(e, a, c, b, d) {
        return -b * Math.cos(a / d * (Math.PI / 2)) + b + c
    },
    easeOutSine: function(e, a, c, b, d) {
        return b * Math.sin(a / d * (Math.PI / 2)) + c
    },
    easeInOutSine: function(e, a, c, b, d) {
        return -b / 2 * (Math.cos(Math.PI * a / d) - 1) + c
    },
    easeInExpo: function(e, a, c, b, d) {
        return a == 0 ? c : b * Math.pow(2, 10 * (a / d - 1)) + c
    },
    easeOutExpo: function(e, a, c, b, d) {
        return a == d ? c + b : b * (-Math.pow(2, -10 * a / d) + 1) + c
    },
    easeInOutExpo: function(e, a, c, b, d) {
        if (a == 0)
            return c;
        if (a == d)
            return c + b;
        if ((a /= d / 2) < 1)
            return b / 2 * Math.pow(2, 10 * (a - 1)) + c;
        return b / 2 * (-Math.pow(2, -10 * --a) + 2) + c
    },
    easeInCirc: function(e, a, c, b, d) {
        return -b * (Math.sqrt(1 - (a /= d) * a) - 1) + c
    },
    easeOutCirc: function(e, a, c, b, d) {
        return b * Math.sqrt(1 - (a = a / d - 1) * a) + c
    },
    easeInOutCirc: function(e, a, c, b, d) {
        if ((a /= d / 2) < 1)
            return -b / 2 * (Math.sqrt(1 - a * a) - 1) + c;
        return b / 2 * (Math.sqrt(1 - (a -= 2) * a) + 1) + c
    },
    easeInElastic: function(e, a, c, b, d) {
        e = 1.70158;
        var f = 0
          , g = b;
        if (a == 0)
            return c;
        if ((a /= d) == 1)
            return c + b;
        f || (f = d * 0.3);
        if (g < Math.abs(b)) {
            g = b;
            e = f / 4
        } else
            e = f / (2 * Math.PI) * Math.asin(b / g);
        return -(g * Math.pow(2, 10 * (a -= 1)) * Math.sin((a * d - e) * 2 * Math.PI / f)) + c
    },
    easeOutElastic: function(e, a, c, b, d) {
        e = 1.70158;
        var f = 0
          , g = b;
        if (a == 0)
            return c;
        if ((a /= d) == 1)
            return c + b;
        f || (f = d * 0.3);
        if (g < Math.abs(b)) {
            g = b;
            e = f / 4
        } else
            e = f / (2 * Math.PI) * Math.asin(b / g);
        return g * Math.pow(2, -10 * a) * Math.sin((a * d - e) * 2 * Math.PI / f) + b + c
    },
    easeInOutElastic: function(e, a, c, b, d) {
        e = 1.70158;
        var f = 0
          , g = b;
        if (a == 0)
            return c;
        if ((a /= d / 2) == 2)
            return c + b;
        f || (f = d * 0.3 * 1.5);
        if (g < Math.abs(b)) {
            g = b;
            e = f / 4
        } else
            e = f / (2 * Math.PI) * Math.asin(b / g);
        if (a < 1)
            return -0.5 * g * Math.pow(2, 10 * (a -= 1)) * Math.sin((a * d - e) * 2 * Math.PI / f) + c;
        return g * Math.pow(2, -10 * (a -= 1)) * Math.sin((a * d - e) * 2 * Math.PI / f) * 0.5 + b + c
    },
    easeInBack: function(e, a, c, b, d, f) {
        if (f == undefined)
            f = 1.70158;
        return b * (a /= d) * a * ((f + 1) * a - f) + c
    },
    easeOutBack: function(e, a, c, b, d, f) {
        if (f == undefined)
            f = 1.70158;
        return b * ((a = a / d - 1) * a * ((f + 1) * a + f) + 1) + c
    },
    easeInOutBack: function(e, a, c, b, d, f) {
        if (f == undefined)
            f = 1.70158;
        if ((a /= d / 2) < 1)
            return b / 2 * a * a * (((f *= 1.525) + 1) * a - f) + c;
        return b / 2 * ((a -= 2) * a * (((f *= 1.525) + 1) * a + f) + 2) + c
    },
    easeInBounce: function(e, a, c, b, d) {
        return b - jQuery.easing.easeOutBounce(e, d - a, 0, b, d) + c
    },
    easeOutBounce: function(e, a, c, b, d) {
        return (a /= d) < 1 / 2.75 ? b * 7.5625 * a * a + c : a < 2 / 2.75 ? b * (7.5625 * (a -= 1.5 / 2.75) * a + 0.75) + c : a < 2.5 / 2.75 ? b * (7.5625 * (a -= 2.25 / 2.75) * a + 0.9375) + c : b * (7.5625 * (a -= 2.625 / 2.75) * a + 0.984375) + c
    },
    easeInOutBounce: function(e, a, c, b, d) {
        if (a < d / 2)
            return jQuery.easing.easeInBounce(e, a * 2, 0, b, d) * 0.5 + c;
        return jQuery.easing.easeOutBounce(e, a * 2 - d, 0, b, d) * 0.5 + b * 0.5 + c
    }
});
//Cycle2
(function(e) {
    "use strict";
    function t(e) {
        return (e || "").toLowerCase()
    }
    var i = "20130409";
    e.fn.cycle = function(i) {
        var n;
        return 0 !== this.length || e.isReady ? this.each(function() {
            var n, s, o, c, r = e(this), l = e.fn.cycle.log;
            if (!r.data("cycle.opts")) {
                (r.data("cycle-log") === !1 || i && i.log === !1 || s && s.log === !1) && (l = e.noop),
                l("--c2 init--"),
                n = r.data();
                for (var a in n)
                    n.hasOwnProperty(a) && /^cycle[A-Z]+/.test(a) && (c = n[a],
                    o = a.match(/^cycle(.*)/)[1].replace(/^[A-Z]/, t),
                    l(o + ":", c, "(" + typeof c + ")"),
                    n[o] = c);
                s = e.extend({}, e.fn.cycle.defaults, n, i || {}),
                s.timeoutId = 0,
                s.paused = s.paused || !1,
                s.container = r,
                s._maxZ = s.maxZ,
                s.API = e.extend({
                    _container: r
                }, e.fn.cycle.API),
                s.API.log = l,
                s.API.trigger = function(e, t) {
                    return s.container.trigger(e, t),
                    s.API
                }
                ,
                r.data("cycle.opts", s),
                r.data("cycle.API", s.API),
                s.API.trigger("cycle-bootstrap", [s, s.API]),
                s.API.addInitialSlides(),
                s.API.preInitSlideshow(),
                s.slides.length && s.API.initSlideshow()
            }
        }) : (n = {
            s: this.selector,
            c: this.context
        },
        e.fn.cycle.log("requeuing slideshow (dom not ready)"),
        e(function() {
            e(n.s, n.c).cycle(i)
        }),
        this)
    }
    ,
    e.fn.cycle.API = {
        opts: function() {
            return this._container.data("cycle.opts")
        },
        addInitialSlides: function() {
            var t = this.opts()
              , i = t.slides;
            t.slideCount = 0,
            t.slides = e(),
            i = i.jquery ? i : t.container.find(i),
            t.random && i.sort(function() {
                return Math.random() - .5
            }),
            t.API.add(i)
        },
        preInitSlideshow: function() {
            var t = this.opts();
            t.API.trigger("cycle-pre-initialize", [t]);
            var i = e.fn.cycle.transitions[t.fx];
            i && e.isFunction(i.preInit) && i.preInit(t),
            t._preInitialized = !0
        },
        postInitSlideshow: function() {
            var t = this.opts();
            t.API.trigger("cycle-post-initialize", [t]);
            var i = e.fn.cycle.transitions[t.fx];
            i && e.isFunction(i.postInit) && i.postInit(t)
        },
        initSlideshow: function() {
            var t, i = this.opts(), n = i.container;
            i.API.calcFirstSlide(),
            "static" == i.container.css("position") && i.container.css("position", "relative"),
            e(i.slides[i.currSlide]).css("opacity", 1).show(),
            i.API.stackSlides(i.slides[i.currSlide], i.slides[i.nextSlide], !i.reverse),
            i.pauseOnHover && (i.pauseOnHover !== !0 && (n = e(i.pauseOnHover)),
            n.hover(function() {
                i.API.pause(!0)
            }, function() {
                i.API.resume(!0)
            })),
            i.timeout && (t = i.API.getSlideOpts(i.nextSlide),
            i.API.queueTransition(t, i.timeout + i.delay)),
            i._initialized = !0,
            i.API.updateView(!0),
            i.API.trigger("cycle-initialized", [i]),
            i.API.postInitSlideshow()
        },
        pause: function(t) {
            var i = this.opts()
              , n = i.API.getSlideOpts()
              , s = i.hoverPaused || i.paused;
            t ? i.hoverPaused = !0 : i.paused = !0,
            s || (i.container.addClass("cycle-paused"),
            i.API.trigger("cycle-paused", [i]).log("cycle-paused"),
            n.timeout && (clearTimeout(i.timeoutId),
            i.timeoutId = 0,
            i._remainingTimeout -= e.now() - i._lastQueue,
            (0 > i._remainingTimeout || isNaN(i._remainingTimeout)) && (i._remainingTimeout = void 0)))
        },
        resume: function(e) {
            var t = this.opts()
              , i = !t.hoverPaused && !t.paused;
            e ? t.hoverPaused = !1 : t.paused = !1,
            i || (t.container.removeClass("cycle-paused"),
            t.API.queueTransition(t.API.getSlideOpts(), t._remainingTimeout),
            t.API.trigger("cycle-resumed", [t, t._remainingTimeout]).log("cycle-resumed"))
        },
        add: function(t, i) {
            var n, s = this.opts(), o = s.slideCount, c = !1;
            "string" == e.type(t) && (t = e.trim(t)),
            e(t).each(function() {
                var t, n = e(this);
                i ? s.container.prepend(n) : s.container.append(n),
                s.slideCount++,
                t = s.API.buildSlideOpts(n),
                s.slides = i ? e(n).add(s.slides) : s.slides.add(n),
                s.API.initSlide(t, n, --s._maxZ),
                n.data("cycle.opts", t),
                s.API.trigger("cycle-slide-added", [s, t, n])
            }),
            s.API.updateView(!0),
            c = s._preInitialized && 2 > o && s.slideCount >= 1,
            c && (s._initialized ? s.timeout && (n = s.slides.length,
            s.nextSlide = s.reverse ? n - 1 : 1,
            s.timeoutId || s.API.queueTransition(s)) : s.API.initSlideshow())
        },
        calcFirstSlide: function() {
            var e, t = this.opts();
            e = parseInt(t.startingSlide || 0, 10),
            (e >= t.slides.length || 0 > e) && (e = 0),
            t.currSlide = e,
            t.reverse ? (t.nextSlide = e - 1,
            0 > t.nextSlide && (t.nextSlide = t.slides.length - 1)) : (t.nextSlide = e + 1,
            t.nextSlide == t.slides.length && (t.nextSlide = 0))
        },
        calcNextSlide: function() {
            var e, t = this.opts();
            t.reverse ? (e = 0 > t.nextSlide - 1,
            t.nextSlide = e ? t.slideCount - 1 : t.nextSlide - 1,
            t.currSlide = e ? 0 : t.nextSlide + 1) : (e = t.nextSlide + 1 == t.slides.length,
            t.nextSlide = e ? 0 : t.nextSlide + 1,
            t.currSlide = e ? t.slides.length - 1 : t.nextSlide - 1)
        },
        calcTx: function(t, i) {
            var n, s = t;
            return i && s.manualFx && (n = e.fn.cycle.transitions[s.manualFx]),
            n || (n = e.fn.cycle.transitions[s.fx]),
            n || (n = e.fn.cycle.transitions.fade,
            s.API.log('Transition "' + s.fx + '" not found.  Using fade.')),
            n
        },
        prepareTx: function(e, t) {
            var i, n, s, o, c, r = this.opts();
            return 2 > r.slideCount ? (r.timeoutId = 0,
            void 0) : (!e || r.busy && !r.manualTrump || (r.API.stopTransition(),
            r.busy = !1,
            clearTimeout(r.timeoutId),
            r.timeoutId = 0),
            r.busy || (0 !== r.timeoutId || e) && (n = r.slides[r.currSlide],
            s = r.slides[r.nextSlide],
            o = r.API.getSlideOpts(r.nextSlide),
            c = r.API.calcTx(o, e),
            r._tx = c,
            e && void 0 !== o.manualSpeed && (o.speed = o.manualSpeed),
            r.nextSlide != r.currSlide && (e || !r.paused && !r.hoverPaused && r.timeout) ? (r.API.trigger("cycle-before", [o, n, s, t]),
            c.before && c.before(o, n, s, t),
            i = function() {
                r.busy = !1,
                r.container.data("cycle.opts") && (c.after && c.after(o, n, s, t),
                r.API.trigger("cycle-after", [o, n, s, t]),
                r.API.queueTransition(o),
                r.API.updateView(!0))
            }
            ,
            r.busy = !0,
            c.transition ? c.transition(o, n, s, t, i) : r.API.doTransition(o, n, s, t, i),
            r.API.calcNextSlide(),
            r.API.updateView()) : r.API.queueTransition(o)),
            void 0)
        },
        doTransition: function(t, i, n, s, o) {
            var c = t
              , r = e(i)
              , l = e(n)
              , a = function() {
                l.animate(c.animIn || {
                    opacity: 1
                }, c.speed, c.easeIn || c.easing, o)
            };
            l.css(c.cssBefore || {}),
            r.animate(c.animOut || {}, c.speed, c.easeOut || c.easing, function() {
                r.css(c.cssAfter || {}),
                c.sync || a()
            }),
            c.sync && a()
        },
        queueTransition: function(t, i) {
            var n = this.opts()
              , s = void 0 !== i ? i : t.timeout;
            return 0 === n.nextSlide && 0 === --n.loop ? (n.API.log("terminating; loop=0"),
            n.timeout = 0,
            s ? setTimeout(function() {
                n.API.trigger("cycle-finished", [n])
            }, s) : n.API.trigger("cycle-finished", [n]),
            n.nextSlide = n.currSlide,
            void 0) : (s && (n._lastQueue = e.now(),
            void 0 === i && (n._remainingTimeout = t.timeout),
            n.paused || n.hoverPaused || (n.timeoutId = setTimeout(function() {
                n.API.prepareTx(!1, !n.reverse)
            }, s))),
            void 0)
        },
        stopTransition: function() {
            var e = this.opts();
            e.slides.filter(":animated").length && (e.slides.stop(!1, !0),
            e.API.trigger("cycle-transition-stopped", [e])),
            e._tx && e._tx.stopTransition && e._tx.stopTransition(e)
        },
        advanceSlide: function(e) {
            var t = this.opts();
            return clearTimeout(t.timeoutId),
            t.timeoutId = 0,
            t.nextSlide = t.currSlide + e,
            0 > t.nextSlide ? t.nextSlide = t.slides.length - 1 : t.nextSlide >= t.slides.length && (t.nextSlide = 0),
            t.API.prepareTx(!0, e >= 0),
            !1
        },
        buildSlideOpts: function(i) {
            var n, s, o = this.opts(), c = i.data() || {};
            for (var r in c)
                c.hasOwnProperty(r) && /^cycle[A-Z]+/.test(r) && (n = c[r],
                s = r.match(/^cycle(.*)/)[1].replace(/^[A-Z]/, t),
                o.API.log("[" + (o.slideCount - 1) + "]", s + ":", n, "(" + typeof n + ")"),
                c[s] = n);
            c = e.extend({}, e.fn.cycle.defaults, o, c),
            c.slideNum = o.slideCount;
            try {
                delete c.API,
                delete c.slideCount,
                delete c.currSlide,
                delete c.nextSlide,
                delete c.slides
            } catch (l) {}
            return c
        },
        getSlideOpts: function(t) {
            var i = this.opts();
            void 0 === t && (t = i.currSlide);
            var n = i.slides[t]
              , s = e(n).data("cycle.opts");
            return e.extend({}, i, s)
        },
        initSlide: function(t, i, n) {
            var s = this.opts();
            i.css(t.slideCss || {}),
            n > 0 && i.css("zIndex", n),
            isNaN(t.speed) && (t.speed = e.fx.speeds[t.speed] || e.fx.speeds._default),
            t.sync || (t.speed = t.speed / 2),
            i.addClass(s.slideClass)
        },
        updateView: function(e) {
            var t = this.opts();
            if (t._initialized) {
                var i = t.API.getSlideOpts()
                  , n = t.slides[t.currSlide];
                !e && (t.API.trigger("cycle-update-view-before", [t, i, n]),
                0 > t.updateView) || (t.slideActiveClass && t.slides.removeClass(t.slideActiveClass).eq(t.currSlide).addClass(t.slideActiveClass),
                e && t.hideNonActive && t.slides.filter(":not(." + t.slideActiveClass + ")").hide(),
                t.API.trigger("cycle-update-view", [t, i, n, e]),
                t.API.trigger("cycle-update-view-after", [t, i, n]))
            }
        },
        getComponent: function(t) {
            var i = this.opts()
              , n = i[t];
            return "string" == typeof n ? /^\s*[\>|\+|~]/.test(n) ? i.container.find(n) : e(n) : n.jquery ? n : e(n)
        },
        stackSlides: function(t, i, n) {
            var s = this.opts();
            t || (t = s.slides[s.currSlide],
            i = s.slides[s.nextSlide],
            n = !s.reverse),
            e(t).css("zIndex", s.maxZ);
            var o, c = s.maxZ - 2, r = s.slideCount;
            if (n) {
                for (o = s.currSlide + 1; r > o; o++)
                    e(s.slides[o]).css("zIndex", c--);
                for (o = 0; s.currSlide > o; o++)
                    e(s.slides[o]).css("zIndex", c--)
            } else {
                for (o = s.currSlide - 1; o >= 0; o--)
                    e(s.slides[o]).css("zIndex", c--);
                for (o = r - 1; o > s.currSlide; o--)
                    e(s.slides[o]).css("zIndex", c--)
            }
            e(i).css("zIndex", s.maxZ - 1)
        },
        getSlideIndex: function(e) {
            return this.opts().slides.index(e)
        }
    },
    e.fn.cycle.log = function() {
        window.console && console.log && console.log("[cycle2] " + Array.prototype.join.call(arguments, " "))
    }
    ,
    e.fn.cycle.version = function() {
        return "Cycle2: " + i
    }
    ,
    e.fn.cycle.transitions = {
        custom: {},
        none: {
            before: function(e, t, i, n) {
                e.API.stackSlides(i, t, n),
                e.cssBefore = {
                    opacity: 1,
                    display: "block"
                }
            }
        },
        fade: {
            before: function(t, i, n, s) {
                var o = t.API.getSlideOpts(t.nextSlide).slideCss || {};
                t.API.stackSlides(i, n, s),
                t.cssBefore = e.extend(o, {
                    opacity: 0,
                    display: "block"
                }),
                t.animIn = {
                    opacity: 1
                },
                t.animOut = {
                    opacity: 0
                }
            }
        },
        fadeout: {
            before: function(t, i, n, s) {
                var o = t.API.getSlideOpts(t.nextSlide).slideCss || {};
                t.API.stackSlides(i, n, s),
                t.cssBefore = e.extend(o, {
                    opacity: 1,
                    display: "block"
                }),
                t.animOut = {
                    opacity: 0
                }
            }
        },
        scrollHorz: {
            before: function(e, t, i, n) {
                e.API.stackSlides(t, i, n);
                var s = e.container.css("overflow", "hidden").width();
                e.cssBefore = {
                    left: n ? s : -s,
                    top: 0,
                    opacity: 1,
                    display: "block"
                },
                e.cssAfter = {
                    zIndex: e._maxZ - 2,
                    left: 0
                },
                e.animIn = {
                    left: 0
                },
                e.animOut = {
                    left: n ? -s : s
                }
            }
        }
    },
    e.fn.cycle.defaults = {
        allowWrap: !0,
        autoSelector: ".cycle-slideshow[data-cycle-auto-init!=false]",
        delay: 0,
        easing: null,
        fx: "fade",
        hideNonActive: !0,
        loop: 0,
        manualFx: void 0,
        manualSpeed: void 0,
        manualTrump: !0,
        maxZ: 100,
        pauseOnHover: !1,
        reverse: !1,
        slideActiveClass: "cycle-slide-active",
        slideClass: "cycle-slide",
        slideCss: {
            position: "absolute",
            top: 0,
            left: 0
        },
        slides: "> img",
        speed: 500,
        startingSlide: 0,
        sync: !0,
        timeout: 4e3,
        updateView: -1
    },
    e(document).ready(function() {
        e(e.fn.cycle.defaults.autoSelector).cycle()
    })
}
)(jQuery),
function(e) {
    "use strict";
    function t(t, n) {
        var s, o, c, r = n.autoHeight;
        if ("container" == r)
            o = e(n.slides[n.currSlide]).outerHeight(),
            n.container.height(o);
        else if (n._autoHeightRatio)
            n.container.height(n.container.width() / n._autoHeightRatio);
        else if ("calc" === r || "number" == e.type(r) && r >= 0) {
            if (c = "calc" === r ? i(t, n) : r >= n.slides.length ? 0 : r,
            c == n._sentinelIndex)
                return;
            n._sentinelIndex = c,
            n._sentinel && n._sentinel.remove(),
            s = e(n.slides[c].cloneNode(!0)),
            s.removeAttr("id name rel").find("[id],[name],[rel]").removeAttr("id name rel"),
            s.css({
                position: "static",
                visibility: "hidden",
                display: "block"
            }).prependTo(n.container).addClass("cycle-sentinel cycle-slide").removeClass("cycle-slide-active"),
            s.find("*").css("visibility", "hidden"),
            n._sentinel = s
        }
    }
    function i(t, i) {
        var n = 0
          , s = -1;
        return i.slides.each(function(t) {
            var i = e(this).height();
            i > s && (s = i,
            n = t)
        }),
        n
    }
    function n(t, i, n, s) {
        var o = e(s).outerHeight()
          , c = i.sync ? i.speed / 2 : i.speed;
        i.container.animate({
            height: o
        }, c)
    }
    function s(i, o) {
        o._autoHeightOnResize && (e(window).off("resize orientationchange", o._autoHeightOnResize),
        o._autoHeightOnResize = null),
        o.container.off("cycle-slide-added cycle-slide-removed", t),
        o.container.off("cycle-destroyed", s),
        o.container.off("cycle-before", n),
        o._sentinel && (o._sentinel.remove(),
        o._sentinel = null)
    }
    e.extend(e.fn.cycle.defaults, {
        autoHeight: 0
    }),
    e(document).on("cycle-initialized", function(i, o) {
        function c() {
            t(i, o)
        }
        var r, l = o.autoHeight, a = e.type(l), d = null;
        ("string" === a || "number" === a) && (o.container.on("cycle-slide-added cycle-slide-removed", t),
        o.container.on("cycle-destroyed", s),
        "container" == l ? o.container.on("cycle-before", n) : "string" === a && /\d+\:\d+/.test(l) && (r = l.match(/(\d+)\:(\d+)/),
        r = r[1] / r[2],
        o._autoHeightRatio = r),
        "number" !== a && (o._autoHeightOnResize = function() {
            clearTimeout(d),
            d = setTimeout(c, 50)
        }
        ,
        e(window).on("resize orientationchange", o._autoHeightOnResize)),
        setTimeout(c, 30))
    })
}(jQuery),
function(e) {
    "use strict";
    e.extend(e.fn.cycle.defaults, {
        caption: "> .cycle-caption",
        captionTemplate: "{{slideNum}} / {{slideCount}}",
        overlay: "> .cycle-overlay",
        overlayTemplate: "<div>{{title}}</div><div>{{desc}}</div>",
        captionModule: "caption"
    }),
    e(document).on("cycle-update-view", function(t, i, n, s) {
        "caption" === i.captionModule && e.each(["caption", "overlay"], function() {
            var e = this
              , t = n[e + "Template"]
              , o = i.API.getComponent(e);
            o.length && t ? (o.html(i.API.tmpl(t, n, i, s)),
            o.show()) : o.hide()
        })
    }),
    e(document).on("cycle-destroyed", function(t, i) {
        var n;
        e.each(["caption", "overlay"], function() {
            var e = this
              , t = i[e + "Template"];
            i[e] && t && (n = i.API.getComponent("caption"),
            n.empty())
        })
    })
}(jQuery),
function(e) {
    "use strict";
    var t = e.fn.cycle;
    e.fn.cycle = function(i) {
        var n, s, o, c = e.makeArray(arguments);
        return "number" == e.type(i) ? this.cycle("goto", i) : "string" == e.type(i) ? this.each(function() {
            var r;
            return n = i,
            o = e(this).data("cycle.opts"),
            void 0 === o ? (t.log('slideshow must be initialized before sending commands; "' + n + '" ignored'),
            void 0) : (n = "goto" == n ? "jump" : n,
            s = o.API[n],
            e.isFunction(s) ? (r = e.makeArray(c),
            r.shift(),
            s.apply(o.API, r)) : (t.log("unknown command: ", n),
            void 0))
        }) : t.apply(this, arguments)
    }
    ,
    e.extend(e.fn.cycle, t),
    e.extend(t.API, {
        next: function() {
            var e = this.opts();
            if (!e.busy || e.manualTrump) {
                var t = e.reverse ? -1 : 1;
                e.allowWrap === !1 && e.currSlide + t >= e.slideCount || (e.API.advanceSlide(t),
                e.API.trigger("cycle-next", [e]).log("cycle-next"))
            }
        },
        prev: function() {
            var e = this.opts();
            if (!e.busy || e.manualTrump) {
                var t = e.reverse ? 1 : -1;
                e.allowWrap === !1 && 0 > e.currSlide + t || (e.API.advanceSlide(t),
                e.API.trigger("cycle-prev", [e]).log("cycle-prev"))
            }
        },
        destroy: function() {
            var e = this.opts();
            clearTimeout(e.timeoutId),
            e.timeoutId = 0,
            e.API.stop(),
            e.API.trigger("cycle-destroyed", [e]).log("cycle-destroyed"),
            e.container.removeData("cycle.opts"),
            e.retainStylesOnDestroy || (e.container.removeAttr("style"),
            e.slides.removeAttr("style"),
            e.slides.removeClass("cycle-slide-active"))
        },
        jump: function(e) {
            var t, i = this.opts();
            if (!i.busy || i.manualTrump) {
                var n = parseInt(e, 10);
                if (isNaN(n) || 0 > n || n >= i.slides.length)
                    return i.API.log("goto: invalid slide index: " + n),
                    void 0;
                if (n == i.currSlide)
                    return i.API.log("goto: skipping, already on slide", n),
                    void 0;
                i.nextSlide = n,
                clearTimeout(i.timeoutId),
                i.timeoutId = 0,
                i.API.log("goto: ", n, " (zero-index)"),
                t = i.currSlide < i.nextSlide,
                i.API.prepareTx(!0, t)
            }
        },
        stop: function() {
            var t = this.opts()
              , i = t.container;
            clearTimeout(t.timeoutId),
            t.timeoutId = 0,
            t.API.stopTransition(),
            t.pauseOnHover && (t.pauseOnHover !== !0 && (i = e(t.pauseOnHover)),
            i.off("mouseenter mouseleave")),
            t.API.trigger("cycle-stopped", [t]).log("cycle-stopped")
        },
        reinit: function() {
            var e = this.opts();
            e.API.destroy(),
            e.container.cycle()
        },
        remove: function(t) {
            for (var i, n, s = this.opts(), o = [], c = 1, r = 0; s.slides.length > r; r++)
                i = s.slides[r],
                r == t ? n = i : (o.push(i),
                e(i).data("cycle.opts").slideNum = c,
                c++);
            n && (s.slides = e(o),
            s.slideCount--,
            e(n).remove(),
            t == s.currSlide && s.API.advanceSlide(1),
            s.API.trigger("cycle-slide-removed", [s, t, n]).log("cycle-slide-removed"),
            s.API.updateView())
        }
    }),
    e(document).on("click.cycle", "[data-cycle-cmd]", function(t) {
        t.preventDefault();
        var i = e(this)
          , n = i.data("cycle-cmd")
          , s = i.data("cycle-context") || ".cycle-slideshow";
        e(s).cycle(n, i.data("cycle-arg"))
    })
}(jQuery),
function(e) {
    "use strict";
    function t(t, i) {
        var n;
        return t._hashFence ? (t._hashFence = !1,
        void 0) : (n = window.location.hash.substring(1),
        t.slides.each(function(s) {
            return e(this).data("cycle-hash") == n ? (i === !0 ? t.startingSlide = s : (t.nextSlide = s,
            t.API.prepareTx(!0, !1)),
            !1) : void 0
        }),
        void 0)
    }
    e(document).on("cycle-pre-initialize", function(i, n) {
        t(n, !0),
        n._onHashChange = function() {
            t(n, !1)
        }
        ,
        e(window).on("hashchange", n._onHashChange)
    }),
    e(document).on("cycle-update-view", function(e, t, i) {
        i.hash && (t._hashFence = !0,
        window.location.hash = i.hash)
    }),
    e(document).on("cycle-destroyed", function(t, i) {
        i._onHashChange && e(window).off("hashchange", i._onHashChange)
    })
}(jQuery),
function(e) {
    "use strict";
    e.extend(e.fn.cycle.defaults, {
        loader: !1
    }),
    e(document).on("cycle-bootstrap", function(t, i) {
        function n(t, n) {
            function o(t) {
                var o;
                "wait" == i.loader ? (r.push(t),
                0 === a && (r.sort(c),
                s.apply(i.API, [r, n]),
                i.container.removeClass("cycle-loading"))) : (o = e(i.slides[i.currSlide]),
                s.apply(i.API, [t, n]),
                o.show(),
                i.container.removeClass("cycle-loading"))
            }
            function c(e, t) {
                return e.data("index") - t.data("index")
            }
            var r = [];
            if ("string" == e.type(t))
                t = e.trim(t);
            else if ("array" === e.type(t))
                for (var l = 0; t.length > l; l++)
                    t[l] = e(t[l])[0];
            t = e(t);
            var a = t.length;
            a && (t.hide().appendTo("body").each(function(t) {
                function c() {
                    0 === --l && (--a,
                    o(d))
                }
                var l = 0
                  , d = e(this)
                  , u = d.is("img") ? d : d.find("img");
                return d.data("index", t),
                u = u.filter(":not(.cycle-loader-ignore)").filter(':not([src=""])'),
                u.length ? (l = u.length,
                u.each(function() {
                    this.complete ? c() : e(this).load(function() {
                        c()
                    }).error(function() {
                        0 === --l && (i.API.log("slide skipped; img not loaded:", this.src),
                        0 === --a && "wait" == i.loader && s.apply(i.API, [r, n]))
                    })
                }),
                void 0) : (--a,
                r.push(d),
                void 0)
            }),
            a && i.container.addClass("cycle-loading"))
        }
        var s;
        i.loader && (s = i.API.add,
        i.API.add = n)
    })
}(jQuery),
function(e) {
    "use strict";
    function t(t, i, n) {
        var s, o = t.API.getComponent("pager");
        o.each(function() {
            var o = e(this);
            if (i.pagerTemplate) {
                var c = t.API.tmpl(i.pagerTemplate, i, t, n[0]);
                s = e(c).appendTo(o)
            } else
                s = o.children().eq(t.slideCount - 1);
            s.on(t.pagerEvent, function(e) {
                e.preventDefault(),
                t.API.page(o, e.currentTarget)
            })
        })
    }
    function i(e, t) {
        var i = this.opts();
        if (!i.busy || i.manualTrump) {
            var n = e.children().index(t)
              , s = n
              , o = s > i.currSlide;
            i.currSlide != s && (i.nextSlide = s,
            i.API.prepareTx(!0, o),
            i.API.trigger("cycle-pager-activated", [i, e, t]))
        }
    }
    e.extend(e.fn.cycle.defaults, {
        pager: "> .cycle-pager",
        pagerActiveClass: "cycle-pager-active",
        pagerEvent: "click.cycle",
        pagerTemplate: "<span>•</span>"
    }),
    e(document).on("cycle-bootstrap", function(e, i, n) {
        n.buildPagerLink = t
    }),
    e(document).on("cycle-slide-added", function(e, t, n, s) {
        t.pager && (t.API.buildPagerLink(t, n, s),
        t.API.page = i)
    }),
    e(document).on("cycle-slide-removed", function(t, i, n) {
        if (i.pager) {
            var s = i.API.getComponent("pager");
            s.each(function() {
                var t = e(this);
                e(t.children()[n]).remove()
            })
        }
    }),
    e(document).on("cycle-update-view", function(t, i) {
        var n;
        i.pager && (n = i.API.getComponent("pager"),
        n.each(function() {
            e(this).children().removeClass(i.pagerActiveClass).eq(i.currSlide).addClass(i.pagerActiveClass)
        }))
    }),
    e(document).on("cycle-destroyed", function(e, t) {
        var i;
        t.pager && t.pagerTemplate && (i = t.API.getComponent("pager"),
        i.empty())
    })
}(jQuery),
function(e) {
    "use strict";
    e.extend(e.fn.cycle.defaults, {
        next: "> .cycle-next",
        nextEvent: "click.cycle",
        disabledClass: "disabled",
        prev: "> .cycle-prev",
        prevEvent: "click.cycle",
        swipe: !1
    }),
    e(document).on("cycle-initialized", function(e, t) {
        if (t.API.getComponent("next").on(t.nextEvent, function(e) {
            e.preventDefault(),
            t.API.next()
        }),
        t.API.getComponent("prev").on(t.prevEvent, function(e) {
            e.preventDefault(),
            t.API.prev()
        }),
        t.swipe) {
            var i = t.swipeVert ? "swipeUp.cycle" : "swipeLeft.cycle swipeleft.cycle"
              , n = t.swipeVert ? "swipeDown.cycle" : "swipeRight.cycle swiperight.cycle";
            t.container.on(i, function() {
                t.API.next()
            }),
            t.container.on(n, function() {
                t.API.prev()
            })
        }
    }),
    e(document).on("cycle-update-view", function(e, t) {
        if (!t.allowWrap) {
            var i = t.disabledClass
              , n = t.API.getComponent("next")
              , s = t.API.getComponent("prev")
              , o = t._prevBoundry || 0
              , c = t._nextBoundry || t.slideCount - 1;
            t.currSlide == c ? n.addClass(i).prop("disabled", !0) : n.removeClass(i).prop("disabled", !1),
            t.currSlide === o ? s.addClass(i).prop("disabled", !0) : s.removeClass(i).prop("disabled", !1)
        }
    }),
    e(document).on("cycle-destroyed", function(e, t) {
        t.API.getComponent("prev").off(t.nextEvent),
        t.API.getComponent("next").off(t.prevEvent),
        t.container.off("swipeleft.cycle swiperight.cycle swipeLeft.cycle swipeRight.cycle swipeUp.cycle swipeDown.cycle")
    })
}(jQuery),
function(e) {
    "use strict";
    e.extend(e.fn.cycle.defaults, {
        progressive: !1
    }),
    e(document).on("cycle-pre-initialize", function(t, i) {
        if (i.progressive) {
            var n, s, o = i.API, c = o.next, r = o.prev, l = o.prepareTx, a = e.type(i.progressive);
            if ("array" == a)
                n = i.progressive;
            else if (e.isFunction(i.progressive))
                n = i.progressive(i);
            else if ("string" == a) {
                if (s = e(i.progressive),
                n = e.trim(s.html()),
                !n)
                    return;
                if (/^(\[)/.test(n))
                    try {
                        n = e.parseJSON(n)
                    } catch (d) {
                        return o.log("error parsing progressive slides", d),
                        void 0
                    }
                else
                    n = n.split(RegExp(s.data("cycle-split") || "\n")),
                    n[n.length - 1] || n.pop()
            }
            l && (o.prepareTx = function(e, t) {
                var s, o;
                return e || 0 === n.length ? (l.apply(i.API, [e, t]),
                void 0) : (t && i.currSlide == i.slideCount - 1 ? (o = n[0],
                n = n.slice(1),
                i.container.one("cycle-slide-added", function(e, t) {
                    setTimeout(function() {
                        t.API.advanceSlide(1)
                    }, 50)
                }),
                i.API.add(o)) : t || 0 !== i.currSlide ? l.apply(i.API, [e, t]) : (s = n.length - 1,
                o = n[s],
                n = n.slice(0, s),
                i.container.one("cycle-slide-added", function(e, t) {
                    setTimeout(function() {
                        t.currSlide = 1,
                        t.API.advanceSlide(-1)
                    }, 50)
                }),
                i.API.add(o, !0)),
                void 0)
            }
            ),
            c && (o.next = function() {
                var e = this.opts();
                if (n.length && e.currSlide == e.slideCount - 1) {
                    var t = n[0];
                    n = n.slice(1),
                    e.container.one("cycle-slide-added", function(e, t) {
                        c.apply(t.API),
                        t.container.removeClass("cycle-loading")
                    }),
                    e.container.addClass("cycle-loading"),
                    e.API.add(t)
                } else
                    c.apply(e.API)
            }
            ),
            r && (o.prev = function() {
                var e = this.opts();
                if (n.length && 0 === e.currSlide) {
                    var t = n.length - 1
                      , i = n[t];
                    n = n.slice(0, t),
                    e.container.one("cycle-slide-added", function(e, t) {
                        t.currSlide = 1,
                        t.API.advanceSlide(-1),
                        t.container.removeClass("cycle-loading")
                    }),
                    e.container.addClass("cycle-loading"),
                    e.API.add(i, !0)
                } else
                    r.apply(e.API)
            }
            )
        }
    })
}(jQuery),
function(e) {
    "use strict";
    e.extend(e.fn.cycle.defaults, {
        tmplRegex: "{{((.)?.*?)}}"
    }),
    e.extend(e.fn.cycle.API, {
        tmpl: function(t, i) {
            var n = RegExp(i.tmplRegex || e.fn.cycle.defaults.tmplRegex, "g")
              , s = e.makeArray(arguments);
            return s.shift(),
            t.replace(n, function(t, i) {
                var n, o, c, r, l = i.split(".");
                for (n = 0; s.length > n; n++)
                    if (c = s[n]) {
                        if (l.length > 1)
                            for (r = c,
                            o = 0; l.length > o; o++)
                                c = r,
                                r = r[l[o]] || i;
                        else
                            r = c[i];
                        if (e.isFunction(r))
                            return r.apply(c, s);
                        if (void 0 !== r && null !== r && r != i)
                            return r
                    }
                return i
            })
        }
    })
}(jQuery);
//Cycle2 ends

/* Vertical Plugin for Cycle2; Copyright (c) 2012 M. Alsup; v20140128 */
(function(e) {
    "use strict";
    e.fn.cycle.transitions.scrollVert = {
        before: function(e, i, t, n) {
            e.API.stackSlides(e, i, t, n);
            var s = e.container.css("overflow", "hidden").height();
            e.cssBefore = {
                top: n ? -s : s,
                left: 0,
                opacity: 1,
                display: "block",
                visibility: "visible"
            },
            e.animIn = {
                top: 0
            },
            e.animOut = {
                top: n ? s : -s
            }
        }
    }
}
)(jQuery);

/* Carousel Plugin for Cycle2; Copyright (c) 2012 M. Alsup; v20140114 */
(function(e) {
    "use strict";
    e(document).on("cycle-bootstrap", function(e, t, i) {
        "carousel" === t.fx && (i.getSlideIndex = function(e) {
            var t = this.opts()._carouselWrap.children()
              , i = t.index(e);
            return i % t.length
        }
        ,
        i.next = function() {
            var e = t.reverse ? -1 : 1;
            t.allowWrap === !1 && t.currSlide + e > t.slideCount - t.carouselVisible || (t.API.advanceSlide(e),
            t.API.trigger("cycle-next", [t]).log("cycle-next"))
        }
        )
    }),
    e.fn.cycle.transitions.carousel = {
        preInit: function(t) {
            t.hideNonActive = !1,
            t.container.on("cycle-destroyed", e.proxy(this.onDestroy, t.API)),
            t.API.stopTransition = this.stopTransition;
            for (var i = 0; t.startingSlide > i; i++)
                t.container.append(t.slides[0])
        },
        postInit: function(t) {
            var i, n, s, o, r = t.carouselVertical;
            t.carouselVisible && t.carouselVisible > t.slideCount && (t.carouselVisible = t.slideCount - 1);
            var l = t.carouselVisible || t.slides.length
              , c = {
                display: r ? "block" : "inline-block",
                position: "static"
            };
            if (t.container.css({
                position: "relative",
                overflow: "hidden"
            }),
            t.slides.css(c),
            t._currSlide = t.currSlide,
            o = e('<div class="cycle-carousel-wrap"></div>').prependTo(t.container).css({
                margin: 0,
                padding: 0,
                top: 0,
                left: 0,
                position: "absolute"
            }).append(t.slides),
            t._carouselWrap = o,
            r || o.css("white-space", "nowrap"),
            t.allowWrap !== !1) {
                for (n = 0; (void 0 === t.carouselVisible ? 2 : 1) > n; n++) {
                    for (i = 0; t.slideCount > i; i++)
                        o.append(t.slides[i].cloneNode(!0));
                    for (i = t.slideCount; i--; )
                        o.prepend(t.slides[i].cloneNode(!0))
                }
                o.find(".cycle-slide-active").removeClass("cycle-slide-active"),
                t.slides.eq(t.startingSlide).addClass("cycle-slide-active")
            }
            t.pager && t.allowWrap === !1 && (s = t.slideCount - l,
            e(t.pager).children().filter(":gt(" + s + ")").hide()),
            t._nextBoundry = t.slideCount - t.carouselVisible,
            this.prepareDimensions(t)
        },
        prepareDimensions: function(t) {
            var i, n, s, o, r = t.carouselVertical, l = t.carouselVisible || t.slides.length;
            if (t.carouselFluid && t.carouselVisible ? t._carouselResizeThrottle || this.fluidSlides(t) : t.carouselVisible && t.carouselSlideDimension ? (i = l * t.carouselSlideDimension,
            t.container[r ? "height" : "width"](i)) : t.carouselVisible && (i = l * e(t.slides[0])[r ? "outerHeight" : "outerWidth"](!0),
            t.container[r ? "height" : "width"](i)),
            n = t.carouselOffset || 0,
            t.allowWrap !== !1)
                if (t.carouselSlideDimension)
                    n -= (t.slideCount + t.currSlide) * t.carouselSlideDimension;
                else
                    for (s = t._carouselWrap.children(),
                    o = 0; t.slideCount + t.currSlide > o; o++)
                        n -= e(s[o])[r ? "outerHeight" : "outerWidth"](!0);
            t._carouselWrap.css(r ? "top" : "left", n)
        },
        fluidSlides: function(t) {
            function i() {
                clearTimeout(s),
                s = setTimeout(n, 20)
            }
            function n() {
                t._carouselWrap.stop(!1, !0);
                var e = t.container.width() / t.carouselVisible;
                e = Math.ceil(e - r),
                t._carouselWrap.children().width(e),
                t._sentinel && t._sentinel.width(e),
                l(t)
            }
            var s, o = t.slides.eq(0), r = o.outerWidth() - o.width(), l = this.prepareDimensions;
            e(window).on("resize", i),
            t._carouselResizeThrottle = i,
            n()
        },
        transition: function(t, i, n, s, o) {
            var r, l = {}, c = t.nextSlide - t.currSlide, a = t.carouselVertical, d = t.speed;
            if (t.allowWrap === !1) {
                s = c > 0;
                var u = t._currSlide
                  , p = t.slideCount - t.carouselVisible;
                c > 0 && t.nextSlide > p && u == p ? c = 0 : c > 0 && t.nextSlide > p ? c = t.nextSlide - u - (t.nextSlide - p) : 0 > c && t.currSlide > p && t.nextSlide > p ? c = 0 : 0 > c && t.currSlide > p ? c += t.currSlide - p : u = t.currSlide,
                r = this.getScroll(t, a, u, c),
                t.API.opts()._currSlide = t.nextSlide > p ? p : t.nextSlide
            } else
                s && 0 === t.nextSlide ? (r = this.getDim(t, t.currSlide, a),
                o = this.genCallback(t, s, a, o)) : s || t.nextSlide != t.slideCount - 1 ? r = this.getScroll(t, a, t.currSlide, c) : (r = this.getDim(t, t.currSlide, a),
                o = this.genCallback(t, s, a, o));
            l[a ? "top" : "left"] = s ? "-=" + r : "+=" + r,
            t.throttleSpeed && (d = r / e(t.slides[0])[a ? "height" : "width"]() * t.speed),
            t._carouselWrap.animate(l, d, t.easing, o)
        },
        getDim: function(t, i, n) {
            var s = e(t.slides[i]);
            return s[n ? "outerHeight" : "outerWidth"](!0)
        },
        getScroll: function(e, t, i, n) {
            var s, o = 0;
            if (n > 0)
                for (s = i; i + n > s; s++)
                    o += this.getDim(e, s, t);
            else
                for (s = i; s > i + n; s--)
                    o += this.getDim(e, s, t);
            return o
        },
        genCallback: function(t, i, n, s) {
            return function() {
                var i = e(t.slides[t.nextSlide]).position()
                  , o = 0 - i[n ? "top" : "left"] + (t.carouselOffset || 0);
                t._carouselWrap.css(t.carouselVertical ? "top" : "left", o),
                s()
            }
        },
        stopTransition: function() {
            var e = this.opts();
            e.slides.stop(!1, !0),
            e._carouselWrap.stop(!1, !0)
        },
        onDestroy: function() {
            var t = this.opts();
            t._carouselResizeThrottle && e(window).off("resize", t._carouselResizeThrottle),
            t.slides.prependTo(t.container),
            t._carouselWrap.remove()
        }
    }
}
)(jQuery);

function numbersonly(myfield, e, dec) {
    var key;
    var keychar;
    if (window.event)
        key = window.event.keyCode;
    else if (e)
        key = e.which;
    else
        return true;
    keychar = String.fromCharCode(key);
    if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 13) || (key == 27))
        return true;
    else if ((("0123456789").indexOf(keychar) > -1))
        return true;
    else if (dec && (keychar == ".")) {
        myfield.form.elements[dec].focus();
        return false
    } else
        return false
}
$(function() {
    $("li:first-child").addClass("first");
    $("li:last-child").addClass("last");
    $("tr:nth-child(odd)").addClass("alter");
    $('[href="#"]').attr("href", "javascript:;");
    now = new Date;
    thecopyrightYear = now.getYear();
    if (thecopyrightYear < 1900)
        thecopyrightYear = thecopyrightYear + 1900;
    $("#cur-date").replaceWith('<span id="cur-date">' + thecopyrightYear + "</span>")

    // Country List Data Fill
    var ctrycode = 1
      , calby = "noip";
    //------------------------------Change Country Code here if required.
    $.ajax({
        type: "GET",
        url: "/assets2/js/countrylist.xml",
        dataType: "xml",
        success: function(xml) {
            $(xml).find('country').each(function() {
                var name = $(this).find('name').text();
                var abbr = $(this).find('abbr').text();
                var code = $(this).find('code').text();
                $('.jform select.countrylist').append('<option value="' + code + '" data-abbr="' + abbr + '">' + name + '</option>');
                if (calby == "noip") {
                    /* Static Country Select */
                    $('.jform select.countrylist option[value="' + ctrycode + '"]').attr('selected', 'selected');
                    $('.jform input[name="code"]').val('+' + ctrycode);
                    $('.jform input[name="ctry"]').val($('.jform select.countrylist option:selected').html());
                } else if (calby == "ip") {
                    /* Geo IP Country Select */
                    var ctrycode1 = geoip_country_code()
                      , tgtctry = $('.jform select.countrylist option[data-abbr="' + ctrycode1 + '"]');
                    tgtctry.attr('selected', 'selected');
                    $('.jform input[name="code"]').val('+' + tgtctry.attr('value'));
                    $('.jform input[name="ctry"]').val($('.jform select.countrylist option:selected').html());
                }
            })
        }
    });

    // Code change on select
    $('.jform select.countrylist[name="pc"]').each(function() {
        var id = $(this).parents('.jform').parent().attr('id');
        $(this).bind('change', function() {
            var cval = $(this).children('option:selected').attr('value');
            cnam = $(this).children('option:selected').html();
            $('#' + id + ' .jform input[name="code"]').val('+' + cval);
            $('#' + id + ' .jform input[name="ctry"]').val(cnam)
        });
        $('#' + id + ' .jform select.countrylist[name="apc"]').bind('change', function() {
            var cval = $(this).children('option:selected').attr('value');
            $('#' + id + ' .jform input[name="acode"]').val('+' + cval)
        });
    });

    // Numbers only for phone number field
    $('[name="pn"]').each(function() {
        if ($(this).attr('type') == "text") {
            $(this).attr('onkeypress', 'return numbersonly(this, event)');
        }
        $(this).attr('minlength', 7)
    });
    $('[name="cn"]').each(function() {
        $(this).attr('minlength', 2)
    })
    // Password No space
    $('input[type="password"]').keypress(function(e) {
        if (e.which === 32)
            return false;
    });

    if ($.browser.msie && $.browser.version <= 9) {
        $('input[type="text"], input[type="password"], input[type="email"], textarea').each(function() {
            var txtvalue = $(this).attr('placeholder');
            $(this).attr('value', txtvalue)
        });
        $('input[type="text"], input[type="password"], input[type="email"], textarea').on('focus', function() {
            var maintxt = $(this).attr('placeholder');
            if ($(this).attr('value') == maintxt) {
                $(this).attr('value', '')
            }
        }).blur(function() {
            var maintxt = $(this).attr('placeholder');
            if ($(this).attr('value') == '') {
                $(this).attr('value', maintxt)
            }
        })
    }

    // Validations ------------------------------------------------------------------
    $('.validate').each(function() {
        var id = $(this).parent().attr('id')
          , cnval = $('#' + id + ' .jform').find('[name="cn"]').attr('placeholder');
        var msgval = $('#' + id + ' .jform').find('[name="msg"]').attr('placeholder');
        pwdval = $('#' + id + ' .jform').find('[name="pwd"]').attr('placeholder');
        if ($.browser.msie && $.browser.version <= 9) {
            jQuery.validator.addMethod("iecn", function(value, element) {
                switch (element.value) {
                case cnval:
                    if (element.name == cnval)
                        return false;
                    break;
                default:
                    return true;
                    break;
                }
            });
            jQuery.validator.addMethod("iemsg", function(value, element) {
                switch (element.value) {
                case $(element).attr('placeholder'):
                    if (element.value == $(element).attr('placeholder'))
                        return false;
                    break;
                default:
                    return true;
                    break;
                }
            });

        }
        jQuery.validator.addMethod("alphanumeric", function(value, element) {
            return this.optional(element) || /^[A-Za-z-.\s\']+$/i.test(value);
        }, "Letters, numbers, and underscores only please");
        $('#' + id + ' .jform').validate();
    });

    $(window).load(function() {
        var num = 0;
        $('.placeholder').each(function() {
            num++;
            var ithis = $(this)
              , pval = ithis.attr('placeholder')
              , namval = ithis.attr('name');
            ithis.removeAttr('placeholder');
            ithis.parent().prepend('<input type="text" name="phtxt' + num + '" class="phtxt ' + namval + '-holder" value="' + pval + '" />');
            ithis.hide();
            ithis.parent().children('.phtxt').on('focus', function() {
                $(this).hide();
                ithis.show().trigger('focus');
            });
            ithis.on('blur', function() {
                if (ithis.hasClass('error')) {
                    $(this).parent().children('.phtxt').addClass('error');
                } else {
                    $(this).parent().children('.phtxt').removeClass('error');
                }
                if (!ithis.val()) {
                    $(this).hide();
                    $(this).parent().children('.phtxt').show();
                }
            });
        });
    });

})

function goToByScroll(e) {
    $("html,body").animate({
        scrollTop: $(e).offset().top
    }, 1e3, "", function() {
        $(this).stop(true, true)
    })
}
function frameheight(e) {
    setInterval("function(){var ht = $(tgt).contents().find('body').height();if($(tgt).height()!=ht){$(tgt).height(ht);}}", 100)
}
(function(a) {
    a.extend(a.fn, {
        validate: function(b) {
            if (!this.length) {
                b && b.debug && window.console && console.warn("nothing selected, can't validate, returning nothing");
                return
            }
            var c = a.data(this[0], "validator");
            return c ? c : (this.attr("novalidate", "novalidate"),
            c = new a.validator(b,this[0]),
            a.data(this[0], "validator", c),
            c.settings.onsubmit && (this.validateDelegate(":submit", "click", function(b) {
                c.settings.submitHandler && (c.submitButton = b.target),
                a(b.target).hasClass("cancel") && (c.cancelSubmit = !0)
            }),
            this.submit(function(b) {
                function d() {
                    var d;
                    return c.settings.submitHandler ? (c.submitButton && (d = a("<input type='hidden'/>").attr("name", c.submitButton.name).val(c.submitButton.value).appendTo(c.currentForm)),
                    c.settings.submitHandler.call(c, c.currentForm, b),
                    c.submitButton && d.remove(),
                    !1) : !0
                }
                return c.settings.debug && b.preventDefault(),
                c.cancelSubmit ? (c.cancelSubmit = !1,
                d()) : c.form() ? c.pendingRequest ? (c.formSubmitted = !0,
                !1) : d() : (c.focusInvalid(),
                !1)
            })),
            c)
        },
        valid: function() {
            if (a(this[0]).is("form"))
                return this.validate().form();
            var b = !0
              , c = a(this[0].form).validate();
            return this.each(function() {
                b &= c.element(this)
            }),
            b
        },
        removeAttrs: function(b) {
            var c = {}
              , d = this;
            return a.each(b.split(/\s/), function(a, b) {
                c[b] = d.attr(b),
                d.removeAttr(b)
            }),
            c
        },
        rules: function(b, c) {
            var d = this[0];
            if (b) {
                var e = a.data(d.form, "validator").settings
                  , f = e.rules
                  , g = a.validator.staticRules(d);
                switch (b) {
                case "add":
                    a.extend(g, a.validator.normalizeRule(c)),
                    f[d.name] = g,
                    c.messages && (e.messages[d.name] = a.extend(e.messages[d.name], c.messages));
                    break;
                case "remove":
                    if (!c)
                        return delete f[d.name],
                        g;
                    var h = {};
                    return a.each(c.split(/\s/), function(a, b) {
                        h[b] = g[b],
                        delete g[b]
                    }),
                    h
                }
            }
            var i = a.validator.normalizeRules(a.extend({}, a.validator.metadataRules(d), a.validator.classRules(d), a.validator.attributeRules(d), a.validator.staticRules(d)), d);
            if (i.required) {
                var j = i.required;
                delete i.required,
                i = a.extend({
                    required: j
                }, i)
            }
            return i
        }
    }),
    a.extend(a.expr[":"], {
        blank: function(b) {
            return !a.trim("" + b.value)
        },
        filled: function(b) {
            return !!a.trim("" + b.value)
        },
        unchecked: function(a) {
            return !a.checked
        }
    }),
    a.validator = function(b, c) {
        this.settings = a.extend(!0, {}, a.validator.defaults, b),
        this.currentForm = c,
        this.init()
    }
    ,
    a.validator.format = function(b, c) {
        return arguments.length === 1 ? function() {
            var c = a.makeArray(arguments);
            return c.unshift(b),
            a.validator.format.apply(this, c)
        }
        : (arguments.length > 2 && c.constructor !== Array && (c = a.makeArray(arguments).slice(1)),
        c.constructor !== Array && (c = [c]),
        a.each(c, function(a, c) {
            b = b.replace(new RegExp("\\{" + a + "\\}","g"), c)
        }),
        b)
    }
    ,
    a.extend(a.validator, {
        defaults: {
            messages: {},
            groups: {},
            rules: {},
            errorClass: "error",
            validClass: "valid",
            errorElement: "label",
            focusInvalid: !0,
            errorContainer: a([]),
            errorLabelContainer: a([]),
            onsubmit: !0,
            ignore: ":hidden",
            ignoreTitle: !1,
            onfocusin: function(a, b) {
                this.lastActive = a,
                this.settings.focusCleanup && !this.blockFocusCleanup && (this.settings.unhighlight && this.settings.unhighlight.call(this, a, this.settings.errorClass, this.settings.validClass),
                this.addWrapper(this.errorsFor(a)).hide())
            },
            onfocusout: function(a, b) {
                !this.checkable(a) && (a.name in this.submitted || !this.optional(a)) && this.element(a)
            },
            onkeyup: function(a, b) {
                if (b.which === 9 && this.elementValue(a) === "")
                    return;
                (a.name in this.submitted || a === this.lastActive) && this.element(a)
            },
            onclick: function(a, b) {
                a.name in this.submitted ? this.element(a) : a.parentNode.name in this.submitted && this.element(a.parentNode)
            },
            highlight: function(b, c, d) {
                b.type === "radio" ? this.findByName(b.name).addClass(c).removeClass(d) : a(b).addClass(c).removeClass(d)
            },
            unhighlight: function(b, c, d) {
                b.type === "radio" ? this.findByName(b.name).removeClass(c).addClass(d) : a(b).removeClass(c).addClass(d)
            }
        },
        setDefaults: function(b) {
            a.extend(a.validator.defaults, b)
        },
        messages: {
            required: "This field is required.",
            remote: "Please fix this field.",
            email: "Please enter a valid email address.",
            url: "Please enter a valid URL.",
            date: "Please enter a valid date.",
            dateISO: "Please enter a valid date (ISO).",
            number: "Please enter a valid number.",
            digits: "Please enter only digits.",
            creditcard: "Please enter a valid credit card number.",
            equalTo: "Please enter the same value again.",
            maxlength: a.validator.format("Please enter no more than {0} characters."),
            minlength: a.validator.format("Please enter at least {0} characters."),
            rangelength: a.validator.format("Please enter a value between {0} and {1} characters long."),
            range: a.validator.format("Please enter a value between {0} and {1}."),
            max: a.validator.format("Please enter a value less than or equal to {0}."),
            min: a.validator.format("Please enter a value greater than or equal to {0}.")
        },
        autoCreateRanges: !1,
        prototype: {
            init: function() {
                function d(b) {
                    var c = a.data(this[0].form, "validator")
                      , d = "on" + b.type.replace(/^validate/, "");
                    c.settings[d] && c.settings[d].call(c, this[0], b)
                }
                this.labelContainer = a(this.settings.errorLabelContainer),
                this.errorContext = this.labelContainer.length && this.labelContainer || a(this.currentForm),
                this.containers = a(this.settings.errorContainer).add(this.settings.errorLabelContainer),
                this.submitted = {},
                this.valueCache = {},
                this.pendingRequest = 0,
                this.pending = {},
                this.invalid = {},
                this.reset();
                var b = this.groups = {};
                a.each(this.settings.groups, function(c, d) {
                    a.each(d.split(/\s/), function(a, d) {
                        b[d] = c
                    })
                });
                var c = this.settings.rules;
                a.each(c, function(b, d) {
                    c[b] = a.validator.normalizeRule(d)
                }),
                a(this.currentForm).validateDelegate(":text, [type='password'], [type='file'], select, textarea, [type='number'], [type='search'] ,[type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'] ", "focusin focusout keyup", d).validateDelegate("[type='radio'], [type='checkbox'], select, option", "click", d),
                this.settings.invalidHandler && a(this.currentForm).bind("invalid-form.validate", this.settings.invalidHandler)
            },
            form: function() {
                return this.checkForm(),
                a.extend(this.submitted, this.errorMap),
                this.invalid = a.extend({}, this.errorMap),
                this.valid() || a(this.currentForm).triggerHandler("invalid-form", [this]),
                this.showErrors(),
                this.valid()
            },
            checkForm: function() {
                this.prepareForm();
                for (var a = 0, b = this.currentElements = this.elements(); b[a]; a++)
                    this.check(b[a]);
                return this.valid()
            },
            element: function(b) {
                b = this.validationTargetFor(this.clean(b)),
                this.lastElement = b,
                this.prepareElement(b),
                this.currentElements = a(b);
                var c = this.check(b) !== !1;
                return c ? delete this.invalid[b.name] : this.invalid[b.name] = !0,
                this.numberOfInvalids() || (this.toHide = this.toHide.add(this.containers)),
                this.showErrors(),
                c
            },
            showErrors: function(b) {
                if (b) {
                    a.extend(this.errorMap, b),
                    this.errorList = [];
                    for (var c in b)
                        this.errorList.push({
                            message: b[c],
                            element: this.findByName(c)[0]
                        });
                    this.successList = a.grep(this.successList, function(a) {
                        return !(a.name in b)
                    })
                }
                this.settings.showErrors ? this.settings.showErrors.call(this, this.errorMap, this.errorList) : this.defaultShowErrors()
            },
            resetForm: function() {
                a.fn.resetForm && a(this.currentForm).resetForm(),
                this.submitted = {},
                this.lastElement = null,
                this.prepareForm(),
                this.hideErrors(),
                this.elements().removeClass(this.settings.errorClass).removeData("previousValue")
            },
            numberOfInvalids: function() {
                return this.objectLength(this.invalid)
            },
            objectLength: function(a) {
                var b = 0;
                for (var c in a)
                    b++;
                return b
            },
            hideErrors: function() {
                this.addWrapper(this.toHide).hide()
            },
            valid: function() {
                return this.size() === 0
            },
            size: function() {
                return this.errorList.length
            },
            focusInvalid: function() {
                if (this.settings.focusInvalid)
                    try {
                        a(this.findLastActive() || this.errorList.length && this.errorList[0].element || []).filter(":visible").focus().trigger("focusin")
                    } catch (b) {}
            },
            findLastActive: function() {
                var b = this.lastActive;
                return b && a.grep(this.errorList, function(a) {
                    return a.element.name === b.name
                }).length === 1 && b
            },
            elements: function() {
                var b = this
                  , c = {};
                return a(this.currentForm).find("input, select, textarea").not(":submit, :reset, :image, [disabled]").not(this.settings.ignore).filter(function() {
                    return !this.name && b.settings.debug && window.console && console.error("%o has no name assigned", this),
                    this.name in c || !b.objectLength(a(this).rules()) ? !1 : (c[this.name] = !0,
                    !0)
                })
            },
            clean: function(b) {
                return a(b)[0]
            },
            errors: function() {
                var b = this.settings.errorClass.replace(" ", ".");
                return a(this.settings.errorElement + "." + b, this.errorContext)
            },
            reset: function() {
                this.successList = [],
                this.errorList = [],
                this.errorMap = {},
                this.toShow = a([]),
                this.toHide = a([]),
                this.currentElements = a([])
            },
            prepareForm: function() {
                this.reset(),
                this.toHide = this.errors().add(this.containers)
            },
            prepareElement: function(a) {
                this.reset(),
                this.toHide = this.errorsFor(a)
            },
            elementValue: function(b) {
                var c = a(b).attr("type")
                  , d = a(b).val();
                return c === "radio" || c === "checkbox" ? a('input[name="' + a(b).attr("name") + '"]:checked').val() : typeof d == "string" ? d.replace(/\r/g, "") : d
            },
            check: function(b) {
                b = this.validationTargetFor(this.clean(b));
                var c = a(b).rules(), d = !1, e = this.elementValue(b), f;
                for (var g in c) {
                    var h = {
                        method: g,
                        parameters: c[g]
                    };
                    try {
                        f = a.validator.methods[g].call(this, e, b, h.parameters);
                        if (f === "dependency-mismatch") {
                            d = !0;
                            continue
                        }
                        d = !1;
                        if (f === "pending") {
                            this.toHide = this.toHide.not(this.errorsFor(b));
                            return
                        }
                        if (!f)
                            return this.formatAndAdd(b, h),
                            !1
                    } catch (i) {
                        throw this.settings.debug && window.console && console.log("exception occured when checking element " + b.id + ", check the '" + h.method + "' method", i),
                        i
                    }
                }
                if (d)
                    return;
                return this.objectLength(c) && this.successList.push(b),
                !0
            },
            customMetaMessage: function(b, c) {
                if (!a.metadata)
                    return;
                var d = this.settings.meta ? a(b).metadata()[this.settings.meta] : a(b).metadata();
                return d && d.messages && d.messages[c]
            },
            customDataMessage: function(b, c) {
                return a(b).data("msg-" + c.toLowerCase()) || b.attributes && a(b).attr("data-msg-" + c.toLowerCase())
            },
            customMessage: function(a, b) {
                var c = this.settings.messages[a];
                return c && (c.constructor === String ? c : c[b])
            },
            findDefined: function() {
                for (var a = 0; a < arguments.length; a++)
                    if (arguments[a] !== undefined)
                        return arguments[a];
                return undefined
            },
            defaultMessage: function(b, c) {
                return this.findDefined(this.customMessage(b.name, c), this.customDataMessage(b, c), this.customMetaMessage(b, c), !this.settings.ignoreTitle && b.title || undefined, a.validator.messages[c], "<strong>Warning: No message defined for " + b.name + "</strong>")
            },
            formatAndAdd: function(b, c) {
                var d = this.defaultMessage(b, c.method)
                  , e = /\$?\{(\d+)\}/g;
                typeof d == "function" ? d = d.call(this, c.parameters, b) : e.test(d) && (d = a.validator.format(d.replace(e, "{$1}"), c.parameters)),
                this.errorList.push({
                    message: d,
                    element: b
                }),
                this.errorMap[b.name] = d,
                this.submitted[b.name] = d
            },
            addWrapper: function(a) {
                return this.settings.wrapper && (a = a.add(a.parent(this.settings.wrapper))),
                a
            },
            defaultShowErrors: function() {
                var a, b;
                for (a = 0; this.errorList[a]; a++) {
                    var c = this.errorList[a];
                    this.settings.highlight && this.settings.highlight.call(this, c.element, this.settings.errorClass, this.settings.validClass),
                    this.showLabel(c.element, c.message)
                }
                this.errorList.length && (this.toShow = this.toShow.add(this.containers));
                if (this.settings.success)
                    for (a = 0; this.successList[a]; a++)
                        this.showLabel(this.successList[a]);
                if (this.settings.unhighlight)
                    for (a = 0,
                    b = this.validElements(); b[a]; a++)
                        this.settings.unhighlight.call(this, b[a], this.settings.errorClass, this.settings.validClass);
                this.toHide = this.toHide.not(this.toShow),
                this.hideErrors(),
                this.addWrapper(this.toShow).show()
            },
            validElements: function() {
                return this.currentElements.not(this.invalidElements())
            },
            invalidElements: function() {
                return a(this.errorList).map(function() {
                    return this.element
                })
            },
            showLabel: function(b, c) {
                var d = this.errorsFor(b);
                d.length ? (d.removeClass(this.settings.validClass).addClass(this.settings.errorClass),
                d.attr("generated") && d.html(c)) : (d = a("<" + this.settings.errorElement + "/>").attr({
                    "for": this.idOrName(b),
                    generated: !0
                }).addClass(this.settings.errorClass).html(c || ""),
                this.settings.wrapper && (d = d.hide().show().wrap("<" + this.settings.wrapper + "/>").parent()),
                this.labelContainer.append(d).length || (this.settings.errorPlacement ? this.settings.errorPlacement(d, a(b)) : d.insertAfter(b))),
                !c && this.settings.success && (d.text(""),
                typeof this.settings.success == "string" ? d.addClass(this.settings.success) : this.settings.success(d, b)),
                this.toShow = this.toShow.add(d)
            },
            errorsFor: function(b) {
                var c = this.idOrName(b);
                return this.errors().filter(function() {
                    return a(this).attr("for") === c
                })
            },
            idOrName: function(a) {
                return this.groups[a.name] || (this.checkable(a) ? a.name : a.id || a.name)
            },
            validationTargetFor: function(a) {
                return this.checkable(a) && (a = this.findByName(a.name).not(this.settings.ignore)[0]),
                a
            },
            checkable: function(a) {
                return /radio|checkbox/i.test(a.type)
            },
            findByName: function(b) {
                return a(this.currentForm).find('[name="' + b + '"]')
            },
            getLength: function(b, c) {
                switch (c.nodeName.toLowerCase()) {
                case "select":
                    return a("option:selected", c).length;
                case "input":
                    if (this.checkable(c))
                        return this.findByName(c.name).filter(":checked").length
                }
                return b.length
            },
            depend: function(a, b) {
                return this.dependTypes[typeof a] ? this.dependTypes[typeof a](a, b) : !0
            },
            dependTypes: {
                "boolean": function(a, b) {
                    return a
                },
                string: function(b, c) {
                    return !!a(b, c.form).length
                },
                "function": function(a, b) {
                    return a(b)
                }
            },
            optional: function(b) {
                var c = this.elementValue(b);
                return !a.validator.methods.required.call(this, c, b) && "dependency-mismatch"
            },
            startRequest: function(a) {
                this.pending[a.name] || (this.pendingRequest++,
                this.pending[a.name] = !0)
            },
            stopRequest: function(b, c) {
                this.pendingRequest--,
                this.pendingRequest < 0 && (this.pendingRequest = 0),
                delete this.pending[b.name],
                c && this.pendingRequest === 0 && this.formSubmitted && this.form() ? (a(this.currentForm).submit(),
                this.formSubmitted = !1) : !c && this.pendingRequest === 0 && this.formSubmitted && (a(this.currentForm).triggerHandler("invalid-form", [this]),
                this.formSubmitted = !1)
            },
            previousValue: function(b) {
                return a.data(b, "previousValue") || a.data(b, "previousValue", {
                    old: null,
                    valid: !0,
                    message: this.defaultMessage(b, "remote")
                })
            }
        },
        classRuleSettings: {
            required: {
                required: !0
            },
            email: {
                email: !0
            },
            url: {
                url: !0
            },
            date: {
                date: !0
            },
            dateISO: {
                dateISO: !0
            },
            number: {
                number: !0
            },
            digits: {
                digits: !0
            },
            creditcard: {
                creditcard: !0
            }
        },
        addClassRules: function(b, c) {
            b.constructor === String ? this.classRuleSettings[b] = c : a.extend(this.classRuleSettings, b)
        },
        classRules: function(b) {
            var c = {}
              , d = a(b).attr("class");
            return d && a.each(d.split(" "), function() {
                this in a.validator.classRuleSettings && a.extend(c, a.validator.classRuleSettings[this])
            }),
            c
        },
        attributeRules: function(b) {
            var c = {}
              , d = a(b);
            for (var e in a.validator.methods) {
                var f;
                e === "required" ? (f = d.get(0).getAttribute(e),
                f === "" && (f = !0),
                f = !!f) : f = d.attr(e),
                f ? c[e] = f : d[0].getAttribute("type") === e && (c[e] = !0)
            }
            return c.maxlength && /-1|2147483647|524288/.test(c.maxlength) && delete c.maxlength,
            c
        },
        metadataRules: function(b) {
            if (!a.metadata)
                return {};
            var c = a.data(b.form, "validator").settings.meta;
            return c ? a(b).metadata()[c] : a(b).metadata()
        },
        staticRules: function(b) {
            var c = {}
              , d = a.data(b.form, "validator");
            return d.settings.rules && (c = a.validator.normalizeRule(d.settings.rules[b.name]) || {}),
            c
        },
        normalizeRules: function(b, c) {
            return a.each(b, function(d, e) {
                if (e === !1) {
                    delete b[d];
                    return
                }
                if (e.param || e.depends) {
                    var f = !0;
                    switch (typeof e.depends) {
                    case "string":
                        f = !!a(e.depends, c.form).length;
                        break;
                    case "function":
                        f = e.depends.call(c, c)
                    }
                    f ? b[d] = e.param !== undefined ? e.param : !0 : delete b[d]
                }
            }),
            a.each(b, function(d, e) {
                b[d] = a.isFunction(e) ? e(c) : e
            }),
            a.each(["minlength", "maxlength", "min", "max"], function() {
                b[this] && (b[this] = Number(b[this]))
            }),
            a.each(["rangelength", "range"], function() {
                b[this] && (b[this] = [Number(b[this][0]), Number(b[this][1])])
            }),
            a.validator.autoCreateRanges && (b.min && b.max && (b.range = [b.min, b.max],
            delete b.min,
            delete b.max),
            b.minlength && b.maxlength && (b.rangelength = [b.minlength, b.maxlength],
            delete b.minlength,
            delete b.maxlength)),
            b.messages && delete b.messages,
            b
        },
        normalizeRule: function(b) {
            if (typeof b == "string") {
                var c = {};
                a.each(b.split(/\s/), function() {
                    c[this] = !0
                }),
                b = c
            }
            return b
        },
        addMethod: function(b, c, d) {
            a.validator.methods[b] = c,
            a.validator.messages[b] = d !== undefined ? d : a.validator.messages[b],
            c.length < 3 && a.validator.addClassRules(b, a.validator.normalizeRule(b))
        },
        methods: {
            required: function(b, c, d) {
                if (!this.depend(d, c))
                    return "dependency-mismatch";
                if (c.nodeName.toLowerCase() === "select") {
                    var e = a(c).val();
                    return e && e.length > 0
                }
                return this.checkable(c) ? this.getLength(b, c) > 0 : a.trim(b).length > 0
            },
            remote: function(b, c, d) {
                if (this.optional(c))
                    return "dependency-mismatch";
                var e = this.previousValue(c);
                this.settings.messages[c.name] || (this.settings.messages[c.name] = {}),
                e.originalMessage = this.settings.messages[c.name].remote,
                this.settings.messages[c.name].remote = e.message,
                d = typeof d == "string" && {
                    url: d
                } || d;
                if (this.pending[c.name])
                    return "pending";
                if (e.old === b)
                    return e.valid;
                e.old = b;
                var f = this;
                this.startRequest(c);
                var g = {};
                return g[c.name] = b,
                a.ajax(a.extend(!0, {
                    url: d,
                    mode: "abort",
                    port: "validate" + c.name,
                    dataType: "json",
                    data: g,
                    success: function(d) {
                        f.settings.messages[c.name].remote = e.originalMessage;
                        var g = d === !0 || d === "true";
                        if (g) {
                            var h = f.formSubmitted;
                            f.prepareElement(c),
                            f.formSubmitted = h,
                            f.successList.push(c),
                            delete f.invalid[c.name],
                            f.showErrors()
                        } else {
                            var i = {}
                              , j = d || f.defaultMessage(c, "remote");
                            i[c.name] = e.message = a.isFunction(j) ? j(b) : j,
                            f.invalid[c.name] = !0,
                            f.showErrors(i)
                        }
                        e.valid = g,
                        f.stopRequest(c, g)
                    }
                }, d)),
                "pending"
            },
            minlength: function(b, c, d) {
                var e = a.isArray(b) ? b.length : this.getLength(a.trim(b), c);
                return this.optional(c) || e >= d
            },
            maxlength: function(b, c, d) {
                var e = a.isArray(b) ? b.length : this.getLength(a.trim(b), c);
                return this.optional(c) || e <= d
            },
            rangelength: function(b, c, d) {
                var e = a.isArray(b) ? b.length : this.getLength(a.trim(b), c);
                return this.optional(c) || e >= d[0] && e <= d[1]
            },
            min: function(a, b, c) {
                return this.optional(b) || a >= c
            },
            max: function(a, b, c) {
                return this.optional(b) || a <= c
            },
            range: function(a, b, c) {
                return this.optional(b) || a >= c[0] && a <= c[1]
            },
            email: function(a, b) {
                return this.optional(b) || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(a)
            },
            url: function(a, b) {
                return this.optional(b) || /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(a)
            },
            date: function(a, b) {
                return this.optional(b) || !/Invalid|NaN/.test(new Date(a))
            },
            dateISO: function(a, b) {
                return this.optional(b) || /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(a)
            },
            number: function(a, b) {
                return this.optional(b) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(a)
            },
            digits: function(a, b) {
                return this.optional(b) || /^\d+$/.test(a)
            },
            creditcard: function(a, b) {
                if (this.optional(b))
                    return "dependency-mismatch";
                if (/[^0-9 \-]+/.test(a))
                    return !1;
                var c = 0
                  , d = 0
                  , e = !1;
                a = a.replace(/\D/g, "");
                for (var f = a.length - 1; f >= 0; f--) {
                    var g = a.charAt(f);
                    d = parseInt(g, 10),
                    e && (d *= 2) > 9 && (d -= 9),
                    c += d,
                    e = !e
                }
                return c % 10 === 0
            },
            equalTo: function(b, c, d) {
                var e = a(d);
                return this.settings.onfocusout && e.unbind(".validate-equalTo").bind("blur.validate-equalTo", function() {
                    a(c).valid()
                }),
                b === e.val()
            }
        }
    }),
    a.format = a.validator.format
}
)(jQuery),
function(a) {
    var b = {};
    if (a.ajaxPrefilter)
        a.ajaxPrefilter(function(a, c, d) {
            var e = a.port;
            a.mode === "abort" && (b[e] && b[e].abort(),
            b[e] = d)
        });
    else {
        var c = a.ajax;
        a.ajax = function(d) {
            var e = ("mode"in d ? d : a.ajaxSettings).mode
              , f = ("port"in d ? d : a.ajaxSettings).port;
            return e === "abort" ? (b[f] && b[f].abort(),
            b[f] = c.apply(this, arguments)) : c.apply(this, arguments)
        }
    }
}(jQuery),
function(a) {
    !jQuery.event.special.focusin && !jQuery.event.special.focusout && document.addEventListener && a.each({
        focus: "focusin",
        blur: "focusout"
    }, function(b, c) {
        function d(b) {
            return b = a.event.fix(b),
            b.type = c,
            a.event.handle.call(this, b)
        }
        a.event.special[c] = {
            setup: function() {
                this.addEventListener(b, d, !0)
            },
            teardown: function() {
                this.removeEventListener(b, d, !0)
            },
            handler: function(b) {
                var d = arguments;
                return d[0] = a.event.fix(b),
                d[0].type = c,
                a.event.handle.apply(this, d)
            }
        }
    }),
    a.extend(a.fn, {
        validateDelegate: function(b, c, d) {
            return this.bind(c, function(c) {
                var e = a(c.target);
                if (e.is(b))
                    return d.apply(e, arguments)
            })
        }
    })
}(jQuery);

//lazyload starts
!function(a, b, c, d) {
    var e = a(b);
    a.fn.lazyload = function(f) {
        function g() {
            var b = 0;
            i.each(function() {
                var c = a(this);
                if (!j.skip_invisible || c.is(":visible"))
                    if (a.abovethetop(this, j) || a.leftofbegin(this, j))
                        ;
                    else if (a.belowthefold(this, j) || a.rightoffold(this, j)) {
                        if (++b > j.failure_limit)
                            return !1
                    } else
                        c.trigger("appear"),
                        b = 0
            })
        }
        var h, i = this, j = {
            threshold: 0,
            failure_limit: 0,
            event: "scroll",
            effect: "show",
            container: b,
            data_attribute: "original",
            skip_invisible: !0,
            appear: null,
            load: null,
            placeholder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
        };
        return f && (d !== f.failurelimit && (f.failure_limit = f.failurelimit,
        delete f.failurelimit),
        d !== f.effectspeed && (f.effect_speed = f.effectspeed,
        delete f.effectspeed),
        a.extend(j, f)),
        h = j.container === d || j.container === b ? e : a(j.container),
        0 === j.event.indexOf("scroll") && h.bind(j.event, function() {
            return g()
        }),
        this.each(function() {
            var b = this
              , c = a(b);
            b.loaded = !1,
            (c.attr("src") === d || c.attr("src") === !1) && c.is("img") && c.attr("src", j.placeholder),
            c.one("appear", function() {
                if (!this.loaded) {
                    if (j.appear) {
                        var d = i.length;
                        j.appear.call(b, d, j)
                    }
                    a("<img />").bind("load", function() {
                        var d = c.attr("data-" + j.data_attribute);
                        c.hide(),
                        c.is("img") ? c.attr("src", d) : c.css("background-image", "url('" + d + "')"),
                        c[j.effect](j.effect_speed),
                        b.loaded = !0;
                        var e = a.grep(i, function(a) {
                            return !a.loaded
                        });
                        if (i = a(e),
                        j.load) {
                            var f = i.length;
                            j.load.call(b, f, j)
                        }
                    }).attr("src", c.attr("data-" + j.data_attribute))
                }
            }),
            0 !== j.event.indexOf("scroll") && c.bind(j.event, function() {
                b.loaded || c.trigger("appear")
            })
        }),
        e.bind("resize", function() {
            g()
        }),
        /(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion) && e.bind("pageshow", function(b) {
            b.originalEvent && b.originalEvent.persisted && i.each(function() {
                a(this).trigger("appear")
            })
        }),
        a(c).ready(function() {
            g()
        }),
        this
    }
    ,
    a.belowthefold = function(c, f) {
        var g;
        return g = f.container === d || f.container === b ? (b.innerHeight ? b.innerHeight : e.height()) + e.scrollTop() : a(f.container).offset().top + a(f.container).height(),
        g <= a(c).offset().top - f.threshold
    }
    ,
    a.rightoffold = function(c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.width() + e.scrollLeft() : a(f.container).offset().left + a(f.container).width(),
        g <= a(c).offset().left - f.threshold
    }
    ,
    a.abovethetop = function(c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.scrollTop() : a(f.container).offset().top,
        g >= a(c).offset().top + f.threshold + a(c).height()
    }
    ,
    a.leftofbegin = function(c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.scrollLeft() : a(f.container).offset().left,
        g >= a(c).offset().left + f.threshold + a(c).width()
    }
    ,
    a.inviewport = function(b, c) {
        return !(a.rightoffold(b, c) || a.leftofbegin(b, c) || a.belowthefold(b, c) || a.abovethetop(b, c))
    }
    ,
    a.extend(a.expr[":"], {
        "below-the-fold": function(b) {
            return a.belowthefold(b, {
                threshold: 0
            })
        },
        "above-the-top": function(b) {
            return !a.belowthefold(b, {
                threshold: 0
            })
        },
        "right-of-screen": function(b) {
            return a.rightoffold(b, {
                threshold: 0
            })
        },
        "left-of-screen": function(b) {
            return !a.rightoffold(b, {
                threshold: 0
            })
        },
        "in-viewport": function(b) {
            return a.inviewport(b, {
                threshold: 0
            })
        },
        "above-the-fold": function(b) {
            return !a.belowthefold(b, {
                threshold: 0
            })
        },
        "right-of-fold": function(b) {
            return a.rightoffold(b, {
                threshold: 0
            })
        },
        "left-of-fold": function(b) {
            return !a.rightoffold(b, {
                threshold: 0
            })
        }
    })
}(jQuery, window, document);

/*!
 * Bootstrap v3.1.1 (http://getbootstrap.com)
 * Copyright 2011-2014 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
if ("undefined" == typeof jQuery)
    throw new Error("Bootstrap's JavaScript requires jQuery");
+function(a) {
    "use strict";
    function b() {
        var a = document.createElement("bootstrap")
          , b = {
            WebkitTransition: "webkitTransitionEnd",
            MozTransition: "transitionend",
            OTransition: "oTransitionEnd otransitionend",
            transition: "transitionend"
        };
        for (var c in b)
            if (void 0 !== a.style[c])
                return {
                    end: b[c]
                };
        return !1
    }
    a.fn.emulateTransitionEnd = function(b) {
        var c = !1
          , d = this;
        a(this).one(a.support.transition.end, function() {
            c = !0
        });
        var e = function() {
            c || a(d).trigger(a.support.transition.end)
        };
        return setTimeout(e, b),
        this
    }
    ,
    a(function() {
        a.support.transition = b()
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = '[data-dismiss="alert"]'
      , c = function(c) {
        a(c).on("click", b, this.close)
    };
    c.prototype.close = function(b) {
        function c() {
            f.trigger("closed.bs.alert").remove()
        }
        var d = a(this)
          , e = d.attr("data-target");
        e || (e = d.attr("href"),
        e = e && e.replace(/.*(?=#[^\s]*$)/, ""));
        var f = a(e);
        b && b.preventDefault(),
        f.length || (f = d.hasClass("alert") ? d : d.parent()),
        f.trigger(b = a.Event("close.bs.alert")),
        b.isDefaultPrevented() || (f.removeClass("in"),
        a.support.transition && f.hasClass("fade") ? f.one(a.support.transition.end, c).emulateTransitionEnd(150) : c())
    }
    ;
    var d = a.fn.alert;
    a.fn.alert = function(b) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.alert");
            e || d.data("bs.alert", e = new c(this)),
            "string" == typeof b && e[b].call(d)
        })
    }
    ,
    a.fn.alert.Constructor = c,
    a.fn.alert.noConflict = function() {
        return a.fn.alert = d,
        this
    }
    ,
    a(document).on("click.bs.alert.data-api", b, c.prototype.close)
}(jQuery),
+function(a) {
    "use strict";
    var b = function(c, d) {
        this.$element = a(c),
        this.options = a.extend({}, b.DEFAULTS, d),
        this.isLoading = !1
    };
    b.DEFAULTS = {
        loadingText: "loading..."
    },
    b.prototype.setState = function(b) {
        var c = "disabled"
          , d = this.$element
          , e = d.is("input") ? "val" : "html"
          , f = d.data();
        b += "Text",
        f.resetText || d.data("resetText", d[e]()),
        d[e](f[b] || this.options[b]),
        setTimeout(a.proxy(function() {
            "loadingText" == b ? (this.isLoading = !0,
            d.addClass(c).attr(c, c)) : this.isLoading && (this.isLoading = !1,
            d.removeClass(c).removeAttr(c))
        }, this), 0)
    }
    ,
    b.prototype.toggle = function() {
        var a = !0
          , b = this.$element.closest('[data-toggle="buttons"]');
        if (b.length) {
            var c = this.$element.find("input");
            "radio" == c.prop("type") && (c.prop("checked") && this.$element.hasClass("active") ? a = !1 : b.find(".active").removeClass("active")),
            a && c.prop("checked", !this.$element.hasClass("active")).trigger("change")
        }
        a && this.$element.toggleClass("active")
    }
    ;
    var c = a.fn.button;
    a.fn.button = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.button")
              , f = "object" == typeof c && c;
            e || d.data("bs.button", e = new b(this,f)),
            "toggle" == c ? e.toggle() : c && e.setState(c)
        })
    }
    ,
    a.fn.button.Constructor = b,
    a.fn.button.noConflict = function() {
        return a.fn.button = c,
        this
    }
    ,
    a(document).on("click.bs.button.data-api", "[data-toggle^=button]", function(b) {
        var c = a(b.target);
        c.hasClass("btn") || (c = c.closest(".btn")),
        c.button("toggle"),
        b.preventDefault()
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = function(b, c) {
        this.$element = a(b),
        this.$indicators = this.$element.find(".carousel-indicators"),
        this.options = c,
        this.paused = this.sliding = this.interval = this.$active = this.$items = null,
        "hover" == this.options.pause && this.$element.on("mouseenter", a.proxy(this.pause, this)).on("mouseleave", a.proxy(this.cycle, this))
    };
    b.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0
    },
    b.prototype.cycle = function(b) {
        return b || (this.paused = !1),
        this.interval && clearInterval(this.interval),
        this.options.interval && !this.paused && (this.interval = setInterval(a.proxy(this.next, this), this.options.interval)),
        this
    }
    ,
    b.prototype.getActiveIndex = function() {
        return this.$active = this.$element.find(".item.active"),
        this.$items = this.$active.parent().children(),
        this.$items.index(this.$active)
    }
    ,
    b.prototype.to = function(b) {
        var c = this
          , d = this.getActiveIndex();
        return b > this.$items.length - 1 || 0 > b ? void 0 : this.sliding ? this.$element.one("slid.bs.carousel", function() {
            c.to(b)
        }) : d == b ? this.pause().cycle() : this.slide(b > d ? "next" : "prev", a(this.$items[b]))
    }
    ,
    b.prototype.pause = function(b) {
        return b || (this.paused = !0),
        this.$element.find(".next, .prev").length && a.support.transition && (this.$element.trigger(a.support.transition.end),
        this.cycle(!0)),
        this.interval = clearInterval(this.interval),
        this
    }
    ,
    b.prototype.next = function() {
        return this.sliding ? void 0 : this.slide("next")
    }
    ,
    b.prototype.prev = function() {
        return this.sliding ? void 0 : this.slide("prev")
    }
    ,
    b.prototype.slide = function(b, c) {
        var d = this.$element.find(".item.active")
          , e = c || d[b]()
          , f = this.interval
          , g = "next" == b ? "left" : "right"
          , h = "next" == b ? "first" : "last"
          , i = this;
        if (!e.length) {
            if (!this.options.wrap)
                return;
            e = this.$element.find(".item")[h]()
        }
        if (e.hasClass("active"))
            return this.sliding = !1;
        var j = a.Event("slide.bs.carousel", {
            relatedTarget: e[0],
            direction: g
        });
        return this.$element.trigger(j),
        j.isDefaultPrevented() ? void 0 : (this.sliding = !0,
        f && this.pause(),
        this.$indicators.length && (this.$indicators.find(".active").removeClass("active"),
        this.$element.one("slid.bs.carousel", function() {
            var b = a(i.$indicators.children()[i.getActiveIndex()]);
            b && b.addClass("active")
        })),
        a.support.transition && this.$element.hasClass("slide") ? (e.addClass(b),
        e[0].offsetWidth,
        d.addClass(g),
        e.addClass(g),
        d.one(a.support.transition.end, function() {
            e.removeClass([b, g].join(" ")).addClass("active"),
            d.removeClass(["active", g].join(" ")),
            i.sliding = !1,
            setTimeout(function() {
                i.$element.trigger("slid.bs.carousel")
            }, 0)
        }).emulateTransitionEnd(1e3 * d.css("transition-duration").slice(0, -1))) : (d.removeClass("active"),
        e.addClass("active"),
        this.sliding = !1,
        this.$element.trigger("slid.bs.carousel")),
        f && this.cycle(),
        this)
    }
    ;
    var c = a.fn.carousel;
    a.fn.carousel = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.carousel")
              , f = a.extend({}, b.DEFAULTS, d.data(), "object" == typeof c && c)
              , g = "string" == typeof c ? c : f.slide;
            e || d.data("bs.carousel", e = new b(this,f)),
            "number" == typeof c ? e.to(c) : g ? e[g]() : f.interval && e.pause().cycle()
        })
    }
    ,
    a.fn.carousel.Constructor = b,
    a.fn.carousel.noConflict = function() {
        return a.fn.carousel = c,
        this
    }
    ,
    a(document).on("click.bs.carousel.data-api", "[data-slide], [data-slide-to]", function(b) {
        var c, d = a(this), e = a(d.attr("data-target") || (c = d.attr("href")) && c.replace(/.*(?=#[^\s]+$)/, "")), f = a.extend({}, e.data(), d.data()), g = d.attr("data-slide-to");
        g && (f.interval = !1),
        e.carousel(f),
        (g = d.attr("data-slide-to")) && e.data("bs.carousel").to(g),
        b.preventDefault()
    }),
    a(window).on("load", function() {
        a('[data-ride="carousel"]').each(function() {
            var b = a(this);
            b.carousel(b.data())
        })
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = function(c, d) {
        this.$element = a(c),
        this.options = a.extend({}, b.DEFAULTS, d),
        this.transitioning = null,
        this.options.parent && (this.$parent = a(this.options.parent)),
        this.options.toggle && this.toggle()
    };
    b.DEFAULTS = {
        toggle: !0
    },
    b.prototype.dimension = function() {
        var a = this.$element.hasClass("width");
        return a ? "width" : "height"
    }
    ,
    b.prototype.show = function() {
        if (!this.transitioning && !this.$element.hasClass("in")) {
            var b = a.Event("show.bs.collapse");
            if (this.$element.trigger(b),
            !b.isDefaultPrevented()) {
                var c = this.$parent && this.$parent.find("> .panel > .in");
                if (c && c.length) {
                    var d = c.data("bs.collapse");
                    if (d && d.transitioning)
                        return;
                    c.collapse("hide"),
                    d || c.data("bs.collapse", null)
                }
                var e = this.dimension();
                this.$element.removeClass("collapse").addClass("collapsing")[e](0),
                this.transitioning = 1;
                var f = function() {
                    this.$element.removeClass("collapsing").addClass("collapse in")[e]("auto"),
                    this.transitioning = 0,
                    this.$element.trigger("shown.bs.collapse")
                };
                if (!a.support.transition)
                    return f.call(this);
                var g = a.camelCase(["scroll", e].join("-"));
                this.$element.one(a.support.transition.end, a.proxy(f, this)).emulateTransitionEnd(350)[e](this.$element[0][g])
            }
        }
    }
    ,
    b.prototype.hide = function() {
        if (!this.transitioning && this.$element.hasClass("in")) {
            var b = a.Event("hide.bs.collapse");
            if (this.$element.trigger(b),
            !b.isDefaultPrevented()) {
                var c = this.dimension();
                this.$element[c](this.$element[c]())[0].offsetHeight,
                this.$element.addClass("collapsing").removeClass("collapse").removeClass("in"),
                this.transitioning = 1;
                var d = function() {
                    this.transitioning = 0,
                    this.$element.trigger("hidden.bs.collapse").removeClass("collapsing").addClass("collapse")
                };
                return a.support.transition ? void this.$element[c](0).one(a.support.transition.end, a.proxy(d, this)).emulateTransitionEnd(350) : d.call(this)
            }
        }
    }
    ,
    b.prototype.toggle = function() {
        this[this.$element.hasClass("in") ? "hide" : "show"]()
    }
    ;
    var c = a.fn.collapse;
    a.fn.collapse = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.collapse")
              , f = a.extend({}, b.DEFAULTS, d.data(), "object" == typeof c && c);
            !e && f.toggle && "show" == c && (c = !c),
            e || d.data("bs.collapse", e = new b(this,f)),
            "string" == typeof c && e[c]()
        })
    }
    ,
    a.fn.collapse.Constructor = b,
    a.fn.collapse.noConflict = function() {
        return a.fn.collapse = c,
        this
    }
    ,
    a(document).on("click.bs.collapse.data-api", "[data-toggle=collapse]", function(b) {
        var c, d = a(this), e = d.attr("data-target") || b.preventDefault() || (c = d.attr("href")) && c.replace(/.*(?=#[^\s]+$)/, ""), f = a(e), g = f.data("bs.collapse"), h = g ? "toggle" : d.data(), i = d.attr("data-parent"), j = i && a(i);
        g && g.transitioning || (j && j.find('[data-toggle=collapse][data-parent="' + i + '"]').not(d).addClass("collapsed"),
        d[f.hasClass("in") ? "addClass" : "removeClass"]("collapsed")),
        f.collapse(h)
    })
}(jQuery),
+function(a) {
    "use strict";
    function b(b) {
        a(d).remove(),
        a(e).each(function() {
            var d = c(a(this))
              , e = {
                relatedTarget: this
            };
            d.hasClass("open") && (d.trigger(b = a.Event("hide.bs.dropdown", e)),
            b.isDefaultPrevented() || d.removeClass("open").trigger("hidden.bs.dropdown", e))
        })
    }
    function c(b) {
        var c = b.attr("data-target");
        c || (c = b.attr("href"),
        c = c && /#[A-Za-z]/.test(c) && c.replace(/.*(?=#[^\s]*$)/, ""));
        var d = c && a(c);
        return d && d.length ? d : b.parent()
    }
    var d = ".dropdown-backdrop"
      , e = "[data-toggle=dropdown]"
      , f = function(b) {
        a(b).on("click.bs.dropdown", this.toggle)
    };
    f.prototype.toggle = function(d) {
        var e = a(this);
        if (!e.is(".disabled, :disabled")) {
            var f = c(e)
              , g = f.hasClass("open");
            if (b(),
            !g) {
                "ontouchstart"in document.documentElement && !f.closest(".navbar-nav").length && a('<div class="dropdown-backdrop"/>').insertAfter(a(this)).on("click", b);
                var h = {
                    relatedTarget: this
                };
                if (f.trigger(d = a.Event("show.bs.dropdown", h)),
                d.isDefaultPrevented())
                    return;
                f.toggleClass("open").trigger("shown.bs.dropdown", h),
                e.focus()
            }
            return !1
        }
    }
    ,
    f.prototype.keydown = function(b) {
        if (/(38|40|27)/.test(b.keyCode)) {
            var d = a(this);
            if (b.preventDefault(),
            b.stopPropagation(),
            !d.is(".disabled, :disabled")) {
                var f = c(d)
                  , g = f.hasClass("open");
                if (!g || g && 27 == b.keyCode)
                    return 27 == b.which && f.find(e).focus(),
                    d.click();
                var h = " li:not(.divider):visible a"
                  , i = f.find("[role=menu]" + h + ", [role=listbox]" + h);
                if (i.length) {
                    var j = i.index(i.filter(":focus"));
                    38 == b.keyCode && j > 0 && j--,
                    40 == b.keyCode && j < i.length - 1 && j++,
                    ~j || (j = 0),
                    i.eq(j).focus()
                }
            }
        }
    }
    ;
    var g = a.fn.dropdown;
    a.fn.dropdown = function(b) {
        return this.each(function() {
            var c = a(this)
              , d = c.data("bs.dropdown");
            d || c.data("bs.dropdown", d = new f(this)),
            "string" == typeof b && d[b].call(c)
        })
    }
    ,
    a.fn.dropdown.Constructor = f,
    a.fn.dropdown.noConflict = function() {
        return a.fn.dropdown = g,
        this
    }
    ,
    a(document).on("click.bs.dropdown.data-api", b).on("click.bs.dropdown.data-api", ".dropdown form", function(a) {
        a.stopPropagation()
    }).on("click.bs.dropdown.data-api", e, f.prototype.toggle).on("keydown.bs.dropdown.data-api", e + ", [role=menu], [role=listbox]", f.prototype.keydown)
}(jQuery),
+function(a) {
    "use strict";
    var b = function(b, c) {
        this.options = c,
        this.$element = a(b),
        this.$backdrop = this.isShown = null,
        this.options.remote && this.$element.find(".modal-content").load(this.options.remote, a.proxy(function() {
            this.$element.trigger("loaded.bs.modal")
        }, this))
    };
    b.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    },
    b.prototype.toggle = function(a) {
        return this[this.isShown ? "hide" : "show"](a)
    }
    ,
    b.prototype.show = function(b) {
        var c = this
          , d = a.Event("show.bs.modal", {
            relatedTarget: b
        });
        this.$element.trigger(d),
        this.isShown || d.isDefaultPrevented() || (this.isShown = !0,
        this.escape(),
        this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', a.proxy(this.hide, this)),
        this.backdrop(function() {
            var d = a.support.transition && c.$element.hasClass("fade");
            c.$element.parent().length || c.$element.appendTo(document.body),
            c.$element.show().scrollTop(0),
            d && c.$element[0].offsetWidth,
            c.$element.addClass("in").attr("aria-hidden", !1),
            c.enforceFocus();
            var e = a.Event("shown.bs.modal", {
                relatedTarget: b
            });
            d ? c.$element.find(".modal-dialog").one(a.support.transition.end, function() {
                c.$element.focus().trigger(e)
            }).emulateTransitionEnd(300) : c.$element.focus().trigger(e)
        }))
    }
    ,
    b.prototype.hide = function(b) {
        b && b.preventDefault(),
        b = a.Event("hide.bs.modal"),
        this.$element.trigger(b),
        this.isShown && !b.isDefaultPrevented() && (this.isShown = !1,
        this.escape(),
        a(document).off("focusin.bs.modal"),
        this.$element.removeClass("in").attr("aria-hidden", !0).off("click.dismiss.bs.modal"),
        a.support.transition && this.$element.hasClass("fade") ? this.$element.one(a.support.transition.end, a.proxy(this.hideModal, this)).emulateTransitionEnd(300) : this.hideModal())
    }
    ,
    b.prototype.enforceFocus = function() {
        a(document).off("focusin.bs.modal").on("focusin.bs.modal", a.proxy(function(a) {
            this.$element[0] === a.target || this.$element.has(a.target).length || this.$element.focus()
        }, this))
    }
    ,
    b.prototype.escape = function() {
        this.isShown && this.options.keyboard ? this.$element.on("keyup.dismiss.bs.modal", a.proxy(function(a) {
            27 == a.which && this.hide()
        }, this)) : this.isShown || this.$element.off("keyup.dismiss.bs.modal")
    }
    ,
    b.prototype.hideModal = function() {
        var a = this;
        this.$element.hide(),
        this.backdrop(function() {
            a.removeBackdrop(),
            a.$element.trigger("hidden.bs.modal")
        })
    }
    ,
    b.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove(),
        this.$backdrop = null
    }
    ,
    b.prototype.backdrop = function(b) {
        var c = this.$element.hasClass("fade") ? "fade" : "";
        if (this.isShown && this.options.backdrop) {
            var d = a.support.transition && c;
            if (this.$backdrop = a('<div class="modal-backdrop ' + c + '" />').appendTo(document.body),
            this.$element.on("click.dismiss.bs.modal", a.proxy(function(a) {
                a.target === a.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus.call(this.$element[0]) : this.hide.call(this))
            }, this)),
            d && this.$backdrop[0].offsetWidth,
            this.$backdrop.addClass("in"),
            !b)
                return;
            d ? this.$backdrop.one(a.support.transition.end, b).emulateTransitionEnd(150) : b()
        } else
            !this.isShown && this.$backdrop ? (this.$backdrop.removeClass("in"),
            a.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one(a.support.transition.end, b).emulateTransitionEnd(150) : b()) : b && b()
    }
    ;
    var c = a.fn.modal;
    a.fn.modal = function(c, d) {
        return this.each(function() {
            var e = a(this)
              , f = e.data("bs.modal")
              , g = a.extend({}, b.DEFAULTS, e.data(), "object" == typeof c && c);
            f || e.data("bs.modal", f = new b(this,g)),
            "string" == typeof c ? f[c](d) : g.show && f.show(d)
        })
    }
    ,
    a.fn.modal.Constructor = b,
    a.fn.modal.noConflict = function() {
        return a.fn.modal = c,
        this
    }
    ,
    a(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(b) {
        var c = a(this)
          , d = c.attr("href")
          , e = a(c.attr("data-target") || d && d.replace(/.*(?=#[^\s]+$)/, ""))
          , f = e.data("bs.modal") ? "toggle" : a.extend({
            remote: !/#/.test(d) && d
        }, e.data(), c.data());
        c.is("a") && b.preventDefault(),
        e.modal(f, this).one("hide", function() {
            c.is(":visible") && c.focus()
        })
    }),
    a(document).on("show.bs.modal", ".modal", function() {
        a(document.body).addClass("modal-open")
    }).on("hidden.bs.modal", ".modal", function() {
        a(document.body).removeClass("modal-open")
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = function(a, b) {
        this.type = this.options = this.enabled = this.timeout = this.hoverState = this.$element = null,
        this.init("tooltip", a, b)
    };
    b.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1
    },
    b.prototype.init = function(b, c, d) {
        this.enabled = !0,
        this.type = b,
        this.$element = a(c),
        this.options = this.getOptions(d);
        for (var e = this.options.trigger.split(" "), f = e.length; f--; ) {
            var g = e[f];
            if ("click" == g)
                this.$element.on("click." + this.type, this.options.selector, a.proxy(this.toggle, this));
            else if ("manual" != g) {
                var h = "hover" == g ? "mouseenter" : "focusin"
                  , i = "hover" == g ? "mouseleave" : "focusout";
                this.$element.on(h + "." + this.type, this.options.selector, a.proxy(this.enter, this)),
                this.$element.on(i + "." + this.type, this.options.selector, a.proxy(this.leave, this))
            }
        }
        this.options.selector ? this._options = a.extend({}, this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    }
    ,
    b.prototype.getDefaults = function() {
        return b.DEFAULTS
    }
    ,
    b.prototype.getOptions = function(b) {
        return b = a.extend({}, this.getDefaults(), this.$element.data(), b),
        b.delay && "number" == typeof b.delay && (b.delay = {
            show: b.delay,
            hide: b.delay
        }),
        b
    }
    ,
    b.prototype.getDelegateOptions = function() {
        var b = {}
          , c = this.getDefaults();
        return this._options && a.each(this._options, function(a, d) {
            c[a] != d && (b[a] = d)
        }),
        b
    }
    ,
    b.prototype.enter = function(b) {
        var c = b instanceof this.constructor ? b : a(b.currentTarget)[this.type](this.getDelegateOptions()).data("bs." + this.type);
        return clearTimeout(c.timeout),
        c.hoverState = "in",
        c.options.delay && c.options.delay.show ? void (c.timeout = setTimeout(function() {
            "in" == c.hoverState && c.show()
        }, c.options.delay.show)) : c.show()
    }
    ,
    b.prototype.leave = function(b) {
        var c = b instanceof this.constructor ? b : a(b.currentTarget)[this.type](this.getDelegateOptions()).data("bs." + this.type);
        return clearTimeout(c.timeout),
        c.hoverState = "out",
        c.options.delay && c.options.delay.hide ? void (c.timeout = setTimeout(function() {
            "out" == c.hoverState && c.hide()
        }, c.options.delay.hide)) : c.hide()
    }
    ,
    b.prototype.show = function() {
        var b = a.Event("show.bs." + this.type);
        if (this.hasContent() && this.enabled) {
            if (this.$element.trigger(b),
            b.isDefaultPrevented())
                return;
            var c = this
              , d = this.tip();
            this.setContent(),
            this.options.animation && d.addClass("fade");
            var e = "function" == typeof this.options.placement ? this.options.placement.call(this, d[0], this.$element[0]) : this.options.placement
              , f = /\s?auto?\s?/i
              , g = f.test(e);
            g && (e = e.replace(f, "") || "top"),
            d.detach().css({
                top: 0,
                left: 0,
                display: "block"
            }).addClass(e),
            this.options.container ? d.appendTo(this.options.container) : d.insertAfter(this.$element);
            var h = this.getPosition()
              , i = d[0].offsetWidth
              , j = d[0].offsetHeight;
            if (g) {
                var k = this.$element.parent()
                  , l = e
                  , m = document.documentElement.scrollTop || document.body.scrollTop
                  , n = "body" == this.options.container ? window.innerWidth : k.outerWidth()
                  , o = "body" == this.options.container ? window.innerHeight : k.outerHeight()
                  , p = "body" == this.options.container ? 0 : k.offset().left;
                e = "bottom" == e && h.top + h.height + j - m > o ? "top" : "top" == e && h.top - m - j < 0 ? "bottom" : "right" == e && h.right + i > n ? "left" : "left" == e && h.left - i < p ? "right" : e,
                d.removeClass(l).addClass(e)
            }
            var q = this.getCalculatedOffset(e, h, i, j);
            this.applyPlacement(q, e),
            this.hoverState = null;
            var r = function() {
                c.$element.trigger("shown.bs." + c.type)
            };
            a.support.transition && this.$tip.hasClass("fade") ? d.one(a.support.transition.end, r).emulateTransitionEnd(150) : r()
        }
    }
    ,
    b.prototype.applyPlacement = function(b, c) {
        var d, e = this.tip(), f = e[0].offsetWidth, g = e[0].offsetHeight, h = parseInt(e.css("margin-top"), 10), i = parseInt(e.css("margin-left"), 10);
        isNaN(h) && (h = 0),
        isNaN(i) && (i = 0),
        b.top = b.top + h,
        b.left = b.left + i,
        a.offset.setOffset(e[0], a.extend({
            using: function(a) {
                e.css({
                    top: Math.round(a.top),
                    left: Math.round(a.left)
                })
            }
        }, b), 0),
        e.addClass("in");
        var j = e[0].offsetWidth
          , k = e[0].offsetHeight;
        if ("top" == c && k != g && (d = !0,
        b.top = b.top + g - k),
        /bottom|top/.test(c)) {
            var l = 0;
            b.left < 0 && (l = -2 * b.left,
            b.left = 0,
            e.offset(b),
            j = e[0].offsetWidth,
            k = e[0].offsetHeight),
            this.replaceArrow(l - f + j, j, "left")
        } else
            this.replaceArrow(k - g, k, "top");
        d && e.offset(b)
    }
    ,
    b.prototype.replaceArrow = function(a, b, c) {
        this.arrow().css(c, a ? 50 * (1 - a / b) + "%" : "")
    }
    ,
    b.prototype.setContent = function() {
        var a = this.tip()
          , b = this.getTitle();
        a.find(".tooltip-inner")[this.options.html ? "html" : "text"](b),
        a.removeClass("fade in top bottom left right")
    }
    ,
    b.prototype.hide = function() {
        function b() {
            "in" != c.hoverState && d.detach(),
            c.$element.trigger("hidden.bs." + c.type)
        }
        var c = this
          , d = this.tip()
          , e = a.Event("hide.bs." + this.type);
        return this.$element.trigger(e),
        e.isDefaultPrevented() ? void 0 : (d.removeClass("in"),
        a.support.transition && this.$tip.hasClass("fade") ? d.one(a.support.transition.end, b).emulateTransitionEnd(150) : b(),
        this.hoverState = null,
        this)
    }
    ,
    b.prototype.fixTitle = function() {
        var a = this.$element;
        (a.attr("title") || "string" != typeof a.attr("data-original-title")) && a.attr("data-original-title", a.attr("title") || "").attr("title", "")
    }
    ,
    b.prototype.hasContent = function() {
        return this.getTitle()
    }
    ,
    b.prototype.getPosition = function() {
        var b = this.$element[0];
        return a.extend({}, "function" == typeof b.getBoundingClientRect ? b.getBoundingClientRect() : {
            width: b.offsetWidth,
            height: b.offsetHeight
        }, this.$element.offset())
    }
    ,
    b.prototype.getCalculatedOffset = function(a, b, c, d) {
        return "bottom" == a ? {
            top: b.top + b.height,
            left: b.left + b.width / 2 - c / 2
        } : "top" == a ? {
            top: b.top - d,
            left: b.left + b.width / 2 - c / 2
        } : "left" == a ? {
            top: b.top + b.height / 2 - d / 2,
            left: b.left - c
        } : {
            top: b.top + b.height / 2 - d / 2,
            left: b.left + b.width
        }
    }
    ,
    b.prototype.getTitle = function() {
        var a, b = this.$element, c = this.options;
        return a = b.attr("data-original-title") || ("function" == typeof c.title ? c.title.call(b[0]) : c.title)
    }
    ,
    b.prototype.tip = function() {
        return this.$tip = this.$tip || a(this.options.template)
    }
    ,
    b.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    }
    ,
    b.prototype.validate = function() {
        this.$element[0].parentNode || (this.hide(),
        this.$element = null,
        this.options = null)
    }
    ,
    b.prototype.enable = function() {
        this.enabled = !0
    }
    ,
    b.prototype.disable = function() {
        this.enabled = !1
    }
    ,
    b.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    }
    ,
    b.prototype.toggle = function(b) {
        var c = b ? a(b.currentTarget)[this.type](this.getDelegateOptions()).data("bs." + this.type) : this;
        c.tip().hasClass("in") ? c.leave(c) : c.enter(c)
    }
    ,
    b.prototype.destroy = function() {
        clearTimeout(this.timeout),
        this.hide().$element.off("." + this.type).removeData("bs." + this.type)
    }
    ;
    var c = a.fn.tooltip;
    a.fn.tooltip = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.tooltip")
              , f = "object" == typeof c && c;
            (e || "destroy" != c) && (e || d.data("bs.tooltip", e = new b(this,f)),
            "string" == typeof c && e[c]())
        })
    }
    ,
    a.fn.tooltip.Constructor = b,
    a.fn.tooltip.noConflict = function() {
        return a.fn.tooltip = c,
        this
    }
}(jQuery),
+function(a) {
    "use strict";
    var b = function(a, b) {
        this.init("popover", a, b)
    };
    if (!a.fn.tooltip)
        throw new Error("Popover requires tooltip.js");
    b.DEFAULTS = a.extend({}, a.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    }),
    b.prototype = a.extend({}, a.fn.tooltip.Constructor.prototype),
    b.prototype.constructor = b,
    b.prototype.getDefaults = function() {
        return b.DEFAULTS
    }
    ,
    b.prototype.setContent = function() {
        var a = this.tip()
          , b = this.getTitle()
          , c = this.getContent();
        a.find(".popover-title")[this.options.html ? "html" : "text"](b),
        a.find(".popover-content")[this.options.html ? "string" == typeof c ? "html" : "append" : "text"](c),
        a.removeClass("fade top bottom left right in"),
        a.find(".popover-title").html() || a.find(".popover-title").hide()
    }
    ,
    b.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    }
    ,
    b.prototype.getContent = function() {
        var a = this.$element
          , b = this.options;
        return a.attr("data-content") || ("function" == typeof b.content ? b.content.call(a[0]) : b.content)
    }
    ,
    b.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    }
    ,
    b.prototype.tip = function() {
        return this.$tip || (this.$tip = a(this.options.template)),
        this.$tip
    }
    ;
    var c = a.fn.popover;
    a.fn.popover = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.popover")
              , f = "object" == typeof c && c;
            (e || "destroy" != c) && (e || d.data("bs.popover", e = new b(this,f)),
            "string" == typeof c && e[c]())
        })
    }
    ,
    a.fn.popover.Constructor = b,
    a.fn.popover.noConflict = function() {
        return a.fn.popover = c,
        this
    }
}(jQuery),
+function(a) {
    "use strict";
    function b(c, d) {
        var e, f = a.proxy(this.process, this);
        this.$element = a(a(c).is("body") ? window : c),
        this.$body = a("body"),
        this.$scrollElement = this.$element.on("scroll.bs.scroll-spy.data-api", f),
        this.options = a.extend({}, b.DEFAULTS, d),
        this.selector = (this.options.target || (e = a(c).attr("href")) && e.replace(/.*(?=#[^\s]+$)/, "") || "") + " .nav li > a",
        this.offsets = a([]),
        this.targets = a([]),
        this.activeTarget = null,
        this.refresh(),
        this.process()
    }
    b.DEFAULTS = {
        offset: 10
    },
    b.prototype.refresh = function() {
        var b = this.$element[0] == window ? "offset" : "position";
        this.offsets = a([]),
        this.targets = a([]);
        {
            var c = this;
            this.$body.find(this.selector).map(function() {
                var d = a(this)
                  , e = d.data("target") || d.attr("href")
                  , f = /^#./.test(e) && a(e);
                return f && f.length && f.is(":visible") && [[f[b]().top + (!a.isWindow(c.$scrollElement.get(0)) && c.$scrollElement.scrollTop()), e]] || null
            }).sort(function(a, b) {
                return a[0] - b[0]
            }).each(function() {
                c.offsets.push(this[0]),
                c.targets.push(this[1])
            })
        }
    }
    ,
    b.prototype.process = function() {
        var a, b = this.$scrollElement.scrollTop() + this.options.offset, c = this.$scrollElement[0].scrollHeight || this.$body[0].scrollHeight, d = c - this.$scrollElement.height(), e = this.offsets, f = this.targets, g = this.activeTarget;
        if (b >= d)
            return g != (a = f.last()[0]) && this.activate(a);
        if (g && b <= e[0])
            return g != (a = f[0]) && this.activate(a);
        for (a = e.length; a--; )
            g != f[a] && b >= e[a] && (!e[a + 1] || b <= e[a + 1]) && this.activate(f[a])
    }
    ,
    b.prototype.activate = function(b) {
        this.activeTarget = b,
        a(this.selector).parentsUntil(this.options.target, ".active").removeClass("active");
        var c = this.selector + '[data-target="' + b + '"],' + this.selector + '[href="' + b + '"]'
          , d = a(c).parents("li").addClass("active");
        d.parent(".dropdown-menu").length && (d = d.closest("li.dropdown").addClass("active")),
        d.trigger("activate.bs.scrollspy")
    }
    ;
    var c = a.fn.scrollspy;
    a.fn.scrollspy = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.scrollspy")
              , f = "object" == typeof c && c;
            e || d.data("bs.scrollspy", e = new b(this,f)),
            "string" == typeof c && e[c]()
        })
    }
    ,
    a.fn.scrollspy.Constructor = b,
    a.fn.scrollspy.noConflict = function() {
        return a.fn.scrollspy = c,
        this
    }
    ,
    a(window).on("load", function() {
        a('[data-spy="scroll"]').each(function() {
            var b = a(this);
            b.scrollspy(b.data())
        })
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = function(b) {
        this.element = a(b)
    };
    b.prototype.show = function() {
        var b = this.element
          , c = b.closest("ul:not(.dropdown-menu)")
          , d = b.data("target");
        if (d || (d = b.attr("href"),
        d = d && d.replace(/.*(?=#[^\s]*$)/, "")),
        !b.parent("li").hasClass("active")) {
            var e = c.find(".active:last a")[0]
              , f = a.Event("show.bs.tab", {
                relatedTarget: e
            });
            if (b.trigger(f),
            !f.isDefaultPrevented()) {
                var g = a(d);
                this.activate(b.parent("li"), c),
                this.activate(g, g.parent(), function() {
                    b.trigger({
                        type: "shown.bs.tab",
                        relatedTarget: e
                    })
                })
            }
        }
    }
    ,
    b.prototype.activate = function(b, c, d) {
        function e() {
            f.removeClass("active").find("> .dropdown-menu > .active").removeClass("active"),
            b.addClass("active"),
            g ? (b[0].offsetWidth,
            b.addClass("in")) : b.removeClass("fade"),
            b.parent(".dropdown-menu") && b.closest("li.dropdown").addClass("active"),
            d && d()
        }
        var f = c.find("> .active")
          , g = d && a.support.transition && f.hasClass("fade");
        g ? f.one(a.support.transition.end, e).emulateTransitionEnd(150) : e(),
        f.removeClass("in")
    }
    ;
    var c = a.fn.tab;
    a.fn.tab = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.tab");
            e || d.data("bs.tab", e = new b(this)),
            "string" == typeof c && e[c]()
        })
    }
    ,
    a.fn.tab.Constructor = b,
    a.fn.tab.noConflict = function() {
        return a.fn.tab = c,
        this
    }
    ,
    a(document).on("click.bs.tab.data-api", '[data-toggle="tab"], [data-toggle="pill"]', function(b) {
        b.preventDefault(),
        a(this).tab("show")
    })
}(jQuery),
+function(a) {
    "use strict";
    var b = function(c, d) {
        this.options = a.extend({}, b.DEFAULTS, d),
        this.$window = a(window).on("scroll.bs.affix.data-api", a.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", a.proxy(this.checkPositionWithEventLoop, this)),
        this.$element = a(c),
        this.affixed = this.unpin = this.pinnedOffset = null,
        this.checkPosition()
    };
    b.RESET = "affix affix-top affix-bottom",
    b.DEFAULTS = {
        offset: 0
    },
    b.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset)
            return this.pinnedOffset;
        this.$element.removeClass(b.RESET).addClass("affix");
        var a = this.$window.scrollTop()
          , c = this.$element.offset();
        return this.pinnedOffset = c.top - a
    }
    ,
    b.prototype.checkPositionWithEventLoop = function() {
        setTimeout(a.proxy(this.checkPosition, this), 1)
    }
    ,
    b.prototype.checkPosition = function() {
        if (this.$element.is(":visible")) {
            var c = a(document).height()
              , d = this.$window.scrollTop()
              , e = this.$element.offset()
              , f = this.options.offset
              , g = f.top
              , h = f.bottom;
            "top" == this.affixed && (e.top += d),
            "object" != typeof f && (h = g = f),
            "function" == typeof g && (g = f.top(this.$element)),
            "function" == typeof h && (h = f.bottom(this.$element));
            var i = null != this.unpin && d + this.unpin <= e.top ? !1 : null != h && e.top + this.$element.height() >= c - h ? "bottom" : null != g && g >= d ? "top" : !1;
            if (this.affixed !== i) {
                this.unpin && this.$element.css("top", "");
                var j = "affix" + (i ? "-" + i : "")
                  , k = a.Event(j + ".bs.affix");
                this.$element.trigger(k),
                k.isDefaultPrevented() || (this.affixed = i,
                this.unpin = "bottom" == i ? this.getPinnedOffset() : null,
                this.$element.removeClass(b.RESET).addClass(j).trigger(a.Event(j.replace("affix", "affixed"))),
                "bottom" == i && this.$element.offset({
                    top: c - h - this.$element.height()
                }))
            }
        }
    }
    ;
    var c = a.fn.affix;
    a.fn.affix = function(c) {
        return this.each(function() {
            var d = a(this)
              , e = d.data("bs.affix")
              , f = "object" == typeof c && c;
            e || d.data("bs.affix", e = new b(this,f)),
            "string" == typeof c && e[c]()
        })
    }
    ,
    a.fn.affix.Constructor = b,
    a.fn.affix.noConflict = function() {
        return a.fn.affix = c,
        this
    }
    ,
    a(window).on("load", function() {
        a('[data-spy="affix"]').each(function() {
            var b = a(this)
              , c = b.data();
            c.offset = c.offset || {},
            c.offsetBottom && (c.offset.bottom = c.offsetBottom),
            c.offsetTop && (c.offset.top = c.offsetTop),
            b.affix(c)
        })
    })
}(jQuery);

/*
	* LayerSlider
	*
	* (c) 2011-2014 George Krupa, John Gera & Kreatura Media
	*
	* Plugin web:			http://kreaturamedia.com/
	* licenses:				http://codecanyon.net/licenses/
*/

eval(function(p, a, c, k, e, d) {
    e = function(c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
    }
    ;
    if (!''.replace(/^/, String)) {
        while (c--) {
            d[e(c)] = k[c] || e(c)
        }
        k = [function(e) {
            return d[e]
        }
        ];
        e = function() {
            return '\\w+'
        }
        ;
        c = 1
    }
    ;while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b','g'), k[c])
        }
    }
    return p
}('18 ad(e,t,n){16 r;6(1W e=="5T"){r=3A("#"+e)}19 6(1W e=="ai"){r=e}16 i,s;2p(t){1l"8N":i="bV 3A 99";s=\'96 98 4K bT ca b6 44 4O c5 c3 an c4 c2 2X 21 3A 9l c1 dG 23 2A 2e 64 4O de. <1Y>4P dd 4e 4O 5g dc db 2e 21 dj di 2X 2A 4Q da 21 "d3 bN d2 2e 3U" d1 d0 21 d4 & d5 d8 3K.</1Y>\';1j;1l"ae":i="5V 3A 99";s="96 98 4K d7 d6 ch an 5V 2s ("+n+\') 2X 21 3A 9l. 2A dk at dl 2s 1.7.0 44 dA. 4P b5 3A 2e 1.10.x 44 dz. dy: 4P do 2I dE 21 3A dD b6 4e 5g 4Q do 2I b5 2e 2.x 2s 2X 3A dx 4i 3m 2I bP b3 dw dq 4K dp 7 & 8. <a 2i="6P://dn.dm.5N/dv/4/69-23-du/#ap-13&ar-60">cZ cY cw cu cy cC 3A by cr cl.</a>\';1j}r.1r("12-3Z");r.3S(\'<p 1t="12-ck">!</p>\');r.3S(\'<p 1t="12-3Z-ci">2A: \'+i+"</p>");r.3S(\'<p 1t="12-3Z-8J">\'+s+"</p>")}(18(e){e.fn.2V=18(n){16 r="1.7.0";16 i=e.fn.8N;16 s=e(14);16 o=18(e,t){16 n=e.1E(".");16 r=t.1E(".");23(16 i=0;i<n.1k;++i){6(r.1k==i){1T 1g}6(1b(n[i])==1b(r[i])){cm}19 6(1b(n[i])>1b(r[i])){1T 1g}19{1T 1c}}6(n.1k!=r.1k){1T 1c}1T 1c};6(!o("1.8.0",i)){s.1r("12-aW")}6(!o(r,i)){ad(s,"ae",i)}19{6((1W n).3H("ai|2W")){1T 14.1O(18(e){1I t(14,n)})}19{6(n=="11"){16 u=e(14).11("2A").g;6(u){1T u}}19{1T 14.1O(18(t){16 r=e(14).11("2A");6(r){6(!r.g.36&&!r.g.48){6(1W n=="3V"){6(n>0&&n<r.g.2y+1&&n!=r.g.27){r.4C(n)}}19{2p(n){1l"1S":r.o.7v(r.g);r.1S("6j");1j;1l"1X":r.o.7l(r.g);r.1X("6j");1j;1l"22":6(!r.g.2w){r.o.b2(r.g);r.g.2t=1c;r.22()}1j}}}6(n=="4X"){r.d.64()}6((r.g.2w||!r.g.2w&&r.g.2t)&&n=="1x"){r.o.ax(r.g);r.g.2t=1g;r.g.1L.17(\'2b[1h*="66.53"], 2b[1h*="62.52"]\').1O(18(){2v(e(14).11("6C"))});r.1x()}6(n=="cn"){r.af()}}})}}}};16 t=18(u,a){16 f=14;f.$el=e(u).1r("12-2n");f.$el.11("2A",f);f.31=18(){f.o=e.4D({},t.9K,a);f.g=e.4D({},t.7q);f.1y=e.4D({},t.9Q);f.4Z=e.4D({},t.9H);f.g.co=e(u).30("12-aW")?1g:1c;6(f.g.2o){f.o.47=1g}6(f.o.2u==="cE"){f.o.2u=1c}6(f.o.2u==="av"){f.o.2u=1g}6(1W aY!=="2W"){f.t=e.4D({},aY)}6(1W aO!=="2W"){f.ct=e.4D({},aO)}6(!f.g.aN){f.g.aN=1c;f.4X();6(e("4u").17(\'aE[91*="5g"]\').1k){f.g.8v=e("4u").17(\'aE[91*="5g"]\').1f("91").1E("5g")[1]}6(e("4u").17(\'94[1h*="69"]\').1k){6(e("4u").17(\'94[1h*="69"]\').1f("1h").1i("?")!=-1){f.g.8x=e("4u").17(\'94[1h*="69"]\').1f("1h").1E("?")[1].1E("=")[1]}}f.d.aT("2A bq");f.d.aU(\'<a 2i="#">1S</a> | <a 2i="#">1X</a> | <a 2i="#">22</a> | <a 2i="#">1x</a> | <a 2i="#">cS 1x</a>\');f.d.3R.17("a").1O(18(){e(14).2k(18(t){t.3t();e(u).2V(e(14).8J())})});f.d.aT("2A 2s cR");f.d.aU("bN 2s: <1Y>"+f.g.2s+"</1Y>");6(f.g.8x){f.d.aL("cX 2s: <1Y>"+f.g.8x+"</1Y>")}6(f.g.8v){f.d.aL("5g 2s: <1Y>"+f.g.8v+"</1Y>")}f.d.aL("3A 2s: <1Y>"+e().8N+"</1Y>");6(e(u).1f("4N")){f.d.aT("2A 2n");f.d.aU("#"+e(u).1f("4N"))}6(!f.o.2r||f.o.2r==""||!f.o.3z||f.o.3z==""){f.d.aT("cW cV 2r. cP: cO 2r 4Q / 44 3z.");f.59()}19{f.d.aT("cI 2e 31 b3 2r: "+f.o.2r,1c);e(u).1r("12-"+f.o.2r);16 n=f.o.3z+f.o.2r+"/2r.1a";8w=e("bC");6(!e("bC").1k){8w=e("3U")}6(e(\'7c[2i="\'+n+\'"]\').1k){f.d.aU(\'cH "\'+f.o.2r+\'" 3m cG 2S.\');r=e(\'7c[2i="\'+n+\'"]\');6(!f.g.2S){f.g.2S=1c;f.g.a9=2g(18(){f.59()},7u)}}19{6(6c.bR){6c.bR(n);16 r=e(\'7c[2i="\'+n+\'"]\')}19{16 r=e(\'<7c 55="cF" 2i="\'+n+\'" 4y="8J/1a" />\').1w(8w)}}r.31(18(){6(!f.g.2S){f.d.aU("bl.31(); 8U");f.g.2S=1c;f.g.a8=2g(18(){f.59()},7u)}});e(2q).31(18(){6(!f.g.2S){f.d.aU("$(2q).31(); 8U");f.g.2S=1c;f.g.aa=2g(18(){f.59()},7u)}});f.g.ab=2g(18(){6(!f.g.2S){f.d.aT("cJ cK: cM bl.31(); 44 $(2q).31(); cL 8U");f.g.2S=1c;f.59()}},1P)}}};f.59=18(){6(!e("4u").1f("4N")){e("4u").1f("4N","12-7q")}19 6(!e("3U").1f("4N")){e("3U").1f("4N","12-7q")}f.g.1A=18(){1T e(u).1d()};f.g.1H=18(){1T e(u).1e()};e(u).17(".12-4G").2x("12-4G").1r("12-1p");e(u).17(\'.12-1p > *[1t*="12-s"]\').1O(18(){16 t=e(14).1f("1t").1E("12-s")[1].1E(" ")[0];e(14).2x("12-s"+t).1r("12-l"+t)});6(f.o.b8){f.o.33=f.o.b8}6(f.o.cN===1g){f.o.4B=1g}6(e(u).17(".12-1p").1k==1){f.o.7g=1g;f.o.8M=1g;f.o.7e=1g;f.o.7h=1g;f.o.4j=0;f.o.7m=1g;f.o.2u=1c;f.o.33=1;f.o.3e="av"}6(f.o.1d){f.g.8y=f.g.2E=""+f.o.1d}19{f.g.8y=f.g.2E=e(u)[0].1N.1d}6(f.o.1e){f.g.4m=""+f.o.1e}19{f.g.4m=e(u)[0].1N.1e}6(f.g.2E.1i("%")==-1&&f.g.2E.1i("1J")==-1){f.g.2E+="1J"}6(f.g.4m.1i("%")==-1&&f.g.4m.1i("1J")==-1){f.g.4m+="1J"}6(f.o.9L&&f.g.2E.1i("1J")!=-1&&f.g.4m.1i("1J")!=-1){f.g.4a=1c}19{f.g.4a=1g}e(u).17(\'*[1t*="12-l"], *[1t*="12-bg"]\').1O(18(){6(!e(14).24().30("12-1p")){e(14).cU(e(14).24())}});e(u).17(".12-1p").1O(18(){e(14).3h(\':2I([1t*="12-"])\').1O(18(){e(14).7a()});16 t=e("<1n>").1r("12-cT");6(e(14).17(".12-bg").1k){t.cQ(e(14).17(".12-bg").eq("0"))}19{t.6q(e(14))}});e(u).17(\'.12-1p, *[1t*="12-l"]\').1O(18(){6(e(14).11("12")||e(14).1f("55")||e(14).1f("1N")){6(e(14).11("12")){16 t=e(14).11("12").20().1E(";")}19 6(e(14).1f("55")&&e(14).1f("55").1i(":")!=-1&&e(14).1f("55").1i(";")!=-1){16 t=e(14).1f("55").20().1E(";")}19{16 t=e(14).1f("1N").20().1E(";")}23(x=0;x<t.1k;x++){3G=t[x].1E(":");6(3G[0].1i("4A")!=-1){3G[1]=f.ak(3G[1])}16 n="";6(3G[2]){n=":"+e.5A(3G[2])}6(3G[0]!=" "&&3G[0]!=""){e(14).11(e.5A(3G[0]),e.5A(3G[1])+n)}}}16 r=e(14);r.11("4h",r[0].1N.1m);r.11("4k",r[0].1N.1q);6(e(14).3m("a")&&e(14).3h().1k>0){r=e(14).3h()}16 i=r.1d();16 s=r.1e();6(r[0].1N.1d&&r[0].1N.1d.1i("%")!=-1){i=r[0].1N.1d}6(r[0].1N.1e&&r[0].1N.1e.1i("%")!=-1){s=r[0].1N.1e}r.11("2Z",i);r.11("2Y",s);r.11("7F",r.1a("28-1m"));r.11("7z",r.1a("28-1F"));r.11("8R",r.1a("28-1q"));r.11("8Q",r.1a("28-1o"));16 o=1W 3i(r.1a("2Q"))=="3V"?1C.cD(3i(r.1a("2Q"))*1D)/1D:1;e(14).11("7d",o);6(r.1a("3v-1m-1d").1i("1J")==-1){r.11("6H",r[0].1N.9d)}19{r.11("6H",r.1a("3v-1m-1d"))}6(r.1a("3v-1F-1d").1i("1J")==-1){r.11("6K",r[0].1N.97)}19{r.11("6K",r.1a("3v-1F-1d"))}6(r.1a("3v-1q-1d").1i("1J")==-1){r.11("6J",r[0].1N.9g)}19{r.11("6J",r.1a("3v-1q-1d"))}6(r.1a("3v-1o-1d").1i("1J")==-1){r.11("6I",r[0].1N.9V)}19{r.11("6I",r.1a("3v-1o-1d"))}r.11("9u",r.1a("9h-9j"));r.11("9n",r.1a("9k-1e"))});6(6c.4M.aV){23(16 t=0;t<e(u).17(".12-1p").1k;t++){6(e(u).17(".12-1p").eq(t).11("cp")==6c.4M.aV.1E("#")[1]){f.o.33=t+1}}}e(u).17(\'*[1t*="12-7K-"]\').1O(18(){16 t=e(14).1f("1t").1E(" ");23(16 n=0;n<t.1k;n++){6(t[n].1i("12-7K-")!=-1){16 r=1b(t[n].1E("12-7K-")[1]);e(14).1a({cq:"cj"}).2k(18(t){t.3t();e(u).2V(r)})}}});f.g.2y=e(u).17(".12-1p").1k;6(f.o.7k&&f.g.2y>2){f.o.33=="2h";f.o.92=1g}19{f.o.7k=1g}6(f.o.33=="2h"){f.o.33=1C.26(1C.2h()*f.g.2y+1)}f.o.5h=f.o.5h<f.g.2y+1?f.o.5h:1;f.o.5h=f.o.5h<1?1:f.o.5h;f.g.4r=1;6(f.o.4B){f.g.4r=0}16 n=6c.4M.2i.1i("cs:")===-1?"":"6P:";e(u).17(\'2b[1h*="66.53"], 2b[1h*="53.be"]\').1O(18(){e(14).24().1r("12-2M-4G");6(e(14).24(\'[1t*="12-l"]\')){16 t=e(14);16 r=n;e.bA(r+"//cA.8j.5N/cB/bH/cz/"+e(14).1f("1h").1E("89/")[1].1E("?")[0]+"?v=2&5J=bS&bQ=?",18(e){t.11("6Q",1b(e["ar"]["cv$ap"]["cx$2l"]["dt"])*1P)});16 i=e("<1n>").1r("12-67").1w(e(14).24());6(f.o.47){e("<1Z>").1w(i).1r("12-2F").1f("5J","6O 2M").11("1h",r+"//1Z.8j.5N/bx/"+e(14).1f("1h").1E("89/")[1].1E("?")[0]+"/"+f.o.87)}19{e("<1Z>").1w(i).1r("12-2F").1f("5J","6O 2M").1f("1h",r+"//1Z.8j.5N/bx/"+e(14).1f("1h").1E("89/")[1].1E("?")[0]+"/"+f.o.87)}e("<1n>").1w(i).1r("12-bM");e(14).24().1a({1d:e(14).1d(),1e:e(14).1e()}).2k(18(){f.g.36=1c;6(f.g.38){6(f.o.2u!=1g){f.g.38=1g}f.g.2t=1c}19{f.g.2t=f.g.2w}6(f.o.2u!=1g){f.1x()}f.g.5b=1c;r=e(14).17("2b").11("3X").1i("6P")===-1?n:"";e(14).17("2b").1f("1h",r+e(14).17("2b").11("3X"));e(14).17(".12-67").1M(f.g.v.d).3J(f.g.v.fo,18(){6(f.o.2u=="1U"&&f.g.2t==1c){16 e=2g(18(){f.22()},t.11("6Q")-f.g.v.d);t.11("6C",e)}f.g.36=1g;6(f.g.2T==1c){f.3s(f.g.1L,18(){f.g.2T=1g})}})});16 s="&";6(e(14).1f("1h").1i("?")==-1){s="?"}16 o="&ba=b4&ds=1";6(e(14).1f("1h").1i("4f")==-1){e(14).11("3X",e(14).1f("1h")+s+"4f=1"+o)}19{e(14).11("3X",e(14).1f("1h").2j("4f=0","4f=1")+o)}e(14).11("2Z",e(14).1f("1d"));e(14).11("2Y",e(14).1f("1e"));e(14).1f("1h","")}});e(u).17(\'2b[1h*="62.52"]\').1O(18(){e(14).24().1r("12-2M-4G");6(e(14).24(\'[1t*="12-l"]\')){16 t=e(14);16 r=n;16 i=e("<1n>").1r("12-67").1w(e(14).24());e.bA(r+"//52.5N/bH/dr/2M/"+e(14).1f("1h").1E("2M/")[1].1E("?")[0]+".bS?bQ=?",18(n){6(f.o.47){e("<1Z>").1w(i).1r("12-2F").1f("5J","6O 2M").11("1h",n[0]["bJ"])}19{e("<1Z>").1w(i).1r("12-2F").1f("5J","6O 2M").1f("1h",n[0]["bJ"])}t.11("6Q",1b(n[0]["2l"])*1P);e("<1n>").1w(i).1r("12-bM")});e(14).24().1a({1d:e(14).1d(),1e:e(14).1e()}).2k(18(){f.g.36=1c;6(f.g.38){6(f.o.2u!=1g){f.g.38=1g}f.g.2t=1c}19{f.g.2t=f.g.2w}6(f.o.2u!=1g){f.1x()}f.g.5b=1c;r=e(14).17("2b").11("3X").1i("6P")===-1?n:"";e(14).17("2b").1f("1h",r+e(14).17("2b").11("3X"));e(14).17(".12-67").1M(f.g.v.d).3J(f.g.v.fo,18(){6(f.o.2u=="1U"&&f.g.2t==1c){16 e=2g(18(){f.22()},t.11("6Q")-f.g.v.d);t.11("6C",e)}f.g.36=1g;6(f.g.2T==1c){f.3s(f.g.1L,18(){f.g.2T=1g})}})});16 s="&";6(e(14).1f("1h").1i("?")==-1){s="?"}16 o="&ba=b4";6(e(14).1f("1h").1i("4f")==-1){e(14).11("3X",e(14).1f("1h")+s+"4f=1"+o)}19{e(14).11("3X",e(14).1f("1h").2j("4f=0","4f=1")+o)}e(14).11("2Z",e(14).1f("1d"));e(14).11("2Y",e(14).1f("1e"));e(14).1f("1h","")}});e(u).17("2M, 6X").1O(18(){16 t=1W e(14).1f("1d")!=="2W"?e(14).1f("1d"):"dF";16 n=1W e(14).1f("1e")!=="2W"?e(14).1f("1e"):""+e(14).1e();6(t.1i("%")===-1){t=1b(t)}6(n.1i("%")===-1){n=1b(n)}6(t==="1D%"&&(n===0||n==="0"||n==="1D%")){e(14).1f("1e","1D%");n="1U"}e(14).24().1r("12-2M-4G").1a({1d:t,1e:n}).11({2Z:t,2Y:n});16 r=e(14);e(14).5E("1d").5E("1e").1a({1d:"1D%",1e:"1D%"}).2k(18(){6(1W r.1f("bq")==="2W"){14.dC=0;14.dB()}f.g.36=1c;6(f.g.38){6(f.o.2u!==1g){f.g.38=1g}f.g.2t=1c}19{f.g.2t=f.g.2w}6(f.o.2u!==1g){f.1x()}f.g.5b=1c;e(14).4e("d9",18(){6(f.o.2u==="1U"&&f.g.2t===1c){f.22()}});f.g.36=1g;6(f.g.2T===1c){f.3s(f.g.1L,18(){f.g.2T=1g})}})});6(f.o.4B){f.o.33=f.o.33-1===0?f.g.2y:f.o.33-1}f.g.27=f.o.33;f.g.1L=e(u).17(".12-1p:eq("+(f.g.27-1)+")");e(u).17(".12-1p").dh(\'<1n 1t="12-2c"></1n>\');6(f.o.9W){f.g.3u=e("<1n>").1r("12-dg-5Q").1w(e(u).17(".12-2c"))}6(f.o.a6&&!f.g.2o){f.g.3f=e("<1n>").1r("12-df-5Q").1w(e(u).17(".12-2c"));f.g.3f.3S(e(\'<1n 1t="12-ct-1m"><1n 1t="12-ct-3F"><1n 1t="12-ct-9N"><1n 1t="12-ct-a5"></1n></1n></1n></1n><1n 1t="12-ct-1F"><1n 1t="12-ct-3F"><1n 1t="12-ct-9N"><1n 1t="12-ct-a5"></1n></1n></1n></1n><1n 1t="12-ct-cc"></1n>\'))}f.g.3E=e("<1n>").1a({aD:-1,1K:"1Q"}).1r("12-9T-2n").1w(e(u));e("<1n>").1r("12-9T-c7").1w(f.g.3E);6(e(u).1a("3x")=="c8"){e(u).1a("3x","aq")}6(f.o.7p){e(u).17(".12-2c").1a({bX:"63("+f.o.7p+")"})}19{e(u).17(".12-2c").1a({bY:f.o.8q})}6(f.o.8q=="8p"&&f.o.7p==1g){e(u).17(".12-2c").1a({3l:"1Q 8p !bZ"})}e(u).17(".12-1p 1Z").1O(18(){e(14).5E("1d").5E("1e");6(f.o.43===1c&&f.o.47===1c){6(1W e(14).11("1h")!=="5T"){e(14).11("1h",e(14).1f("1h"));16 t=f.o.3z+"../1a/c0.c6";e(14).1f("1h",t)}}19{6(1W e(14).11("1h")==="5T"){e(14).1f("1h",e(14).11("1h"));e(14).5E("11-1h")}}});e(u).17(".12-1p").4e("cd",18(t){f.g.bG=t.8X-e(14).24().5m().1m;f.g.bF=t.bE-e(14).24().5m().1q});e(u).17(".12-1p").4e("aj",18(t){16 n=e(14).24().5m().1m+f.g.bG;16 r=e(14).24().5m().1q+f.g.bF;16 i=t.8X-n;16 s=t.bE-r;e(14).17("> *:2I(.12-bg)").1O(18(){6(1W e(14).11("4V")!=="2W"&&1b(e(14).11("4V"))!==0){e(14).1a({3p:-i/1D*1b(e(14).11("4V")),3O:-s/1D*1b(e(14).11("4V"))})}})});e(u).17(".12-1p").4e("ce",18(){e(14).17("> *:2I(.12-bg)").1O(18(){6(1W e(14).11("4V")!=="2W"&&1b(e(14).11("4V"))!==0){3a.2e(14,.4,{1a:{3p:0,3O:0}})}})});6(f.o.8M){e(\'<a 1t="12-1s-1S" 2i="#" />\').2k(18(t){t.3t();e(u).2V("1S")}).1w(e(u));e(\'<a 1t="12-1s-1X" 2i="#" />\').2k(18(t){t.3t();e(u).2V("1X")}).1w(e(u));6(f.o.9F){e(u).17(".12-1s-1S, .12-1s-1X").1a({1K:"1Q"});e(u).1R(18(){6(!f.g.8r){6(f.g.2o){e(u).17(".12-1s-1S, .12-1s-1X").1a("1K","2m")}19{e(u).17(".12-1s-1S, .12-1s-1X").1x(1c,1c).2J(2z)}}},18(){6(f.g.2o){e(u).17(".12-1s-1S, .12-1s-1X").1a("1K","1Q")}19{e(u).17(".12-1s-1S, .12-1s-1X").1x(1c,1c).3J(2z)}})}}6(f.o.7e||f.o.7h){16 r=e(\'<1n 1t="12-1o-1s-2R" />\').1w(e(u));f.g.3n=r;6(f.o.3e=="4R"){r.1r("12-aJ-5i")}6(f.o.7h&&f.o.3e!="4R"){e(\'<5G 1t="12-1o-4T" />\').1w(e(u).17(".12-1o-1s-2R"));6(f.o.3e=="1R"){16 i=e(\'<1n 1t="12-1G-1R"><1n 1t="12-1G-1R-2c"><1n 1t="12-1G-1R-bg"></1n><1n 1t="12-1G-1R-1Z"><1Z></1n><5G></5G></1n></1n>\').1w(e(u).17(".12-1o-4T"))}23(x=1;x<f.g.2y+1;x++){16 s=e(\'<a 2i="#" />\').1w(e(u).17(".12-1o-4T")).2k(18(t){t.3t();e(u).2V(e(14).5D()+1)});6(f.o.3e=="1R"){e(u).17(".12-1G-1R, .12-1G-1R-1Z").1a({1d:f.o.7V,1e:f.o.65});16 o=e(u).17(".12-1G-1R");16 a=o.17("1Z").1a({1e:f.o.65});16 l=e(u).17(".12-1G-1R-2c").1a({29:"2O",1K:"2m"});s.1R(18(){16 t=e(u).17(".12-1p").eq(e(14).5D());16 n;6(f.o.43===1c&&f.o.47===1c){6(t.17(".12-4l").1k){n=t.17(".12-4l").11("1h")}19 6(t.17(".12-2F").1k){n=t.17(".12-2F").11("1h")}19 6(t.17(".12-bg").1k){n=t.17(".12-bg").11("1h")}19{n=f.o.3z+f.o.2r+"/6D.4H"}}19{6(t.17(".12-4l").1k){n=t.17(".12-4l").1f("1h")}19 6(t.17(".12-2F").1k){n=t.17(".12-2F").1f("1h")}19 6(t.17(".12-bg").1k){n=t.17(".12-bg").1f("1h")}19{n=f.o.3z+f.o.2r+"/6D.4H"}}e(u).17(".12-1G-1R-1Z").1a({1m:1b(o.1a("28-1m")),1q:1b(o.1a("28-1q"))});a.31(18(){6(e(14).1d()==0){a.1a({3x:"aq",3j:"0 1U",1m:"1U"})}19{a.1a({3x:"cf",3p:-e(14).1d()/2,1m:"50%"})}}).1f("1h",n);o.1a({1K:"2m"}).1x().4s({1m:e(14).3x().1m+(e(14).1d()-o.3D())/2},8i);l.1a({1K:"1Q",29:"34"}).1x().2J(8i)},18(){l.1x().3J(8i,18(){o.1a({29:"2O",1K:"2m"})})})}}6(f.o.3e=="1R"){i.1w(e(u).17(".12-1o-4T"))}e(u).17(".12-1o-4T a:eq("+(f.o.33-1)+")").1r("12-1s-1V")}6(f.o.7e){16 c=e(\'<a 1t="12-1s-22" 2i="#" />\').2k(18(t){t.3t();e(u).2V("22")}).6q(e(u).17(".12-1o-1s-2R"));16 h=e(\'<a 1t="12-1s-1x" 2i="#" />\').2k(18(t){t.3t();e(u).2V("1x")}).1w(e(u).17(".12-1o-1s-2R"))}19 6(f.o.3e!="4R"){e(\'<5G 1t="12-1s-aw 12-1s-cb" />\').6q(e(u).17(".12-1o-1s-2R"));e(\'<5G 1t="12-1s-aw 12-1s-bW" />\').1w(e(u).17(".12-1o-1s-2R"))}6(f.o.7j&&f.o.3e!="4R"){r.1a({1K:"1Q"});e(u).1R(18(){6(!f.g.8r){6(f.g.2o){r.1a("1K","2m")}19{r.1x(1c,1c).2J(2z)}}},18(){6(f.g.2o){r.1a("1K","1Q")}19{r.1x(1c,1c).3J(2z)}})}}6(f.o.3e=="4R"){f.g.42=e(\'<1n 1t="12-1G-2R"></1n>\').1w(e(u));16 i=e(\'<1n 1t="12-1G"><1n 1t="12-1G-2c"><1n 1t="12-1G-1p-2n"><1n 1t="12-1G-1p"></1n></1n></1n></1n>\').1w(f.g.42);f.g.5i=e(u).17(".12-1G-1p-2n");6(!("6s"3M 2q)){f.g.5i.1R(18(){e(14).1r("12-1G-1p-1R")},18(){e(14).2x("12-1G-1p-1R");f.7y()}).aj(18(t){16 n=1b(t.8X-e(14).5m().1m)/e(14).1d()*(e(14).1d()-e(14).17(".12-1G-1p").1d());e(14).17(".12-1G-1p").1x().1a({3p:n})})}19{f.g.5i.1r("12-c9")}e(u).17(".12-1p").1O(18(){16 t=e(14).5D()+1;16 n;6(f.o.43===1c&&f.o.47===1c){6(e(14).17(".12-4l").1k){n=e(14).17(".12-4l").11("1h")}19 6(e(14).17(".12-2F").1k){n=e(14).17(".12-2F").11("1h")}19 6(e(14).17(".12-bg").1k){n=e(14).17(".12-bg").11("1h")}19{n=f.o.3z+f.o.2r+"/6D.4H"}}19{6(e(14).17(".12-4l").1k){n=e(14).17(".12-4l").1f("1h")}19 6(e(14).17(".12-2F").1k){n=e(14).17(".12-2F").1f("1h")}19 6(e(14).17(".12-bg").1k){n=e(14).17(".12-bg").1f("1h")}19{n=f.o.3z+f.o.2r+"/6D.4H"}}16 r=e(\'<a 2i="#" 1t="12-4g-\'+t+\'"><1Z 1h="\'+n+\'"></a>\');r.1w(e(u).17(".12-1G-1p"));6(!("6s"3M 2q)){r.1R(18(){e(14).3h().1x().6t(2z,f.o.7U/1D)},18(){6(!e(14).3h().30("12-4g-1V")){e(14).3h().1x().6t(2z,f.o.81/1D)}})}r.2k(18(n){n.3t();e(u).2V(t)})});6(c&&h){16 p=f.g.3n=e(\'<1n 1t="12-1o-1s-2R 12-cg-5i"></1n>\').1w(e(u));c.8c().2k(18(t){t.3t();e(u).2V("22")}).1w(p);h.8c().2k(18(t){t.3t();e(u).2V("1x")}).1w(p)}6(f.o.7j){f.g.42.1a("1K","1Q");6(p){f.g.3n=p.1a("1K")=="2m"?p:e(u).17(".12-aJ-5i");f.g.3n.1a("1K","1Q")}e(u).1R(18(){e(u).1r("12-1R");6(!f.g.8r){6(f.g.2o){f.g.42.1a("1K","2m");6(f.g.3n){f.g.3n.1a("1K","2m")}}19{f.g.42.1x(1c,1c).2J(2z);6(f.g.3n){f.g.3n.1x(1c,1c).2J(2z)}}}},18(){e(u).2x("12-1R");6(f.g.2o){f.g.42.1a("1K","1Q");6(f.g.3n){f.g.3n.1a("1K","1Q")}}19{f.g.42.1x(1c,1c).3J(2z);6(f.g.3n){f.g.3n.1x(1c,1c).3J(2z)}}})}}f.g.40=e(\'<1n 1t="12-40"></1n>\').1w(e(u));6(f.g.40.1a("1K")=="2m"&&!f.g.40.17("1Z").1k){f.g.6G=18(){f.g.40.1a({1K:"1Q",29:"34"}).2J(41,18(){f.g.6G=1g})};f.g.51=e("<1Z>").1f("1h",f.o.3z+f.o.2r+"/40.4H").1w(f.g.40);f.g.9B=1W 1b(e(u).1a("28-1o"))=="3V"?1b(e(u).1a("28-1o")):0}f.8t();6(f.o.9y&&e(u).17(".12-1p").1k>1){e("3U").6F("bU",18(e){6(!f.g.36&&!f.g.48){6(e.bm==37){f.o.7v(f.g);f.1S("6j")}19 6(e.bm==39){f.o.7l(f.g);f.1X("6j")}}})}6("6s"3M 2q&&e(u).17(".12-1p").1k>1&&f.o.9G){e(u).17(".12-2c").6F("ec",18(e){16 t=e.5a?e.5a:e.bf.5a;6(t.1k==1){f.g.6E=f.g.5z=t[0].bK}});e(u).17(".12-2c").6F("eD",18(e){16 t=e.5a?e.5a:e.bf.5a;6(t.1k==1){f.g.5z=t[0].bK}6(1C.49(f.g.6E-f.g.5z)>45){e.3t()}});e(u).17(".12-2c").6F("eV",18(t){6(1C.49(f.g.6E-f.g.5z)>45){6(f.g.6E-f.g.5z>0){f.o.7l(f.g);e(u).2V("1X")}19{f.o.7v(f.g);e(u).2V("1S")}}})}6(f.o.9M==1c&&e(u).17(".12-1p").1k>1){e(u).17(".12-2c").1R(18(){f.o.au(f.g);6(f.g.2w){f.g.38=1c;f.1x();6(f.g.3u){f.g.3u.1x()}6(f.g.3f){6(f.g.2P){f.g.2P.68()}}f.g.46=(1I 57).4U()}},18(){6(f.g.38==1c){f.22();f.g.38=1g}})}f.8z();6(f.o.1u){f.g.1u=e("<1Z>").1r("12-eU").1w(e(u)).1f("1N",f.o.bo).1a({29:"2O",1K:"eT"}).31(18(){16 t=0;6(!f.g.1u){t=1P}2g(18(){f.g.1u.11("2Z",f.g.1u.1d());f.g.1u.11("2Y",f.g.1u.1e());6(f.g.1u.1a("1m")!="1U"){f.g.1u.11("4h",f.g.1u[0].1N.1m)}6(f.g.1u.1a("1F")!="1U"){f.g.1u.11("6e",f.g.1u[0].1N.1F)}6(f.g.1u.1a("1q")!="1U"){f.g.1u.11("4k",f.g.1u[0].1N.1q)}6(f.g.1u.1a("1o")!="1U"){f.g.1u.11("6d",f.g.1u[0].1N.1o)}6(f.o.7Z!=1g){e("<a>").1w(e(u)).1f("2i",f.o.7Z).1f("eR",f.o.bp).1a({eS:"1Q",eW:"1Q"}).3S(f.g.1u)}f.g.1u.1a({1K:"1Q",29:"34"});f.8Z()},t)}).1f("1h",f.o.1u)}e(2q).2T(18(){f.g.2T=1c;6(!f.g.36){f.3s(f.g.1L,18(){6(f.g.2D){f.g.2D.5C()}f.g.2T=1g});6(f.g.1u){f.8Z()}}});f.g.9a=1c;6(f.o.4B==1c){6(f.o.7g){f.g.2w=1c;e(u).17(".12-1s-22").1r("12-1s-22-1V")}19{e(u).17(".12-1s-1x").1r("12-1s-1x-1V")}f.1X()}19{f.43(f.g.1L,18(){f.g.1L.2J(1P,18(){f.g.48=1g;e(14).1r("12-1V");6(f.o.86){e(14).1M(e(14).11("5d")+25).f1(18(){e(14).17(".12-2F, 2M, 6X").2k();e(14).8D()})}f.g.1L.17(\' > *[1t*="12-l"]\').1O(18(){6(e(14).11("5v")>0){16 t=e(14);t.11("6W",2g(18(){f.8H(t)},t.11("5v")))}})});f.7R(f.g.27);6(f.o.7g){f.g.48=1g;f.22()}19{e(u).17(".12-1s-1x").1r("12-1s-1x-1V")}})}f.o.bz(e(u))};f.22=18(){6(f.g.2w){6(f.g.2f=="1S"&&f.o.92){f.1S()}19{f.1X()}}19{f.g.2w=1c;6(!f.g.36&&!f.g.48){f.5Q()}}e(u).17(".12-1s-22").1r("12-1s-22-1V");e(u).17(".12-1s-1x").2x("12-1s-1x-1V")};f.5Q=18(){6(e(u).17(".12-1V").11("12")){16 t=f.4Z.7i}19{16 t=f.o.7i}16 n=e(u).17(".12-1V").11("5H")?1b(e(u).17(".12-1V").11("5H")):t;6(!f.o.4B&&!e(u).17(".12-1V").11("5H")){16 r=e(u).17(".12-1p:eq("+(f.o.33-1)+")").11("5H");n=r?r:t}2v(f.g.4o);6(f.g.46){6(!f.g.4d){f.g.4d=(1I 57).4U()}6(f.g.4d>f.g.46){f.g.46=(1I 57).4U()}6(!f.g.3I){f.g.3I=n}f.g.3I-=f.g.46-f.g.4d;f.g.46=1g;f.g.4d=(1I 57).4U()}19{f.g.3I=n;f.g.4d=(1I 57).4U()}f.g.3I=1b(f.g.3I);f.g.4o=2g(18(){f.g.4d=f.g.46=f.g.3I=1g;f.22()},f.g.3I);6(f.g.3u){f.g.3u.4s({1d:f.g.1A()},f.g.3I,"8b",18(){e(14).1a({1d:0})})}6(f.g.3f){16 i=f.g.3f.17(".12-ct-1F .12-ct-3F");16 s=f.g.3f.17(".12-ct-1m .12-ct-3F");6(f.g.3f.1a("1K")=="1Q"){i.1a({3F:0});s.1a({3F:0});f.g.3f.2J(b1)}6(!f.g.2P){f.g.2P=1I bD;f.g.2P.aZ(3a.6R(i[0],n/b0,{3g:0},{3T:7B.7A,3g:6N,f0:18(){f.g.2P=1g}}));f.g.2P.aZ(3a.6R(s[0],n/b0,{3g:0},{3T:7B.7A,3g:6N}))}19{f.g.2P.eZ()}}};f.1x=18(){f.g.46=(1I 57).4U();6(f.g.3u){f.g.3u.1x()}6(f.g.3f){6(f.g.2P){f.g.2P.68()}}6(!f.g.38&&!f.g.2t){e(u).17(".12-1s-1x").1r("12-1s-1x-1V");e(u).17(".12-1s-22").2x("12-1s-22-1V")}2v(f.g.4o);f.g.2w=1g};f.af=18(){2v(f.g.4o);f.g.2w=1g;2v(f.g.a9);2v(f.g.a8);2v(f.g.aa);2v(f.g.ab);2v(f.g.aB);6(f.g.3u){f.g.3u.1x()}6(f.g.3f){6(f.g.2P){f.g.2P.68()}}e(u).17("*").1x(1c,1g).8D();e(u).17(".12-1p >").1O(18(){6(e(14).11("3N")){e(14).11("3N").68()}});6(!f.g.38&&!f.g.2t){e(u).17(".12-1s-1x").1r("12-1s-1x-1V");e(u).17(".12-1s-22").2x("12-1s-22-1V")}};f.eY=18(){e(u).17("*").1x();2v(f.g.4o);f.4C(f.g.27,f.g.2f)};f.ak=18(t){6(e.5A(t.20())=="aR"||e.5A(t.20())=="8b"){1T t.20()}19{1T t.2j("7E","aS").2j("7J","ay").2j("7H","az").2j("eQ","eP").2j("eH","eG").2j("eF","eE").2j("eJ","eO").2j("eN","eM").2j("eK","eL").2j("f3","fp").2j("fm","fl").2j("5P","fj").2j("fk","fq")}};f.1S=18(e){6(f.g.27<2){f.g.4r+=1}6(f.g.4r>f.o.4j&&f.o.4j>0&&!e){f.g.4r=0;f.1x();6(f.o.7m==1g){f.o.4j=0}}19{16 t=f.g.27<2?f.g.2y:f.g.27-1;f.g.2f="1S";f.4C(t,f.g.2f)}};f.1X=18(e){6(!f.o.7k){6(!(f.g.27<f.g.2y)){f.g.4r+=1}6(f.g.4r>f.o.4j&&f.o.4j>0&&!e){f.g.4r=0;f.1x();6(f.o.7m==1g){f.o.4j=0}}19{16 t=f.g.27<f.g.2y?f.g.27+1:1;f.g.2f="1X";f.4C(t,f.g.2f)}}19 6(!e){16 t=f.g.27;16 n=18(){t=1C.26(1C.2h()*f.g.2y)+1;6(t==f.g.27){n()}19{f.g.2f="1X";f.4C(t,f.g.2f)}};n()}19 6(e){16 t=f.g.27<f.g.2y?f.g.27+1:1;f.g.2f="1X";f.4C(t,f.g.2f)}};f.4C=18(t,n){f.g.4d=f.g.46=f.g.3I=1g;6(f.g.3u){f.g.3u.1x().1M(2z).4s({1d:0},fr)}6(f.g.3f){f.g.3f.3J(41);6(f.g.2P){f.g.2P.5W().2l(.35)}}6(f.g.5b==1c){f.g.5b=1g;f.g.2w=f.g.2t;f.g.1L.17(\'2b[1h*="66.53"], 2b[1h*="62.52"]\').1O(18(){e(14).24().17(".12-67").2J(f.g.v.fi,18(){e(14).24().17("2b").1f("1h","")})});f.g.1L.17("2M, 6X").1O(18(){14.68()})}e(u).17(\'2b[1h*="66.53"], 2b[1h*="62.52"]\').1O(18(){2v(e(14).11("6C"))});2v(f.g.4o);f.g.61=t;f.g.1v=e(u).17(".12-1p:eq("+(f.g.61-1)+")");6(!n){6(f.g.27<f.g.61){f.g.2f="1X"}19{f.g.2f="1S"}}16 r=0;6(e(u).17(\'2b[1h*="66.53"], 2b[1h*="62.52"]\').1k>0){r=f.g.v.fi}f.43(f.g.1v,18(){f.4s()})};f.43=18(t,n){f.g.48=1c;6(f.g.9a){e(u).1a({29:"34"})}6(f.o.43){16 r=[];16 i=0;6(t.1a("3l-2K")!="1Q"&&t.1a("3l-2K").1i("63")!=-1&&!t.30("12-3w")&&!t.30("12-2I-3w")){16 s=t.1a("3l-2K");s=s.3H(/63\\((.*)\\)/)[1].2j(/"/9U,"");r[r.1k]=[s,t]}t.17("1Z:2I(.12-3w, .12-2I-3w)").1O(18(){6(f.o.47===1c){e(14).1f("1h",e(14).11("1h"))}r[r.1k]=[e(14).1f("1h"),e(14)]});t.17("*").1O(18(){6(e(14).1a("3l-2K")!="1Q"&&e(14).1a("3l-2K").1i("63")!=-1&&!e(14).30("12-3w")&&!e(14).30("12-2I-3w")){16 t=e(14).1a("3l-2K");t=t.3H(/63\\((.*)\\)/)[1].2j(/"/9U,"");r[r.1k]=[t,e(14)]}});6(r.1k==0){e(".12-1G-2R, .12-1s-1X, .12-1s-1S, .12-1o-1s-2R").1a({29:"34"});f.3s(t,n)}19{6(f.g.2o){f.g.3E.1a("1K","2m")}19{f.g.3E.1M(9A).2J(2z)}23(x=0;x<r.1k;x++){e("<1Z>").11("el",r[x]).31(18(){e(14).11("el")[1].1r("12-3w");6(++i==r.1k){f.g.3E.1x(1c,1c).1a({1K:"1Q"});e(".12-1G-2R, .12-1s-1X, .12-1s-1S, .12-1o-1s-2R").1a({29:"34"});6(3W.3Y.1i("fv/7")!==-1||f.g.2o){2g(18(){f.3s(t,n)},50)}19{f.3s(t,n)}}}).3Z(18(){16 t=e(14).11("el")[0].9D(e(14).11("el")[0].9O("/")+1,e(14).11("el")[0].1k);6(2q.4w){4w.ft(\'2A 3Z:\\r\\n\\r\\6x 6L 4K 21 6M 2X 21 2K 44 3l 2K "\'+t+\'" 3m 71 2e a 70 4M 4Q 4i 6Z be 2S. 4P 6Y 21 72 2X 4t 4O 73 76 3M 21 75.\')}19{9P(\'2A 3Z:\\r\\n\\r\\6x 6L 4K 21 6M 2X 21 2K 44 3l 2K "\'+t+\'" 3m 71 2e a 70 4M 4Q 4i 6Z be 2S. 4P 6Y 21 72 2X 4t 4O 73 76 3M 21 75.\')}e(14).1r("12-2I-3w");i++}).1f("1h",r[x][0])}}}19{e(".12-1G-2R, .12-1s-1X, .12-1s-1S, .12-1o-1s-2R").1a({29:"34"});f.3s(t,n)}};f.3s=18(t,n){t.1a({29:"2O",1K:"2m"});6(f.g.6G){f.g.6G()}f.8z();6(f.o.3e=="4R"){f.9J()}t.3h().1O(18(){16 t=e(14);16 n=t.11("4h")?t.11("4h"):"0";16 r=t.11("4k")?t.11("4k"):"0";6(t.3m("a")&&t.3h().1k>0){t.1a({1K:"2m"});t=t.3h()}16 i="1U";16 s="1U";6(t.11("2Z")){6(1W t.11("2Z")=="3V"){i=1b(t.11("2Z"))*f.g.1z}19 6(t.11("2Z").1i("%")!=-1){i=t.11("2Z")}}6(t.11("2Y")){6(1W t.11("2Y")=="3V"){s=1b(t.11("2Y"))*f.g.1z}19 6(t.11("2Y").1i("%")!=-1){s=t.11("2Y")}}16 o=t.11("7F")?1b(t.11("7F"))*f.g.1z:0;16 a=t.11("7z")?1b(t.11("7z"))*f.g.1z:0;16 l=t.11("8R")?1b(t.11("8R"))*f.g.1z:0;16 c=t.11("8Q")?1b(t.11("8Q"))*f.g.1z:0;16 h=t.11("6H")?1b(t.11("6H"))*f.g.1z:0;16 p=t.11("6K")?1b(t.11("6K"))*f.g.1z:0;16 d=t.11("6J")?1b(t.11("6J"))*f.g.1z:0;16 v=t.11("6I")?1b(t.11("6I"))*f.g.1z:0;16 m=t.11("9u");16 g=t.11("9n");6(f.g.4a||f.o.4E>0){6(t.3m("1Z")&&!t.30("12-bg")&&t.1f("1h")){t.1a({1d:"1U",1e:"1U"});6((i==0||i=="1U")&&1W s=="3V"&&s!=0){i=s/t.1e()*t.1d()}6((s==0||s=="1U")&&1W i=="3V"&&i!=0){s=i/t.1d()*t.1e()}6(i=="1U"){i=t.1d()*f.g.1z}6(s=="1U"){s=t.1e()*f.g.1z}t.1a({1d:i,1e:s})}6(!t.3m("1Z")){t.1a({1d:i,1e:s,"9h-9j":1b(m)*f.g.1z+"1J","9k-1e":1b(g)*f.g.1z+"1J"})}6(t.3m("1n")&&t.17("2b").11("3X")){16 y=t.17("2b");y.1f("1d",1b(y.11("2Z"))*f.g.1z).1f("1e",1b(y.11("2Y"))*f.g.1z);t.1a({1d:1b(y.11("2Z"))*f.g.1z,1e:1b(y.11("2Y"))*f.g.1z})}t.1a({28:l+"1J "+a+"1J "+c+"1J "+o+"1J ",9d:h+"1J",97:p+"1J",9g:d+"1J",9V:v+"1J"})}6(!t.30("12-bg")){16 b=t;6(t.24().3m("a")){t=t.24()}16 w=0;6(f.o.7f){w=f.o.7f>0?(f.g.1A()-f.o.7f)/2:0}19 6(f.o.8E){w=f.o.8E>0?(f.g.1A()-f.o.8E)/2:0}w=w<0?0:w;6(n.1i("%")!=-1){t.1a({1m:f.g.1A()/1D*1b(n)-b.1d()/2-o-h})}19 6(w>0||f.g.4a||f.o.4E>0){t.1a({1m:w+1b(n)*f.g.1z})}6(r.1i("%")!=-1){t.1a({1q:f.g.1H()/1D*1b(r)-b.1e()/2-l-d})}19 6(f.g.4a||f.o.4E>0){t.1a({1q:1b(r)*f.g.1z})}}19{16 E=e(u).17(".12-2c");t.1a({1d:"1U",1e:"1U"});i=t.1d();s=t.1e();16 S=f.g.1z;6(f.g.2E.1i("%")!=-1){6(f.g.1A()>i){S=f.g.1A()/i;6(f.g.1H()>s*S){S=f.g.1H()/s}}19 6(f.g.1H()>s){S=f.g.1H()/s;6(f.g.1A()>i*S){S=f.g.1A()/i}}}t.1a({1d:i*S,1e:s*S,3p:E.1d()/2-i*S/2,3O:E.1e()/2-s*S/2})}});t.1a({1K:"1Q",29:"34"});f.8t();n();e(14).8D()};f.8t=18(){6(f.g.51){16 e=18(){6(f.g.51.1e()>0){6(f.g.9B>0){f.g.40.1a({1e:f.g.51.1e()/2})}19{f.g.40.1a({1e:f.g.51.1e(),3O:-f.g.51.1e()/2})}}19{2g(18(){e()},50)}};e()}};f.8z=18(){6(f.o.4E>0){6(e(2q).1d()<f.o.4E){f.g.4a=1c;f.g.2E=f.o.4E+"1J"}19{f.g.4a=1g;f.g.2E=f.g.8y;f.g.1z=1}}6(f.g.4a){16 t=e(u).24();e(u).1a({1d:t.1d()-1b(e(u).1a("28-1m"))-1b(e(u).1a("28-1F"))});f.g.1z=e(u).1d()/1b(f.g.2E);e(u).1a({1e:f.g.1z*1b(f.g.4m)})}19{f.g.1z=1;e(u).1a({1d:f.g.2E,1e:f.g.4m})}6(e(u).6a(".12-6f-6g-2n").1k){e(u).6a(".12-6f-6g-9z").1a({1e:e(u).3y(1c)});e(u).6a(".12-6f-6g-2n").1a({1e:e(u).3y(1c)});e(u).6a(".12-6f-6g-9z").1a({1d:e(2q).1d(),1m:-e(u).6a(".12-6f-6g-2n").5m().1m});6(f.g.2E.1i("%")!=-1){16 n=1b(f.g.2E);16 r=e("3U").1d()/1D*n-(e(u).3D()-e(u).1d());e(u).1d(r)}}e(u).17(".12-2c, .12-1y-2n").1a({1d:f.g.1A(),1e:f.g.1H()});6(f.g.1L&&f.g.1v){f.g.1L.1a({1d:f.g.1A(),1e:f.g.1H()});f.g.1v.1a({1d:f.g.1A(),1e:f.g.1H()})}19{e(u).17(".12-1p").1a({1d:f.g.1A(),1e:f.g.1H()})}};f.8Z=18(){f.g.1u.1a({1d:f.g.1u.11("2Z")*f.g.1z,1e:f.g.1u.11("2Y")*f.g.1z});6(f.g.2o){f.g.1u.1a("1K","2m")}19{f.g.1u.2J(2z)}16 t=6B=6A=6u="1U";6(f.g.1u.11("4h")&&f.g.1u.11("4h").1i("%")!=-1){t=f.g.1A()/1D*1b(f.g.1u.11("4h"))-f.g.1u.1d()/2+1b(e(u).1a("28-1m"))}19{t=1b(f.g.1u.11("4h"))*f.g.1z}6(f.g.1u.11("6e")&&f.g.1u.11("6e").1i("%")!=-1){6B=f.g.1A()/1D*1b(f.g.1u.11("6e"))-f.g.1u.1d()/2+1b(e(u).1a("28-1F"))}19{6B=1b(f.g.1u.11("6e"))*f.g.1z}6(f.g.1u.11("4k")&&f.g.1u.11("4k").1i("%")!=-1){6A=f.g.1H()/1D*1b(f.g.1u.11("4k"))-f.g.1u.1e()/2+1b(e(u).1a("28-1q"))}19{6A=1b(f.g.1u.11("4k"))*f.g.1z}6(f.g.1u.11("6d")&&f.g.1u.11("6d").1i("%")!=-1){6u=f.g.1H()/1D*1b(f.g.1u.11("6d"))-f.g.1u.1e()/2+1b(e(u).1a("28-1o"))}19{6u=1b(f.g.1u.11("6d"))*f.g.1z}f.g.1u.1a({1m:t,1F:6B,1q:6A,1o:6u})};f.9J=18(){f.7N("4e");16 t=f.g.2E.1i("%")==-1?1b(f.g.2E):f.g.1A();e(u).17(".12-1G-1p a").1a({1d:1b(f.o.7V*f.g.1z),1e:1b(f.o.65*f.g.1z)});e(u).17(".12-1G-1p a:4n").1a({3j:0});e(u).17(".12-1G-1p").1a({1e:1b(f.o.65*f.g.1z)});16 n=e(u).17(".12-1G");16 r=f.o.7o.1i("%")==-1?1b(f.o.7o):1b(t/1D*1b(f.o.7o));n.1a({1d:r*1C.26(f.g.1z*1D)/1D});6(n.1d()>e(u).17(".12-1G-1p").1d()){n.1a({1d:e(u).17(".12-1G-1p").1d()})}f.7N("9I")};f.7R=18(t){16 n=t?t:f.g.61;e(u).17(".12-1G-1p a:2I(.12-4g-"+n+")").3h().1O(18(){e(14).2x("12-4g-1V").1x().6t(88,f.o.81/1D)});e(u).17(".12-1G-1p a.12-4g-"+n).3h().1r("12-4g-1V").1x().6t(88,f.o.7U/1D)};f.7y=18(){6(!e(u).17(".12-1G-1p-2n").30("12-1G-1p-1R")){16 t=e(u).17(".12-4g-1V").1k?e(u).17(".12-4g-1V").24():1g;6(t){16 n=t.3x().1m+t.1d()/2;16 r=e(u).17(".12-1G-1p-2n").1d()/2-n;r=r<e(u).17(".12-1G-1p-2n").1d()-e(u).17(".12-1G-1p").1d()?e(u).17(".12-1G-1p-2n").1d()-e(u).17(".12-1G-1p").1d():r;r=r>0?0:r;e(u).17(".12-1G-1p").4s({3p:r},fs)}}};f.7N=18(t){6(f.o.7j&&!e(u).30("12-1R")){2p(t){1l"4e":f.g.42.1a({29:"2O",1K:"2m"});1j;1l"9I":f.g.42.1a({29:"34",1K:"1Q"});1j}}};f.4s=18(){6(e(u).17(".12-1p").1k>1){f.g.36=1c}f.g.48=1g;2v(f.g.4o);2v(f.g.fh);f.g.9C=f.g.1L;f.o.ac(f.g);6(f.o.3e=="4R"){f.7R();6(!("6s"3M 2q)){f.7y()}}f.g.1v.1r("12-9e");16 t=7D=6w=8n=6z=8a=6y=8k=6r=fg=6v=f8="1U";16 a=8e=f.g.1A();16 l=8d=f.g.1H();16 c=f.g.2f=="1S"?f.g.1L:f.g.1v;16 h=c.11("3C")?c.11("3C"):f.o.8s;16 p=f.g.7W[f.g.2f][h];6(p=="1m"||p=="1F"){a=6w=8e=6y=0;6v=0}6(p=="1q"||p=="1o"){l=t=8d=6z=0;6r=0}2p(p){1l"1m":7D=6z=0;6r=-f.g.1A();1j;1l"1F":t=8a=0;6r=f.g.1A();1j;1l"1q":8n=6y=0;6v=-f.g.1H();1j;1l"1o":6w=8k=0;6v=f.g.1H();1j}f.g.1L.1a({1m:t,1F:7D,1q:6w,1o:8n});f.g.1v.1a({1d:8e,1e:8d,1m:6z,1F:8a,1q:6y,1o:8k});16 d=f.g.1L.11("5w")?1b(f.g.1L.11("5w")):f.o.7t;16 v=f.g.1L.11("4L")?1b(f.g.1L.11("4L")):f.o.4S;16 m=f.g.1L.11("4J")?f.g.1L.11("4J"):f.o.4F;16 g=f.g.1v.11("5d")?1b(f.g.1v.11("5d")):f.o.5r;16 y=f.g.1v.11("5t")?1b(f.g.1v.11("5t")):f.o.5y;16 b=f.g.1v.11("5K")?f.g.1v.11("5K"):f.o.5F;16 w=18(){f.g.1L.1M(d+v/15).4s({1d:a,1e:l},v,m,18(){E()})};16 E=18(){f.g.9C.17(\' > *[1t*="12-l"]\').1O(18(){6(e(14).11("3N")){e(14).11("3N").85()}e(14).1a({f7:"1Q"})});f.o.7Q(f.g);f.g.1L=f.g.1v;f.g.27=f.g.61;6(f.o.43&&f.o.47){16 t=f.g.27==f.g.2y?1:f.g.27+1;e(u).17(".12-1p").eq(t-1).17("1Z:2I(.12-3w)").1O(18(){e(14).31(18(){e(14).1r("12-3w")}).3Z(18(){16 t=e(14).11("1h").9D(e(14).11("1h").9O("/")+1,e(14).11("1h").1k);6(2q.4w){4w(\'2A 3Z:\\r\\n\\r\\6x 6L 4K 21 6M 2X 21 2K 44 3l 2K "\'+t+\'" 3m 71 2e a 70 4M 4Q 4i 6Z be 2S. 4P 6Y 21 72 2X 4t 4O 73 76 3M 21 75.\')}19{9P(\'2A 3Z:\\r\\n\\r\\6x 6L 4K 21 6M 2X 21 2K 44 3l 2K "\'+t+\'" 3m 71 2e a 70 4M 4Q 4i 6Z be 2S. 4P 6Y 21 72 2X 4t 4O 73 76 3M 21 75.\')}e(14).1r("12-2I-3w")}).1f("1h",e(14).11("1h"))})}e(u).17(".12-1p").2x("12-1V");e(u).17(".12-1p:eq("+(f.g.27-1)+")").1r("12-1V").2x("12-9e");e(u).17(".12-1o-4T a").2x("12-1s-1V");e(u).17(".12-1o-4T a:eq("+(f.g.27-1)+")").1r("12-1s-1V");6(f.g.2w){f.5Q()}f.g.36=1g;6(f.g.2T==1c){f.3s(f.g.1L,18(){f.g.2T=1g})}};16 S=18(t){f.g.1L.17(\' > *[1t*="12-l"]\').1O(18(){6(!e(14).11("2B")){f.5O(e(14))}e(14).2x("12-8F");16 r=e(14).11("3C")?e(14).11("3C"):p;16 i,s;2p(r){1l"1m":i=-f.g.1A();s=0;1j;1l"1F":i=f.g.1A();s=0;1j;1l"1q":s=-f.g.1H();i=0;1j;1l"1o":s=f.g.1H();i=0;1j;1l"3B":s=0;i=0;1j}6(e(14).11("2B")==="1I"){16 o="1I"}19{16 o=e(14).11("6b")?e(14).11("6b"):1g}2p(o){1l"1m":i=f.g.1A();s=0;1j;1l"1F":i=-f.g.1A();s=0;1j;1l"1q":s=f.g.1H();i=0;1j;1l"1o":s=-f.g.1H();i=0;1j;1l"3B":s=0;i=0;1j;1l"1I":6(e(14).11("3c")){6(e(14).11("3c")==="1m"){i=f.g.1A()}19 6(e(14).11("3c")==="1F"){i=-f.g.1A()}19{i=-1b(e(14).11("3c"))}}19{i=-f.1y.8l}6(e(14).11("3r")){6(e(14).11("3r")==="1q"){s=f.g.1H()}19 6(e(14).11("3r")==="1o"){s=-f.g.1H()}19{s=-1b(e(14).11("3r"))}}19{s=-f.1y.7C}1j}16 u=58=5o=4c=5p=5q=3k=3q="1Q";u=e(14).11("5U")?e(14).11("5U"):f.1y.7x;58=e(14).11("6p")?e(14).11("6p"):f.1y.7G;5o=e(14).11("6i")?e(14).11("6i"):f.1y.7P;4c=e(14).11("5M")?e(14).11("5M"):f.1y.7O;5p=e(14).11("6n")?e(14).11("6n"):f.1y.8T;5q=e(14).11("6o")?e(14).11("6o"):f.1y.8W;6(4c===1){3k=e(14).11("6m")?e(14).11("6m"):f.1y.8P;3q=e(14).11("6l")?e(14).11("6l"):f.1y.8O}19{3k=3q=4c}16 a=e(14).11("78")?e(14).11("78").1E(" "):f.1y.8V;23(16 l=0;l<a.1k;l++){6(a[l].1i("%")===-1&&a[l].1i("1m")!==-1&&a[l].1i("1F")!==-1&&a[l].1i("1q")!==-1&&a[l].1i("1o")!==-1){a[l]=""+1b(a[l])*f.g.1z+"1J"}}16 c=a.8Y(" ");16 h=e(14).11("6k")?e(14).11("6k"):f.1y.8S;16 d=1b(e(14).1a("1m"));16 v=1b(e(14).1a("1q"));16 m=1b(e(14).1f("1t").1E("12-l")[1]);16 g=e(14).3D()>e(14).3y()?e(14).3D():e(14).3y();16 y=1b(u)===0?e(14).3D():g;16 b=1b(u)===0?e(14).3y():g;6(m===-1&&o!=="1I"||e(14).11("3c")==="1m"||e(14).11("3c")==="1F"){6(i<0){i=-(f.g.1A()-d+(3k/2-.5)*y+1D)}19 6(i>0){i=d+(3k/2+.5)*y+1D}}19{i=i*f.g.1z}6(m===-1&&o!=="1I"||e(14).11("3r")==="1q"||e(14).11("3r")==="1o"){6(s<0){s=-(f.g.1H()-v+(3q/2-.5)*b+1D)}19 6(s>0){s=v+(3q/2+.5)*b+1D}}19{s=s*f.g.1z}6(m===-1||o==="1I"){16 w=1}19{16 E=f.g.1L.11("7w")?1b(f.g.1L.11("7w")):f.o.8L;16 w=m*E}6(e(14).11("2B")==="1I"){16 S=f.1y.7t;16 x=f.1y.4S;16 T=f.1y.4F}19{16 S=f.o.7t;16 x=f.o.4S;16 T=f.o.4F}16 N=e(14).11("5w")?1b(e(14).11("5w")):S;16 C=e(14).11("4L")?1b(e(14).11("4L")):x;16 k=e(14).11("4J")?e(14).11("4J"):T;6(t){N=0;C=t}6(e(14).11("6W")){2v(e(14).11("6W"))}16 L={29:"2O"};16 A=e(14);16 O={3g:u,4x:58,4z:5o,7s:5p,7r:5q,5k:3k,5j:3q,x:-i*w,y:-s*w,1M:N/1P,3T:n(k),8B:18(){A.1a(L)}};6(o=="3B"||!o&&r==="3B"||e(14).11("bO")!=="1g"&&e(14).11("2B")==="1I"){O["2Q"]=0;L["2Q"]=e(14).11("7d")}6(e(14).11("3N")){e(14).11("3N").85()}3a.8K(e(14)[0],{8C:c,8G:h});e(14).11("3N",3a.2e(e(14)[0],C/1P,O))})};16 x=18(){f.g.1v.1M(d+g).4s({1d:f.g.1A(),1e:f.g.1H()},y,b)};16 T=18(){6(f.g.3o){d=0}6(1W f.o.9w==="18"){f.o.9w(f.g,d+g)}f.g.1v.17(\' > *[1t*="12-l"]\').1O(18(){6(!e(14).11("2B")){f.5O(e(14))}6(e(14).11("2B")==="1I"){16 t="1I"}19{16 t=e(14).11("3C")?e(14).11("3C"):p}16 r,i;2p(t){1l"1m":r=-f.g.1A();i=0;1j;1l"1F":r=f.g.1A();i=0;1j;1l"1q":i=-f.g.1H();r=0;1j;1l"1o":i=f.g.1H();r=0;1j;1l"3B":i=0;r=0;1j;1l"1I":6(e(14).11("5e")){6(e(14).11("5e")==="1m"){r=-f.g.1A()}19 6(e(14).11("5e")==="1F"){r=f.g.1A()}19{r=1b(e(14).11("5e"))}}19{r=f.1y.9R}6(e(14).11("5f")){6(e(14).11("5f")==="1q"){i=-f.g.1H()}19 6(e(14).11("5f")==="1o"){i=f.g.1H()}19{i=1b(e(14).11("5f"))}}19{i=f.1y.9S}1j}16 s=83=82=74=84=7L=5n=5c="1Q";s=e(14).11("8I")?e(14).11("8I"):f.1y.9X;83=e(14).11("9r")?e(14).11("9r"):f.1y.9Y;82=e(14).11("9q")?e(14).11("9q"):f.1y.a4;74=e(14).11("8A")?e(14).11("8A"):f.1y.9x;84=e(14).11("9p")?e(14).11("9p"):f.1y.9Z;7L=e(14).11("9f")?e(14).11("9f"):f.1y.a0;6(74===1){5n=e(14).11("9t")?e(14).11("9t"):f.1y.a3;5c=e(14).11("9v")?e(14).11("9v"):f.1y.a2}19{5n=5c=74}16 o=e(14).11("9o")?e(14).11("9o").1E(" "):f.1y.a1;23(16 u=0;u<o.1k;u++){6(o[u].1i("%")===-1&&o[u].1i("1m")!==-1&&o[u].1i("1F")!==-1&&o[u].1i("1q")!==-1&&o[u].1i("1o")!==-1){o[u]=""+1b(o[u])*f.g.1z+"1J"}}16 a=o.8Y(" ");16 l=e(14).11("9i")?e(14).11("9i"):f.1y.9E;16 c=1b(e(14).1a("1m"));16 h=1b(e(14).1a("1q"));16 d=1b(e(14).1f("1t").1E("12-l")[1]);6(e(14)[0].1N.1d.1i("%")!==-1){e(14).1a({1d:f.g.1A()/1D*1b(e(14)[0].1N.1d)})}16 v=e(14).3D()>e(14).3y()?e(14).3D():e(14).3y();16 m=1b(s)===0?e(14).3D():v;16 g=1b(s)===0?e(14).3y():v;6(d===-1&&t!=="1I"||e(14).11("5e")==="1m"||e(14).11("5e")==="1F"){6(r<0){r=-(c+(5n/2+.5)*m+1D)}19 6(r>0){r=f.g.1A()-c+(5n/2-.5)*m+1D}}19{r=r*f.g.1z}6(d===-1&&t!=="1I"||e(14).11("5f")==="1q"||e(14).11("5f")==="1o"){6(i<0){i=-(h+(5c/2+.5)*g+1D)}19 6(i>0){i=f.g.1H()-h+(5c/2-.5)*g+1D}}19{i=i*f.g.1z}6(d===-1||t==="1I"){16 y=1}19{16 b=f.g.1v.11("9s")?1b(f.g.1v.11("9s")):f.o.ao;16 y=d*b}6(e(14).11("2B")==="1I"){16 w=f.1y.5r;16 E=f.1y.5y;16 S=f.1y.5F}19{16 w=f.o.5r;16 E=f.o.5y;16 S=f.o.5F}16 x=e(14).11("5d")?1b(e(14).11("5d")):w;16 T=e(14).11("5t")?1b(e(14).11("5t")):E;16 N=e(14).11("5K")?e(14).11("5K"):S;16 C=e(14);16 k=18(){6(C.30("12-2M-4G")){C.1r("12-8F")}6(f.o.86==1c){C.17(".12-2F, 2M, 6X").2k()}6(C.11("5v")>0){C.11("6W",2g(18(){f.8H(C)},C.11("5v")))}};e(14).1a({3p:0,3O:0});16 L={5k:5n,5j:5c,7s:84,7r:7L,3g:s,4x:83,4z:82,29:"34",x:r*y,y:i*y};16 A={3g:0,4x:0,4z:0,7s:0,7r:0,5k:1,5j:1,3T:n(N),1M:x/1P,x:0,y:0,8B:18(){k()}};6(t.1i("3B")!=-1||e(14).11("f4")!=="1g"&&e(14).11("2B")==="1I"){L["2Q"]=0;A["2Q"]=e(14).11("7d")}6(e(14).11("3N")){e(14).11("3N").85()}3a.8K(e(14)[0],{8G:l,8C:a});e(14).11("3N",3a.6R(e(14)[0],T/1P,L,A))})};16 N=18(){6(i(e(u))&&(f.g.1v.11("4W")||f.g.1v.11("5u"))){6(f.g.1v.11("4W")&&f.g.1v.11("5u")){16 t=1C.26(1C.2h()*2);16 n=[["3d",f.g.1v.11("4W")],["bj",f.g.1v.11("5u")]];k(n[t][0],n[t][1])}19 6(f.g.1v.11("4W")){k("3d",f.g.1v.11("4W"))}19{k("bj",f.g.1v.11("5u"))}}19{6(f.g.1v.11("5B")&&f.g.1v.11("5s")){16 t=1C.26(1C.2h()*2);16 n=[["2d",f.g.1v.11("5B")],["bn",f.g.1v.11("5s")]];k(n[t][0],n[t][1])}19 6(f.g.1v.11("5B")){k("2d",f.g.1v.11("5B"))}19 6(f.g.1v.11("5s")){k("bn",f.g.1v.11("5s"))}19{k("2d","1")}}};16 C=18(){6(i(e(u))&&5x.1i("3d")!=-1){k("3d",5x.1E(":")[1])}19{6(5x.1i("3d")!=-1){k("2d","4t")}19{k("2d",5x.1E(":")[1])}}};16 k=18(e,t){16 n=e.1i("f5")==-1?f.t:f.ct;16 r="3d",i,s;6(e.1i("2d")!=-1){r="2d"}6(t.1i("4n")!=-1){s=n["t"+r].1k-1;i="4n"}19 6(t.1i("4t")!=-1){s=1C.26(1C.2h()*o(n["t"+r]));i="2h bs 4t"}19{16 u=t.1E(",");16 a=u.1k;s=1b(u[1C.26(1C.2h()*a)])-1;i="2h bs f9"}L(r,n["t"+r][s])};16 L=18(t,i){16 o=e(u).17(".12-2c");16 a=f.g.1L.17(\'*[1t*="12-l"]\').1k>0?1P:0;16 l=i.6T.20().1i("fa")==-1?1g:1c;16 c=i.6T.20().1i("ff")==-1?1g:1c;16 h=1W i.4p;16 p=1W i.4b;2p(h){1l"3V":h=i.4p;1j;1l"5T":h=1C.26(1C.2h()*(1b(i.4p.1E(",")[1])-1b(i.4p.1E(",")[0])+1))+1b(i.4p.1E(",")[0]);1j;b7:h=1C.26(1C.2h()*(i.4p[1]-i.4p[0]+1))+i.4p[0];1j}2p(p){1l"3V":p=i.4b;1j;1l"5T":p=1C.26(1C.2h()*(1b(i.4b.1E(",")[1])-1b(i.4b.1E(",")[0])+1))+1b(i.4b.1E(",")[0]);1j;b7:p=1C.26(1C.2h()*(i.4b[1]-i.4b[0]+1))+i.4b[0];1j}6(f.g.9m()==1c&&f.o.bu==1c||f.g.2o&&f.o.bv==1c){6(h>=15){h=7}19 6(h>=5){h=4}19 6(h>=4){h=3}19 6(h>2){h=2}6(p>=15){p=7}19 6(p>=5){p=4}19 6(p>=4){p=3}19 6(p>2){p=2}6(p>2&&h>2){p=2;6(h>4){h=4}}}16 d=e(u).17(".12-2c").1d()/h;16 v=e(u).17(".12-2c").1e()/p;6(!f.g.2D){f.g.2D=e("<1n>").1r("12-1y-2n").1r("12-4q-2O").1a({1d:o.1d(),1e:o.1e()}).6q(o)}19{f.g.2D.1x(1c,1c).5C().1a({1K:"2m",1d:o.1d(),1e:o.1e()})}16 m=o.1d()-1C.26(d)*h;16 g=o.1e()-1C.26(v)*p;16 y=[];y.bc=18(){16 e=14.1k,t,n,r;6(e==0)1T 1g;bt(--e){t=1C.26(1C.2h()*(e+1));n=14[e];r=14[t];14[e]=r;14[t]=n}1T 14};23(16 b=0;b<h*p;b++){y.7Y(b)}2p(i.3Q.fd){1l"5W":y.5W();1j;1l"bd-7X":y=s(p,h,"7X");1j;1l"bd-5W":y=s(p,h,"5W");1j;1l"2h":y.bc();1j}16 w=f.g.1L.17(".12-bg");16 x=f.g.1v.17(".12-bg");6(w.1k==0&&x.1k==0){t="2d";i=e.4D(1c,{},f.t["fb"][0]);i.1B.2l=1;i.3Q.1M=0}6(t=="3d"){f.g.3o=(h*p-1)*i.3Q.1M;16 N=0;6(i.2H&&i.2H.2l){N+=i.2H.2l}6(i.2a&&i.2a.2l){N+=i.2a.2l}6(i.2C&&i.2C.2l){N+=i.2C.2l}f.g.3o+=N;16 C=0;6(i.2H&&i.2H.1M){C+=i.2H.1M}6(i.2a&&i.2a.1M){C+=i.2a.1M}6(i.2C&&i.2C.1M){C+=i.2C.1M}f.g.3o+=C}19{f.g.3o=(h*p-1)*i.3Q.1M+i.1B.2l;f.g.54=e("<1n>").1r("12-fc").1w(f.g.2D);f.g.8f=e("<1n>").1r("12-f2").1w(f.g.2D)}16 k=f.g.2f;23(16 L=0;L<h*p;L++){16 A=L%h==0?m:0;16 O=L>(p-1)*h-1?g:0;16 M=e("<1n>").1r("12-1y-3Q").1a({1d:1C.26(d)+A,1e:1C.26(v)+O}).1w(f.g.2D);16 56,D;6(t=="3d"){M.1r("12-3d-2n");16 P=1C.26(d)+A;16 H=1C.26(v)+O;16 B;6(i.2a.5Z=="bB"){6(1C.49(i.2a.1B.3b)>90&&i.3Q.a7!="bL"){B=1C.26(P/7)+A}19{B=P}}19{6(1C.49(i.2a.1B.2U)>90&&i.3Q.a7!="bL"){B=1C.26(H/7)+O}19{B=H}}16 j=P/2;16 F=H/2;16 I=B/2;16 q=18(t,n,r,i,s,o,u,a,f){e("<1n>").1r(t).1a({1d:r,1e:i,3P:"5X("+s+"1J, "+o+"1J, "+u+"1J) 2U("+a+"3L) 3b("+f+"3L) 5R(5L) 4v(1, 1, 1)","-o-3P":"5X("+s+"1J, "+o+"1J, "+u+"1J) 2U("+a+"3L) 3b("+f+"3L) 5R(5L) 4v(1, 1, 1)","-bi-3P":"5X("+s+"1J, "+o+"1J, "+u+"1J) 2U("+a+"3L) 3b("+f+"3L) 5R(5L) 4v(1, 1, 1)","-bh-3P":"5X("+s+"1J, "+o+"1J, "+u+"1J) 2U("+a+"3L) 3b("+f+"3L) 5R(5L) 4v(1, 1, 1)","-5S-3P":"5X("+s+"1J, "+o+"1J, "+u+"1J) 2U("+a+"3L) 3b("+f+"3L) 5R(5L) 4v(1, 1, 1)"}).1w(n)};q("12-3d-3K",M,0,0,0,0,-I,0,0);16 R=0;16 U=0;16 z=0;6(i.2a.5Z=="dW"&&1C.49(i.2a.1B.2U)>90){q("12-3d-5P",M.17(".12-3d-3K"),P,H,-j,-F,-I,6N,0)}19{q("12-3d-5P",M.17(".12-3d-3K"),P,H,-j,-F,-I,0,6N)}q("12-3d-1o",M.17(".12-3d-3K"),P,B,-j,F-I,0,-90,0);q("12-3d-1q",M.17(".12-3d-3K"),P,B,-j,-F-I,0,90,0);q("12-3d-bw",M.17(".12-3d-3K"),P,H,-j,-F,I,0,0);q("12-3d-1m",M.17(".12-3d-3K"),B,H,-j-I,-F,0,0,-90);q("12-3d-1F",M.17(".12-3d-3K"),B,H,j-I,-F,0,0,90);56=M.17(".12-3d-bw");6(i.2a.5Z=="bB"){6(1C.49(i.2a.1B.3b)>90){D=M.17(".12-3d-5P")}19{D=M.17(".12-3d-1m, .12-3d-1F")}}19{6(1C.49(i.2a.1B.2U)>90){D=M.17(".12-3d-5P")}19{D=M.17(".12-3d-1q, .12-3d-1o")}}16 W=y[L]*i.3Q.1M;16 X=f.g.2D.17(".12-3d-2n:eq("+L+") .12-3d-3K");16 V=1I bD;6(i.2H&&i.2H.1B){i.2H.1B.1M=i.2H.1B.1M?(i.2H.1B.1M+W)/1P:W/1P;V.2e(X[0],i.2H.2l/1P,r(i.2H.1B,i.2H.4A))}19{i.2a.1B.1M=i.2a.1B.1M?(i.2a.1B.1M+W)/1P:W/1P}V.2e(X[0],i.2a.2l/1P,r(i.2a.1B,i.2a.4A));6(i.2C){6(!i.2C.1B){i.2C.1B={}}V.2e(X[0],i.2C.2l/1P,r(i.2C.1B,i.2C.4A,"2C"))}}19{16 J=32=2N=2G="1U";16 K=6U=1;6(i.1B.5Z=="2h"){16 Q=["1q","1o","1F","1m"];16 G=Q[1C.26(1C.2h()*Q.1k)]}19{16 G=i.1B.5Z}6(i.6T.20().1i("ag")!=-1&&L%2==0){6(k=="1S"){k="1X"}19{k="1S"}}6(k=="1S"){2p(G){1l"1q":G="1o";1j;1l"1o":G="1q";1j;1l"1m":G="1F";1j;1l"1F":G="1m";1j;1l"8m":G="7S";1j;1l"8h":G="8g";1j;1l"8g":G="8h";1j;1l"7S":G="8m";1j}}2p(G){1l"1q":J=2N=-M.1e();32=2G=0;1j;1l"1o":J=2N=M.1e();32=2G=0;1j;1l"1m":J=2N=0;32=2G=-M.1d();1j;1l"1F":J=2N=0;32=2G=M.1d();1j;1l"8m":J=M.1e();2N=0;32=M.1d();2G=0;1j;1l"8h":J=M.1e();2N=0;32=-M.1d();2G=0;1j;1l"8g":J=-M.1e();2N=0;32=M.1d();2G=0;1j;1l"7S":J=-M.1e();2N=0;32=-M.1d();2G=0;1j}f.g.4Y=i.1B.5I?i.1B.5I:1;6(l==1c&&f.g.4Y!=1){J=J/2;2N=2N/2;32=32/2;2G=2G/2}2p(i.1B.4y){1l"3B":J=2N=32=2G=0;K=0;6U=1;1j;1l"dH":K=0;6U=1;6(f.g.4Y==1){2N=2G=0}1j}6((i.1B.3F||i.1B.2U||i.1B.3b||f.g.4Y!=1)&&!f.g.2o&&i.1B.4y!="1p"){M.1a({4q:"34"})}19{M.1a({4q:"2O"})}6(l==1c){f.g.54.1a({4q:"34"})}19{f.g.54.1a({4q:"2O"})}6(c==1c||i.1B.4y=="1p"||l==1c){16 Y=M.1w(f.g.54);16 Z=M.8c().1w(f.g.8f);56=e("<1n>").1r("12-dN").1w(Y)}19{16 Z=M.1w(f.g.8f)}D=e("<1n>").1r("12-dT").1w(Z).1a({1q:-J,1m:-32,dP:"2m",2Q:K});16 et=y[L]*i.3Q.1M;16 5l=i.1B.3F?i.1B.3F:0;16 6S=i.1B.2U?i.1B.2U:0;16 6V=i.1B.3b?i.1B.3b:0;6(k=="1S"){5l=-5l;6S=-6S;6V=-6V}3a.6R(D[0],i.1B.2l/1P,{3g:5l,4x:6S,4z:6V,5I:f.g.4Y},{1M:et/1P,1q:0,1m:0,2Q:6U,3g:0,4x:0,4z:0,5I:1,3T:n(i.1B.4A)});6(c==1c&&(x.1k<1||x.1k>0&&(x.1f("1h").20().1i("4H")!=-1||x.1d()<f.g.1A()||x.1e()<f.g.1H()))){3a.2e(56[0],i.1B.2l/1P,{1M:et/1P,2Q:0,3T:n(i.1B.4A)})}6((i.1B.4y=="1p"||l==1c)&&i.6T.20().1i("ag")==-1){16 4i=0;6(5l!=0){4i=-5l}3a.2e(56[0],i.1B.2l/1P,{1M:et/1P,1q:2N,1m:2G,3g:4i,5I:f.g.4Y,2Q:K,3T:n(i.1B.4A)})}}6(w.1k){6(t=="3d"||t=="2d"&&(c==1c||i.1B.4y=="1p"||l==1c)){56.3S(e("<1Z>").1f("1h",w.1f("1h")).1a({1d:w[0].1N.1d,1e:w[0].1N.1e,3p:3i(w.1a("3j-1m"))-3i(M.3x().1m),3O:3i(w.1a("3j-1q"))-3i(M.3x().1q)}))}19 6(f.g.54.3h().1k==0){f.g.54.3S(e("<1Z>").1f("1h",w.1f("1h")).1a({1d:w[0].1N.1d,1e:w[0].1N.1e,3p:3i(w.1a("3j-1m")),3O:3i(w.1a("3j-1q"))}))}}6(x.1k){D.3S(e("<1Z>").1f("1h",x.1f("1h")).1a({1d:x[0].1N.1d,1e:x[0].1N.1e,3p:3i(x.1a("3j-1m"))-3i(M.3x().1m),3O:3i(x.1a("3j-1q"))-3i(M.3x().1q)}))}}16 4Z=f.g.1L;16 2L=f.g.1v;2g(18(){4Z.17(".12-bg").1a({29:"2O"})},50);2L.17(".12-bg").1a({29:"2O"});f.g.2D.2x("12-4q-2O");S(a);2g(18(){4Z.1a({1d:0})},a);16 95=1b(2L.11("77"))?1b(2L.11("77")):0;16 at=f.g.3o+95>0?f.g.3o+95:0;2g(18(){6(f.g.2T==1c){f.g.2D.5C();4Z.2x("12-1V");f.3s(2L,18(){f.g.2T=1g})}T();6(2L.17(".12-bg").1k<1||2L.17(".12-bg").1k>0&&2L.17(".12-bg").1f("1h").20().1i("4H")!=-1){f.g.2D.1M(b1).3J(2z,18(){e(14).5C().64()})}2L.1a({1d:f.g.1A(),1e:f.g.1H()})},at);6(f.g.3o<2z){f.g.3o=1P}2g(18(){f.g.2D.1r("12-4q-2O");2L.1r("12-1V");6(2L.17(".12-bg").1k){2L.17(".12-bg").1a({1K:"1Q",29:"34"});6(f.g.2o){2L.17(".12-bg").1a("1K","2m");2g(18(){E()},41)}19{2L.17(".12-bg").2J(41,18(){E()})}}19{E()}},f.g.3o)};16 A=(f.g.1v.11("4W")||f.g.1v.11("5B"))&&f.t||(f.g.1v.11("5u")||f.g.1v.11("5s"))&&f.ct?"1I":"5V";6(!f.g.1v.11("2B")){f.5O(f.g.1v)}6(f.g.1v.11("2B")==="1I"){A="1I"}6(f.o.8u){A="aA"}6(f.o.4B&&!f.g.aI){6(f.g.2y==1){16 d=0;f.o.7Q(f.g)}19{16 O=1b(f.g.1v.11("77"))?1b(f.g.1v.11("77")):0;16 M=A=="1I"?0:v;f.g.aB=2g(18(){E()},M+1C.49(O))}f.g.3o=1c;T();f.g.1v.1a({1d:f.g.1A(),1e:f.g.1H()});6(!f.g.2o){f.g.1v.17(".12-bg").1a({1K:"1Q"}).2J(41)}f.g.aI=1c;f.g.48=1g}19{2p(A){1l"5V":f.g.3o=1g;6(f.g.2D){f.g.2D.5C()}w();S();x();T();1j;1l"1I":6(1W 5x!="2W"){C()}19{N()}1j;1l"aA":L(f.o.8u.4y,f.o.8u.ev);1j}}};f.5O=18(e){16 t=e.11("12")||!e.11("12")&&!e.11("5H")&&!e.11("3C")&&!e.11("6b")&&!e.11("5d")&&!e.11("5w")&&!e.11("5t")&&!e.11("4L")&&!e.11("5v")&&!e.11("5K")&&!e.11("4J")&&!e.11("8A")&&!e.11("5M")&&!e.11("8I")&&!e.11("5U")?"1I":"5V";e.11("2B",t)};f.8H=18(e){6(!e.11("2B")){f.5O(e)}e.2x("12-8F");16 t=f.g.1L;6(f.g.2f!="1S"&&f.g.1v){t=f.g.1v}16 r=t.11("3C")?t.11("3C"):f.o.8s;16 i=f.g.7W[f.g.2f][r];16 s=e.11("3C")?e.11("3C"):i;16 o,u;2p(s){1l"1m":o=-f.g.1A();u=0;1j;1l"1F":o=f.g.1A();u=0;1j;1l"1q":u=-f.g.1H();o=0;1j;1l"1o":u=f.g.1H();o=0;1j;1l"3B":u=0;o=0;1j}6(e.11("2B")==="1I"){16 a="1I"}19{16 a=e.11("6b")?e.11("6b"):1g}2p(a){1l"1m":o=f.g.1A();u=0;1j;1l"1F":o=-f.g.1A();u=0;1j;1l"1q":u=f.g.1H();o=0;1j;1l"1o":u=-f.g.1H();o=0;1j;1l"3B":u=0;o=0;1j;1l"1I":6(e.11("3c")){6(e.11("3c")==="1m"){o=f.g.1A()}19 6(e.11("3c")==="1F"){o=-f.g.1A()}19{o=-1b(e.11("3c"))}}19{o=-f.1y.8l}6(e.11("3r")){6(e.11("3r")==="1q"){u=f.g.1H()}19 6(e.11("3r")==="1o"){u=-f.g.1H()}19{u=-1b(e.11("3r"))}}19{u=-f.1y.7C}1j}16 l=58=5o=4c=5p=5q=3k=3q="1Q";l=e.11("5U")?e.11("5U"):f.1y.7x;58=e.11("6p")?e.11("6p"):f.1y.7G;5o=e.11("6i")?e.11("6i"):f.1y.7P;4c=e.11("5M")?e.11("5M"):f.1y.7O;5p=e.11("6n")?e.11("6n"):f.1y.8T;5q=e.11("6o")?e.11("6o"):f.1y.8W;6(4c===1){3k=e.11("6m")?e.11("6m"):f.1y.8P;3q=e.11("6l")?e.11("6l"):f.1y.8O}19{3k=3q=4c}16 c=e.11("78")?e.11("78").1E(" "):f.1y.8V;23(16 h=0;h<c.1k;h++){6(c[h].1i("%")===-1&&c[h].1i("1m")!==-1&&c[h].1i("1F")!==-1&&c[h].1i("1q")!==-1&&c[h].1i("1o")!==-1){c[h]=""+1b(c[h])*f.g.1z+"1J"}}16 p=c.8Y(" ");16 d=e.11("6k")?e.11("6k"):f.1y.8S;16 v=1b(e.1a("1m"));16 m=1b(e.1a("1q"));16 g=1b(e.1f("1t").1E("12-l")[1]);16 y=e.3D()>e.3y()?e.3D():e.3y();16 b=1b(l)===0?e.3D():y;16 w=1b(l)===0?e.3y():y;6(g===-1&&a!=="1I"||e.11("3c")==="1m"||e.11("3c")==="1F"){6(o<0){o=-(f.g.1A()-v+(3k/2-.5)*b+1D)}19 6(o>0){o=v+(3k/2+.5)*b+1D}}19{o=o*f.g.1z}6(g===-1&&a!=="1I"||e.11("3r")==="1q"||e.11("3r")==="1o"){6(u<0){u=-(f.g.1H()-m+(3q/2-.5)*w+1D)}19 6(u>0){u=m+(3q/2+.5)*w+1D}}19{u=u*f.g.1z}6(g===-1||a==="1I"){16 E=1}19{16 S=f.g.1L.11("7w")?1b(f.g.1L.11("7w")):f.o.8L;16 E=g*S}6(e.11("2B")==="1I"){16 x=f.1y.4S;16 T=f.1y.4F}19{16 x=f.o.4S;16 T=f.o.4F}16 N=e.11("4L")?1b(e.11("4L")):x;16 C=e.11("4J")?e.11("4J"):T;16 k={29:"2O"};16 L={3g:l,4x:58,4z:5o,7s:5p,7r:5q,5k:3k,5j:3q,x:-o*E,y:-u*E,3T:n(C),8B:18(){e.1a(k)}};6(a=="3B"||!a&&s=="3B"||e.11("bO")!=="1g"&&e.11("2B")==="1I"){L["2Q"]=0;k["2Q"]=e.11("7d")}3a.8K(e[0],{8G:d,8C:p});3a.2e(e[0],N/1P,L)};f.4X=18(){f.d={3R:e("<1n>"),aT:18(t){e("<bI>"+t+"</bI>").1w(f.d.3R)},am:18(){e("<4I>").1w(f.d.3R)},aU:18(t){e("<4I><3E>"+t+"</3E></4I>").1w(f.d.3R)},aL:18(t){e("<3E>"+t+"</3E>").1w(f.d.3R.17("4I:4n"))},93:18(t){e("<4I>").1w(f.d.3R.17("4I:4n 3E:4n"))},aF:18(e){f.d.3R.17("4I:4n 3E:4n").1R(18(){e.1a({3v:"ej ei eg",3O:1b(e.1a("3j-1q"))-2,3p:1b(e.1a("3j-1m"))-2})},18(){e.1a({3v:"9b",3O:1b(e.1a("3j-1q"))+2,3p:1b(e.1a("3j-1m"))+2})})},64:18(){6(!e("3U").17(".12-4X-4w").1k){6(!f.d.aC){f.d.aT("eh eB");f.d.am();23(16 t 3M f.o){f.d.aL(t+": <1Y>"+f.o[t]+"</1Y>")}f.d.aT("2A ee");f.d.aU("en 2X ex ez: <1Y>"+e(u).17(".12-1p").1k+"</1Y>");e(u).17(\'.12-2c .12-1p, .12-2c *[1t*="12-l"]\').1O(18(){6(e(14).30("12-1p")){f.d.aU("<1Y>aK "+(e(14).5D()+1)+"</1Y>");f.d.93();f.d.aL("<1Y>aK "+(e(14).5D()+1)+" aG:</1Y><br><br>")}19{f.d.aU("&7b;&7b;&7b;&7b;ep ( "+e(14).aM("aH")+" )");f.d.aF(e(14));f.d.93();f.d.aL("<1Y>"+e(14).aM("aH")+" 4G aG:</1Y><br><br>");f.d.aL("es / 1t: <1Y>"+e(14).1f("1t")+"</1Y>")}e.1O(e(14).11(),18(e,t){f.d.aL(e+": <1Y>"+t+"</1Y>")})});f.d.aC=1c}16 n=e("<1n>").1r("12-4X-4w").1a({3x:"dI",aD:"dL",1q:"6h",1F:"6h",1d:"dU",28:"dV",3l:"e3","3v-e4":"6h",1e:e(2q).1e()-60,2Q:0,aX:7u}).1w(e("3U")).1a({aX:0,2Q:.9}).2k(18(t){6(t.aQ&&t.aP){e(14).7a()}});16 r=e("<1n>").1a({1d:"1D%",1e:"1D%",4q:"1U"}).1w(n);16 i=e("<1n>").1a({1d:"1D%"}).1w(r).3S(f.d.3R)}},e5:18(){e("3U").17(".12-4X-4w").7a()}};e(u).2k(18(e){6(e.aQ&&e.aP){f.d.64()}})};f.31()};16 n=18(e){16 t;6(e.20().1i("aR")!==-1||e.20().1i("8b")!==-1){t=7B.7A}19 6(e.20().1i("7E")!==-1){16 n=e.20().1E("7E")[1];t=2q[n.7I(0).8o()+n.7M(1)].aS}19 6(e.20().1i("7H")!==-1){16 n=e.20().1E("7H")[1];t=2q[n.7I(0).8o()+n.7M(1)].az}19 6(e.20().1i("7J")!==-1){16 n=e.20().1E("7J")[1];t=2q[n.7I(0).8o()+n.7M(1)].ay}1T t};16 r=18(e,t,r,i){6(1W t==="2W"){16 t="e1"}16 s={};6(e.3F!==i){s.3g=e.3F}6(e.3b!==i){s.4z=e.3b}6(e.2U!==i){s.4x=e.2U}6(r==="2C"){s.5k=s.5j=s.ah=1}19 6(e.4v!==i){s.5k=s.5j=s.ah=e.4v}6(e.1M){s.1M=r==="2C"?e.1M/1P:e.1M}s.3T=n(t);1T s};16 i=18(t){16 n=e("<1n>"),r=1g,i=1g,s=["dX","e0","eC","fw","dM"];3P=["eI","eX","e2","er","eo"];23(16 o=s.1k-1;o>=0;o--){r=r?r:n[0].1N[s[o]]!=2W}23(16 o=3P.1k-1;o>=0;o--){n.1a("3P-1N","al-3d");i=i?i:n[0].1N[3P[o]]=="al-3d"}6(r&&n[0].1N[s[4]]!=2W){n.1f("4N","12-ef").1w(t);r=n[0].ek===3&&n[0].ea===9;n.7a()}1T r&&i};16 s=18(e,t,n){16 r=[];6(n=="7X"){23(16 i=0;i<e;i++){23(16 s=0;s<t;s++){r.7Y(i+s*e)}}}19{23(16 i=e-1;i>-1;i--){23(16 s=t-1;s>-1;s--){r.7Y(i+s*e)}}}1T r};16 o=18(e){16 t=0;23(16 n 3M e){6(e.e9(n)){++t}}1T t};16 u=18(){bb=18(e){e=e.20();16 t=/(b9)[ \\/]([\\w.]+)/.5Y(e)||/(5S)[ \\/]([\\w.]+)/.5Y(e)||/(eb)(?:.*2s|)[ \\/]([\\w.]+)/.5Y(e)||/(9c) ([\\w.]+)/.5Y(e)||e.1i("bP")<0&&/(ed)(?:.*? em:([\\w.]+)|)/.5Y(e)||[];1T{7T:t[1]||"",2s:t[2]||"0"}};16 e=bb(3W.3Y),t={};6(e.7T){t[e.7T]=1c;t.2s=e.2s}6(t.b9){t.5S=1c}19 6(t.5S){t.ey=1c}1T t};eA=18(e,t){16 n=["5S","ew","bh","bi","o",""];16 r=0,i,s;bt(r<n.1k&&!e[i]){i=t;6(n[r]==""){i=i.bk(0,1).20()+i.bk(1)}i=n[r]+i;s=1W e[i];6(s!="2W"){n=[n[r]];1T s=="18"?e[i]():e[i]}r++}};t.7q={2s:"5.1.0",9m:18(){6(3W.3Y.3H(/eu/i)||3W.3Y.3H(/e8/i)||3W.3Y.3H(/e7/i)||3W.3Y.3H(/dQ/i)||3W.3Y.3H(/dR/i)||3W.3Y.3H(/dS/i)||3W.3Y.3H(/dO dJ/i)){1T 1c}19{1T 1g}},dK:18(e){6(e.1a("28-1o")=="1U"||e.1a("28-1o")=="1Q"||e.1a("28-1o")==0||e.1a("28-1o")=="9b"){1T 1c}19{1T 1g}},2o:u().9c&&u().2s<9?1c:1g,38:1g,5b:1g,2w:1g,36:1g,2y:79,2f:"1X",4o:79,1A:79,1H:79,7W:{1S:{1m:"1F",1F:"1m",1q:"1o",1o:"1q"},1X:{1m:"1m",1F:"1F",1q:"1q",1o:"1o"}},v:{d:41,fo:88,fi:41}};t.9Q={9R:80,9S:0,5y:1P,5r:0,5F:"7n",2J:1c,9X:0,9Y:0,a4:0,9x:1,a3:1,a2:1,9Z:0,a0:0,a1:["50%","50%","0"],9E:41,8l:-80,7C:0,4S:9A,e6:0,4F:"7n",3J:1c,7x:0,7G:0,7P:0,7O:1,8P:1,8O:1,8T:0,8W:0,8V:["50%","50%","0"],8S:41};t.9H={7i:as};t.9K={9L:1c,4E:0,7f:0,7g:1c,9M:1c,33:1,4B:1c,4j:0,7m:1c,92:1g,7k:1g,2r:"dY",3z:"/69/dZ/",8q:"8p",7p:1g,8M:1c,7e:1c,7h:1c,9y:1c,9G:1c,9F:1c,7j:1g,9W:1g,a6:1c,3e:"1R",7o:"60%",7V:1D,65:60,7U:35,81:1D,86:1c,2u:"1U",87:"fe.f6",43:1c,47:1c,1u:1g,bo:"1m: -6h; 1q: -6h;",7Z:1g,bp:"fu",bu:1c,bv:1c,bz:18(e){},b2:18(e){},ax:18(e){},au:18(e){},ac:18(e){},7Q:18(e){},7v:18(e){},7l:18(e){},7i:as,8s:"1F",ao:.45,8L:.45,5y:1P,4S:1P,5F:"7n",4F:"7n",5r:0,7t:0}})(3A)', 62, 963, '||||||if|||||||||||||||||||||||||||||||||||||||||||||||||||||||||data|ls||this||var|find|function|else|css|parseInt|true|width|height|attr|false|src|indexOf|break|length|case|left|div|bottom|slide|top|addClass|nav|class|yourLogo|nextLayer|appendTo|stop|lt|ratio|sliderWidth|transition|Math|100|split|right|thumbnail|sliderHeight|new|px|display|curLayer|delay|style|each|1e3|none|hover|prev|return|auto|active|typeof|next|strong|img|toLowerCase|the|start|for|parent||floor|curLayerIndex|padding|visibility|animation|iframe|inner||to|prevNext|setTimeout|random|href|replace|click|duration|block|container|ie78|switch|window|skin|version|originalAutoSlideshow|autoPauseSlideshow|clearTimeout|autoSlideshow|removeClass|layersNum|300|LayerSlider|transitiontype|after|ltContainer|sliderOriginalWidth|videopreview|L2|before|not|fadeIn|image|ot|video|T2|hidden|cttl|opacity|wrapper|loaded|resize|rotateX|layerSlider|undefined|of|originalHeight|originalWidth|hasClass|load|L1|firstSlide|visible||isAnimating||paused||TweenLite|rotateY|offsetxout||thumbnailNavigation|circleTimer|rotation|children|parseFloat|margin|curSubScaleX|background|is|bottomWrapper|totalDuration|marginLeft|curSubScaleY|offsetyout|makeResponsive|preventDefault|barTimer|border|preloaded|position|outerHeight|skinsPath|jQuery|fade|slidedirection|outerWidth|li|rotate|param|match|curSlideTime|fadeOut|box|deg|in|tr|marginTop|transform|tile|history|append|ease|body|number|navigator|videoSrc|userAgent|error|shadow|500|thumbsWrapper|imgPreload|or||pausedSlideTime|lazyLoad|isLoading|abs|responsiveMode|rows|curSubScale|startSlideTime|on|autoplay|thumb|originalLeft|it|loops|originalTop|tn|sliderOriginalHeight|last|slideTimer|cols|overflow|nextLoop|animate|all|html|scale3d|console|rotationX|type|rotationY|easing|animateFirstSlide|change|extend|responsiveUnder|easingOut|layer|png|ul|easingout|like|durationout|location|id|your|Please|and|always|durationOut|slidebuttons|getTime|parallaxlevel|transition3d|debug|scale2D|st||shadowImg|vimeo|youtu|curTiles|rel|_|Date|curSubRotateX|init|touches|pausedByVideo|nextSubScaleY|delayin|offsetxin|offsetyin|WordPress|fisrtSlide|thumbnails|scaleY|scaleX|tt|offset|nextSubScaleX|curSubRotateY|curSubSkewX|curSubSkewY|delayIn|customtransition2d|durationin|customtransition3d|showuntil|delayout|LSCustomTransition|durationIn|touchEndX|trim|transition2d|empty|index|removeAttr|easingIn|span|slidedelay|scale|alt|easingin|0deg|scaleout|com|transitionType|back|timer|rotateZ|webkit|string|rotateout|old|reverse|translate3d|exec|direction||nextLayerIndex|player|url|show|tnHeight|www|vpcontainer|pause|layerslider|closest|slideoutdirection|document|originalBottom|originalRight|wp|fullwidth|10px|rotateyout|clicked|perspectiveout|scaleyout|scalexout|skewxout|skewyout|rotatexout|prependTo|layerMarginLeft|ontouchstart|fadeTo|oB|layerMarginTop|curLayerTop|nIt|nextLayerTop|nextLayerLeft|oT|oR|videoTimer|nothumb|touchStartX|bind|showShadow|originalBorderLeft|originalBorderBottom|originalBorderTop|originalBorderRight|seems|URL|180|Play|http|videoDuration|fromTo|nt|name|O2|rt|showUntilTimer|audio|check|cannot|wrong|pointing|URLs|images|nextSubScale|slider|used|timeshift|transformoriginout|null|remove|nbsp|link|originalOpacity|navStartStop|layersContainer|autoStart|navButtons|slideDelay|hoverBottomNav|randomSlideshow|cbNext|forceLoopNum|easeInOutQuint|tnContainerWidth|globalBGImage|global|skewY|skewX|delayOut|150|cbPrev|parallaxout|rotateOut|scrollThumb|originalPaddingRight|easeNone|Linear|offsetYOut|curLayerRight|easeinout|originalPaddingLeft|rotateXOut|easeout|charAt|easein|linkto|nextSubSkewY|slice|bottomNavSizeHelper|scaleOut|rotateYOut|cbAnimStop|changeThumb|bottomright|browser|tnActiveOpacity|tnWidth|slideDirections|forward|push|yourLogoLink||tnInactiveOpacity|nextSubRotateY|nextSubRotateX|nextSubSkewX|kill|autoPlayVideos|youtubePreview|750|embed|nextLayerRight|linear|clone|nextLayerHeight|nextLayerWidth|nextTiles|bottomleft|topright|250|youtube|nextLayerBottom|offsetXOut|topleft|curLayerBottom|toUpperCase|transparent|globalBGColor|forceHideControls|slideDirection|resizeShadow|slideTransition|wpVersion|cssContainer|lswpVersion|sliderOriginalWidthRU|resizeSlider|scalein|onComplete|transformOrigin|dequeue|sublayerContainer|videohack|transformPerspective|sublayerShowUntil|rotatein|text|set|parallaxOut|navPrevNext|jquery|scaleYOut|scaleXOut|originalPaddingBottom|originalPaddingTop|perspectiveOut|skewXOut|fired|transformOriginOut|skewYOut|pageX|join|resizeYourLogo||content|twoWaySlideshow|aUU|script|ut|It|borderRightWidth|looks|issue|showSlider|0px|msie|borderLeftWidth|animating|skewyin|borderTopWidth|font|perspectivein|size|line|library|isMobile|originalLineHeight|transformoriginin|skewxin|rotateyin|rotatexin|parallaxin|scalexin|originalFontSize|scaleyin|cbTimeLineStart|scaleIn|keybNav|helper|400|shadowBtmMod|stopLayer|substring|perspectiveIn|hoverPrevNext|touchNav|slideTransitions|off|resizeThumb|options|responsive|pauseOnHover|hider|lastIndexOf|alert|layerTransitions|offsetXIn|offsetYIn|loading|gi|borderBottomWidth|showBarTimer|rotateIn|rotateXIn|skewXIn|skewYIn|transformOriginIn|scaleYIn|scaleXIn|rotateYIn|half|showCircleTimer|depth|t2|t1|t3|t4|cbAnimStart|lsShowNotice|oldjquery|forcestop|mirror|scaleZ|object|mousemove|ieEasing|preserve|aeU||parallaxIn|group|relative|entry|4e3||cbPause|disabled|sides|cbStop|easeIn|easeOut|forced|t5|putData|zIndex|meta||properties|tagName|firstSlideAnimated|above|SLIDE||prop|initialized|layerSliderCustomTransitions|altKey|shiftKey|swing|easeInOut|||hash|norotate|marginRight|layerSliderTransitions|add|2e3|350|cbStart|with|opaque|update|plugin|default|firstLayer|chrome|wmode|uaMatch|randomize|col||originalEvent||moz|ms|custom3d|substr|curSkin|which|custom2d|yourLogoStyle|yourLogoTarget|controls||from|while|optimizeForMobile|optimizeForIE78|front|vi||cbInit|getJSON|horizontal|head|TimelineLite|pageY|parallaxStartY|parallaxStartX|api|h1|thumbnail_large|clientX|large|playvideo|JS|fadeout|compatible|callback|createStyleSheet|json|that|keydown|multiple|sideright|backgroundImage|backgroundColor|important|blank|causing|copy|loads|extra|theme|gif|indicator|static|touchscroll|another|sideleft|center|mouseenter|mouseleave|absolute|below|using|title|pointer|exclam|here|continue|forceStop|enableCSS3|deeplink|cursor|clicking|file||more|media|read|yt|about|videos|gdata|feeds|updating|round|enabled|stylesheet|already|Skin|Trying|Fallback|mode|were|Neither|animateFirstLayer|mistyped|Possibilities|insertAfter|information|force|gpuhack|insertBefore|without|Loading|WP|can|You|within|option|includes|Put|Troubleshooting|Advanced|are|you|Settings|ended|enable|area|admin|navigate|sliders|circle|bar|wrapAll|page|main|requires|least|kreaturamedia|support||IE|browsers|v2|html5|seconds|wordpress|faq|older|because|Important|higher|newer|play|currentTime|Updater|use|640|problems|mixed|fixed|Phone|isHideOn3D|10000000000|WebkitPerspective|curtile|Windows|dispay|iPad|iPod|BlackBerry|nexttile|300px|20px|vertical|perspective|v5|skins|OPerspective|easeInOutQuart|msTransformStyle|black|radius|hide|showUntil|iPhone|webOS|hasOwnProperty|offsetLeft|opera|touchstart|mozilla|Content|test3d|red|Init|solid|2px|offsetHeight||rv|Number|WebkitTransformStyle|Layer||MozTransformStyle|distance||Android|obj|khtml|slides|safari|found|lsPrefixes|code|msPerspective|touchmove|Cubic|cubic|Quart|quart|transformStyle|quint|expo|Expo|Sine|sine|Quint|Quad|quad|target|textDecoration|bock|yourlogo|touchend|outline|OTransformStyle|restart|resume|onReverseComplete|queue|nexttiles|circ|fadein|custom|jpg|filter|layerMarginBottom|specified|carousel|t2d|curtiles|sequence|maxresdefault|crossfad|layerMarginRight|changeTimer||Back|bounce|Elastic|elastic|||Circ|Bounce|450|600|log|_self|Trident|MozPerspective'.split('|'), 0, {}))

/*!
 * jQuery Transit - CSS3 transitions and transformations
 * modified for LayerSlider
 */
eval(function(p, a, c, k, e, d) {
    e = function(c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
    }
    ;
    while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b','g'), k[c])
        }
    }
    return p
}('(j(e){j r(e){7(e J t.F)q e;k n=["2W","2V","O","1U"];k r=e.2U(0).2X()+e.2Y(1);7(e J t.F){q e}1k(k i=0;i<n.31;++i){k s=n[i]+r;7(s J t.F){q s}}}j i(){t.F[n.C]="";t.F[n.C]="Y(30)";q t.F[n.C]!==""}j f(e){7(E e==="1D"){4.2a(e)}q 4}j l(e,t,n){7(t===K){e.12(n)}L 7(t){e.12(t,n)}L{n()}}j c(t){k n=[];e.1j(t,j(t){t=e.2Z(t);t=e.H.1C[t]||e.2T[t]||t;t=d(t);7(e.2S(t,n)===-1){n.X(t)}});q n}j h(t,n,r,i){k s=c(t);7(e.1b[r]){r=e.1b[r]}k o=""+m(n)+" "+r;7(1B(i,10)>0){o+=" "+m(i)}k u=[];e.1j(s,j(e,t){u.X(t+" "+o)});q u.1n(", ")}j p(t,r){7(!r){e.2M[t]=K}e.H.1C[t]=n.C;e.W[t]={Q:j(n){k r=e(n).16("H:C");q r.Q(t)},G:j(n,r){k i=e(n).16("H:C");i.1u(t,r);e(n).16({"H:C":i})}}}j d(e){q e.1W(/([A-Z])/g,j(e){q"-"+e.21()})}j v(e,t){7(E e==="1D"&&!e.2L(/^[\\-0-9\\.]+$/)){q e}L{q""+e+t}}j m(t){k n=t;7(e.1H.1x[n]){n=e.1H.1x[n]}q v(n,"1U")}e.H={2K:"0.9.9",2N:K,1C:{2O:"1m",2R:"1m",2Q:"1m",2P:"1m",33:"1l",34:"1l",3j:"1l",3i:"1l"},20:K,1Y:27};k t=3h.3k("3l");k n={};k s=3o.3n.21().3m("3g")>-1;n.I=r("I");n.2b=r("2b");n.C=r("C");n.U=r("U");n.1Z=i();k o={I:"1N",2J:"3f",37:"36",35:"38",3a:"3e"};k u=n.1N=o[n.I]||D;1k(k a J n){7(n.1X(a)&&E e.1L[a]==="B"){e.1L[a]=n[a]}}t=D;e.1b={1F:"1d","J":"1d-J",1h:"1d-1h","J-1h":"1d-J-1h",3c:"w-z(0,1,.5,1)",3b:"w-z(.18, .3p, .2d, .19)",2h:"w-z(.2g,.2f,.1V,1)",2e:"w-z(.2I,.24,.1V,1)",2B:"w-z(.6,.2A,.2i,.2z)",2x:"w-z(.2y,.2C,.1Q,1)",2D:"w-z(.2H,.2G,.15,.1O)",2F:"w-z(.29,.1r,.2E,.2w)",2v:"w-z(.19,1,.22,1)",2n:"w-z(1,0,0,1)",2m:"w-z(.18,.2l,.1R,.2j)",2k:"w-z(.25,.46,.45,.2o)",2p:"w-z(.2u,.2c,.2t,.2s)",2q:"w-z(.2r,.2c,.3w,.22)",3W:"w-z(.1Q,.43,.44,1)",42:"w-z(.41,0,.26,1)",40:"w-z(.3Z,.1r,.3V,.3U)",4a:"w-z(.23,1,.32,1)",3X:"w-z(.1O,0,.3Y,1)",49:"w-z(.47,0,.4c,.4f)",4d:"w-z(.39,.4b,.4e,1)",48:"w-z(.3S,.1r,.18,.29)",3A:"w-z(.6,-.28,.3z,.24)",3B:"w-z(.26, .3C,.32,1.3D)",3q:"w-z(.1R,-.18,.3x,1.18)"};e.W["H:C"]={Q:j(t){q e(t).1P("C")||1S f},G:j(t,r){k i=r;7(!(i 3s f)){i=1S f(i)}7(n.C==="3r"&&!s){t.F[n.C]=i.1t(K)}L{t.F[n.C]=i.1t()}e(t).1P("C",i)}};e.W.C={G:e.W["H:C"].G};7(e.1y.3t<"1.8"){e.W.U={Q:j(e){q e.F[n.U]},G:j(e,t){e.F[n.U]=t}};e.W.I={Q:j(e){q e.F[n.I]},G:j(e,t){e.F[n.I]=t}}}p("1q");p("1s");p("N");p("1z");p("R");p("S");p("17");p("1i");p("Y");p("1o");p("1c");p("1p");p("1v");p("x",K);p("y",K);f.1E={1u:j(e,t){k n=E t==="1D"?t.1a(","):t.3u===1T?t:[t];n.3T(e);f.1E.G.V(4,n)},G:j(e){k t=1T.1E.3v.V(3E,[1]);7(4.1A[e]){4.1A[e].V(4,t)}L{4[e]=t.1n(",")}},Q:j(e){7(4.1w[e]){q 4.1w[e].V(4)}L{q 4[e]||0}},1A:{1s:j(e){4.17=v(e,"M")},1q:j(e,t){7(t===B){t=e}4.N=e+","+t},17:j(e){4.17=v(e,"M")},1i:j(e){4.1i=v(e,"M")},Y:j(e){4.Y=v(e,"M")},N:j(e,t){7(t===B){t=e}4.N=e+","+t},1z:j(e,t,n){7(t===B){t=e}7(n===B){n=e}4.1z=e+","+t+","+n},1p:j(e){4.1p=v(e,"M")},1v:j(e){4.1v=v(e,"M")},1c:j(e){4.1c=v(e,"T")},x:j(e){4.G("R",e,D)},y:j(e){4.G("R",D,e)},3F:j(e){4.G("S",e,D,D)},3O:j(e){4.G("S",D,e,D)},3N:j(e){4.G("S",D,D,e)},R:j(e,t){7(4.14===B){4.14=0}7(4.13===B){4.13=0}7(e!==D&&e!==B){4.14=v(e,"T")}7(t!==D&&t!==B){4.13=v(t,"T")}4.R=4.14+","+4.13},S:j(e,t,n){7(4.1f===B){4.1f=0}7(4.1g===B){4.1g=0}7(4.1e===B){4.1e=0}7(e!==D&&e!==B){4.1f=v(e,"T")}7(t!==D&&t!==B){4.1g=v(t,"T")}7(n!==D&&n!==B){4.1e=v(n,"T")}4.S=4.1f+","+4.1g+","+4.1e}},1w:{1s:j(){k e=4.17||"1M".1a("M")[0];q v(e,"M")},1q:j(){k e=(4.N||"1,1,1").1a(",");7(e[0]){e[0]=P(e[0])}7(e[1]){e[1]=P(e[1])}7(e[2]){e[2]=P(e[2])}q e[0]===e[1]===e[2]?e[0]:e},x:j(){q 4.14||0},y:j(){q 4.13||0},N:j(){k e=(4.N||"1,1,1").1a(",");7(e[0]){e[0]=P(e[0])}7(e[1]){e[1]=P(e[1])}7(e[2]){e[2]=P(e[2])}q e[0]===e[1]===e[2]?e[0]:e},1o:j(){k e=(4.1o||"0,0,0,1M").1a(",");1k(k t=0;t<=3;++t){7(e[t]){e[t]=P(e[t])}}7(e[3]){e[3]=v(e[3],"M")}q e}},2a:j(e){k t=4;e.1W(/([a-3P-3Q-9]+)\\((.*?)\\)/g,j(e,n,r){t.1u(n,r)})},1t:j(e){k t=[];1k(k r J 4){7(4.1X(r)){7(!n.1Z&&(r==="1i"||r==="Y"||r==="1c"||r==="U")){3R}7(r[0]!=="3M"){7(e&&r==="N"){t.X(r+"3d("+4[r]+",1)")}L 7(e&&r==="R"){t.X(r+"3d("+4[r]+",0)")}L{t.X(r+"("+4[r]+")")}}}}q t.1n(" ")}};e.1y.I=e.1y.H=j(t,r,i,s){k o=4;k a=0;k f=K;7(E r==="j"){s=r;r=B}7(E i==="j"){s=i;i=B}7(E t.1J!=="B"){i=t.1J;11 t.1J}7(E t.1I!=="B"){r=t.1I;11 t.1I}7(E t.1G!=="B"){s=t.1G;11 t.1G}7(E t.12!=="B"){f=t.12;11 t.12}7(E t.1K!=="B"){a=t.1K;11 t.1K}7(E r==="B"){r=e.1H.1x.1F}7(E i==="B"){i=e.1b.1F}r=m(r);k c=h(t,r,i,a);k p=e.H.20&&n.I;k d=p?1B(r,10)+1B(a,10):0;7(d===0){k v=j(e){o.16(t);7(s){s.V(o)}7(e){e()}};l(o,f,v);q o}k g={};k y=j(r){k i=27;k a=j(){7(i){o.3L(u,a)}7(d>0){o.1j(j(){4.F[n.I]=g[4]||D})}7(E s==="j"){s.V(o)}7(E r==="j"){r()}};7(d>0&&u&&e.H.1Y){i=K;o.3H(u,a)}L{3G.3I(a,d)}o.1j(j(){7(d>0){4.F[n.I]=c}e(4).16(t)})};k b=j(e){4.3J;y(e)};l(o,f,b);q 4};e.H.3K=h})(3y)', 62, 264, '||||this|||if||||||||||||function|var||||||return||||||cubic|||bezier||undefined|transform|null|typeof|style|set|transit|transition|in|true|else|deg|scale||parseFloat|get|translate|translate3d|px|transformOrigin|apply|cssHooks|push|rotateY|||delete|queue|_translateY|_translateX||css|rotate|55||split|cssEase|perspective|ease|_translate3dZ|_translate3dX|_translate3dY|out|rotateX|each|for|padding|margin|join|rotate3d|skewX|kmScale|05|kmRotate|toString|setFromString|skewY|getter|speeds|fn|scale3d|setter|parseInt|propertyMap|string|prototype|_default|complete|fx|duration|easing|delay|support|0deg|transitionEnd|86|data|165|68|new|Array|ms|355|replace|hasOwnProperty|useTransitionEnd|transform3d|enabled|toLowerCase|||045||175|false||95|parse|transitionDelay|03|675|easeInOutCubic|61|215|easeOutCubic|98|53|easeOutQuad|085|easeInQuad|easeInOutExpo|94|easeInOutQuad|easeInQuart|895|955|515|455|easeOutExpo|035|easeOutCirc|075|335|04|easeInCirc|82|easeInOutCirc|795|easeInExpo|135|785|645|MozTransition|version|match|cssNumber|modifiedForLayerSlider|marginLeft|marginTop|marginBottom|marginRight|inArray|cssProps|charAt|Webkit|Moz|toUpperCase|substr|camelCase|90deg|length||paddingLeft|paddingRight|WebkitTransition|oTransitionEnd|OTransition|webkitTransitionEnd||msTransition|easeInCubic|snap||MSTransitionEnd|transitionend|chrome|document|paddingTop|paddingBottom|createElement|div|indexOf|userAgent|navigator|055|easeInOutBack|WebkitTransform|instanceof|jquery|constructor|slice|685|265|jQuery|735|easeInBack|easeOutBack|885|275|arguments|t3dx|window|bind|setTimeout|offsetWidth|getTransitionValue|unbind|_|t3dz|t3dy|zA|Z0|continue|445|unshift|06|855|easeOutQuart|easeInOutQuint|07|755|easeInQuint|77|easeInOutQuart|84|||||easeInOutSine|easeInSine|easeOutQuint|575|745|easeOutSine|565|715'.split('|')));

/*!
 * VERSION: 1.11.2
 * DATE: 2013-11-20
 * UPDATES AND DOCS AT: http://www.greensock.com
 *
 * @license Copyright (c) 2008-2013, GreenSock. All rights reserved.
 * This work is subject to the terms at http://www.greensock.com/terms_of_use.html or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 *
 * @author: Jack Doyle, jack@greensock.com
 */

eval(function(p, a, c, k, e, d) {
    e = function(c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
    }
    ;
    if (!''.replace(/^/, String)) {
        while (c--) {
            d[e(c)] = k[c] || e(c)
        }
        k = [function(e) {
            return d[e]
        }
        ];
        e = function() {
            return '\\w+'
        }
        ;
        c = 1
    }
    ;while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b','g'), k[c])
        }
    }
    return p
}('(17(e){"5v 5u";19 t=e.6h||e;1a(!t.5c){19 n,r,i,s,o,u=17(e){19 n,r=e.1s("."),i=t;1b(n=0;r.1c>n;n++)i[r[n]]=i=i[r[n]]||{};18 i},a=u("4F.4A"),f=1e-10,l=[].6G,c=17(){},h=17(){19 e=9h.1x.9i,t=e.1Z([]);18 17(n){18 n 2a 3K||"3T"==1j n&&!!n.28&&e.1Z(n)===t}}(),p={},d=17(n,r,i,s){15.4v=p[n]?p[n].4v:[],p[n]=15,15.5a=1d,15.76=i;19 o=[];15.5F=17(a){1b(19 f,l,c,h,v=r.1c,m=v;--v>-1;)(f=p[r[v]]||1g d(r[v],[])).5a?(o[v]=f.5a,m--):a&&f.4v.28(15);1a(0===m&&i)1b(l=("4F.4A."+n).1s("."),c=l.4G(),h=u(l.1G("."))[c]=15.5a=i.36(i,o),s&&(t[c]=h,"17"==1j 5V&&5V.9j?5V((e.8F?e.8F+"/":"")+n.1s(".").1G("/"),[],17(){18 h}):"9f"!=1j 5E&&5E.8A&&(5E.8A=h)),v=0;15.4v.1c>v;v++)15.4v[v].5F()},15.5F(!0)},v=e.3R=17(e,t,n,r){18 1g d(e,t,n,r)},m=a.7W=17(e,t,n){18 t=t||17(){},v(e,[],17(){18 t},n),t};v.97=t;19 g=[0,0,1,1],y=[],b=m("2j.7v",17(e,t,n,r){15.5B=e,15.6j=n||0,15.6g=r||0,15.5C=t?g.3U(t):g},!0),w=b.7Z={},E=b.7X=17(e,t,n,r){1b(19 i,s,o,u,f=t.1s(","),l=f.1c,c=(n||"5s,5R,5r").1s(",");--l>-1;)1b(s=f[l],i=r?m("2j."+s,1d,!0):a.2j[s]||{},o=c.1c;--o>-1;)u=c[o],w[s+"."+u]=w[u+s]=i[u]=e.2x?e:e[u]||1g e};1b(i=b.1x,i.3m=!1,i.2x=17(e){1a(15.5B)18 15.5C[0]=e,15.5B.36(1d,15.5C);19 t=15.6j,n=15.6g,r=1===t?1-e:2===t?e:.5>e?2*e:2*(1-e);18 1===n?r*=r:2===n?r*=r*r:3===n?r*=r*r*r:4===n&&(r*=r*r*r*r),1===t?1-r:2===t?r:.5>e?r/2:1-r/2},n=["8u","8w","9a","9c","9l,9x"],r=n.1c;--r>-1;)i=n[r]+",9y"+r,E(1g b(1d,1d,1,r),i,"5R",!0),E(1g b(1d,1d,2,r),i,"5s"+(0===r?",96":"")),E(1g b(1d,1d,3,r),i,"5r");w.9s=a.2j.8u.5s,w.9o=a.2j.8w.5r;19 S=m("8m.8q",17(e){15.40={},15.8r=e||15});i=S.1x,i.8M=17(e,t,n,r,i){i=i||0;19 u,a,f=15.40[e],l=0;1b(1d==f&&(15.40[e]=f=[]),a=f.1c;--a>-1;)u=f[a],u.c===t&&u.s===n?f.2W(a,1):0===l&&i>u.2s&&(l=a+1);f.2W(l,0,{c:t,s:n,8o:r,2s:i}),15!==s||o||s.3a()},i.9n=17(e,t){19 n,r=15.40[e];1a(r)1b(n=r.1c;--n>-1;)1a(r[n].c===t)18 r.2W(n,1),2u 0},i.8C=17(e){19 t,n,r,i=15.40[e];1a(i)1b(t=i.1c,n=15.8r;--t>-1;)r=i[t],r.8o?r.c.1Z(r.s||n,{2r:e,2v:n}):r.c.1Z(r.s||n)};19 x=e.9z,T=e.8S,N=8l.95||17(){18(1g 8l).92()},C=N();1b(n=["64","8W","91","o"],r=n.1c;--r>-1&&!x;)x=e[n[r]+"8Z"],T=e[n[r]+"93"]||e[n[r]+"8U"];m("52",17(e,t){19 n,r,i,u,a,f=15,l=N(),h=t!==!1&&x,p=17(e){C=N(),f.3u=(C-l)/8d;19 t,s=f.3u-a;(!n||s>0||e===!0)&&(f.41++,a+=s+(s>=u?.9t:u-s),t=!0),e!==!0&&(i=r(p)),t&&f.8C("5y")};S.1Z(f),f.3u=f.41=0,f.5y=17(){p(!0)},f.4X=17(){1d!=i&&(h&&T?T(i):aa(i),r=c,i=1d,f===s&&(o=!1))},f.3a=17(){1d!==i&&f.4X(),r=0===n?c:h&&x?x:17(e){18 6p(e,0|8d*(a-f.3u)+1)},f===s&&(o=!0),p(2)},f.6f=17(e){18 22.1c?(n=e,u=1/(n||60),a=15.3u+u,f.3a(),2u 0):n},f.8e=17(e){18 22.1c?(f.4X(),h=e,f.6f(n),2u 0):h},f.6f(e),6p(17(){h&&(!i||5>f.41)&&f.8e(!1)},af)}),i=a.52.1x=1g a.8m.8q,i.2M=a.52;19 k=m("5k.72",17(e,t){1a(15.1o=t=t||{},15.1N=15.2l=e||0,15.2J=1C(t.4y)||0,15.1y=1,15.2c=t.1V===!0,15.1z=t.1z,15.2G=t.43===!0,q){o||s.3a();19 n=15.1o.5Q?I:q;n.1P(15,n.1n),15.1o.34&&15.34(!0)}});s=k.8h=1g a.52,i=k.1x,i.2o=i.1I=i.2w=i.1A=!1,i.1K=i.1n=0,i.1O=-1,i.1f=i.3h=i.32=i.1p=i.1U=1d,i.1A=!1;19 L=17(){o&&N()-C>8p&&s.3a(),6p(L,8p)};L(),i.7w=17(e,t){18 22.1c&&15.4e(e,t),15.43(!1).34(!1)},i.6c=17(e,t){18 22.1c&&15.4e(e,t),15.34(!0)},i.aB=17(e,t){18 22.1c&&15.4e(e,t),15.34(!1)},i.4e=17(e,t){18 15.2Z(1C(e),t!==!1)},i.ar=17(e,t){18 15.43(!1).34(!1).2Z(e?-15.2J:0,t!==!1,!0)},i.as=17(e,t){18 22.1c&&15.4e(e||15.26(),t),15.43(!0).34(!1)},i.1B=17(){},i.5i=17(){18 15},i.4O=17(){19 e,t=15.1p,n=15.1i;18!t||!15.1I&&!15.1A&&t.4O()&&(e=t.3y())>=n&&n+15.26()/15.1y>e},i.1M=17(e,t){18 o||s.3a(),15.1I=!e,15.2c=15.4O(),t!==!0&&(e&&!15.1U?15.1p.1P(15,15.1i-15.2J):!e&&15.1U&&15.1p.3C(15,!0)),!1},i.2p=17(){18 15.1M(!1,!1)},i.4c=17(e,t){18 15.2p(e,t),15},i.35=17(e){1b(19 t=e?15:15.1U;t;)t.2o=!0,t=t.1U;18 15},i.5o=17(e){1b(19 t=e.1c,n=e.3U();--t>-1;)"{4t}"===e[t]&&(n[t]=15);18 n},i.aw=17(e,t,n,r){1a("a8"===(e||"").1t(0,2)){19 i=15.1o;1a(1===22.1c)18 i[e];1d==t?3L i[e]:(i[e]=t,i[e+"6o"]=h(n)&&-1!==n.1G("").1k("{4t}")?15.5o(n):n,i[e+"6l"]=r),"5q"===e&&(15.32=t)}18 15},i.4y=17(e){18 22.1c?(15.1p.2F&&15.8f(15.1i+e-15.2J),15.2J=e,15):15.2J},i.2C=17(e){18 22.1c?(15.1N=15.2l=e,15.35(!0),15.1p.2F&&15.1n>0&&15.1n<15.1N&&0!==e&&15.2Z(15.1K*(e/15.1N),!0),15):(15.2o=!1,15.1N)},i.26=17(e){18 15.2o=!1,22.1c?15.2C(e):15.2l},i.3u=17(e,t){18 22.1c?(15.2o&&15.26(),15.2Z(e>15.1N?15.1N:e,t)):15.1n},i.2Z=17(e,t,n){1a(o||s.3a(),!22.1c)18 15.1K;1a(15.1p){1a(0>e&&!n&&(e+=15.26()),15.1p.2F){15.2o&&15.26();19 r=15.2l,i=15.1p;1a(e>r&&!n&&(e=r),15.1i=(15.1A?15.4D:i.1n)-(15.2G?r-e:e)/15.1y,i.2o||15.35(!1),i.1p)1b(;i.1p;)i.1p.1n!==(i.1i+i.1K)/i.1y&&i.2Z(i.1K,!0),i=i.1p}15.1I&&15.1M(!0,!1),(15.1K!==e||0===15.1N)&&15.1B(e,t,!1)}18 15},i.9N=i.9P=17(e,t){18 22.1c?15.2Z(15.2C()*e,t):15.1n/15.2C()},i.8f=17(e){18 22.1c?(e!==15.1i&&(15.1i=e,15.1U&&15.1U.4J&&15.1U.1P(15,e-15.2J)),15):15.1i},i.5N=17(e){1a(!22.1c)18 15.1y;1a(e=e||f,15.1p&&15.1p.2F){19 t=15.4D,n=t||0===t?t:15.1p.2Z();15.1i=n-(n-15.1i)*15.1y/e}18 15.1y=e,15.35(!1)},i.43=17(e){18 22.1c?(e!=15.2G&&(15.2G=e,15.2Z(15.1K,!0)),15):15.2G},i.34=17(e){1a(!22.1c)18 15.1A;1a(e!=15.1A&&15.1p){o||e||s.3a();19 t=15.1p,n=t.3y(),r=n-15.4D;!e&&t.2F&&(15.1i+=r,15.35(!1)),15.4D=e?n:1d,15.1A=e,15.2c=15.4O(),!e&&0!==r&&15.2w&&15.2C()&&15.1B(t.2F?15.1K:(n-15.1i)/15.1y,!0,!0)}18 15.1I&&!e&&15.1M(!0,!1),15};19 A=m("5k.7n",17(e){k.1Z(15,0,e),15.4P=15.2F=!0});i=A.1x=1g k,i.2M=A,i.4c().1I=!1,i.27=i.3h=1d,i.4J=!1,i.1P=i.84=17(e,t){19 n,r;1a(e.1i=1C(t||0)+e.2J,e.1A&&15!==e.1p&&(e.4D=e.1i+(15.3y()-e.1i)/e.1y),e.1U&&e.1U.3C(e,!0),e.1U=e.1p=15,e.1I&&e.1M(!0,!0),n=15.3h,15.4J)1b(r=e.1i;n&&n.1i>r;)n=n.1l;18 n?(e.1f=n.1f,n.1f=e):(e.1f=15.27,15.27=e),e.1f?e.1f.1l=e:15.3h=e,e.1l=n,15.1p&&15.35(!0),15},i.3C=17(e,t){18 e.1U===15&&(t||e.1M(!1,!0),e.1U=1d,e.1l?e.1l.1f=e.1f:15.27===e&&(15.27=e.1f),e.1f?e.1f.1l=e.1l:15.3h===e&&(15.3h=e.1l),15.1p&&15.35(!0)),15},i.1B=17(e,t,n){19 r,i=15.27;1b(15.1K=15.1n=15.1O=e;i;)r=i.1f,(i.2c||e>=i.1i&&!i.1A)&&(i.2G?i.1B((i.2o?i.26():i.2l)-(e-i.1i)*i.1y,t,n):i.1B((e-i.1i)*i.1y,t,n)),i=r},i.3y=17(){18 o||s.3a(),15.1K};19 O=m("5c",17(t,n,r){1a(k.1Z(15,n,r),15.1B=O.1x.1B,1d==t)5W"87 6v a 1d 2v.";15.2v=t="1H"!=1j t?t:O.3w(t)||t;19 i,s,o,u=t.9I||t.1c&&t!==e&&t[0]&&(t[0]===e||t[0].3o&&t[0].1v&&!t.3o),a=15.1o.4L;1a(15.5S=a=1d==a?F[O.8i]:"2t"==1j a?a>>0:F[a],(u||t 2a 3K||t.28&&h(t))&&"2t"!=1j t[0])1b(15.2z=o=l.1Z(t,0),15.3A=[],15.2Y=[],i=0;o.1c>i;i++)s=o[i],s?"1H"!=1j s?s.1c&&s!==e&&s[0]&&(s[0]===e||s[0].3o&&s[0].1v&&!s.3o)?(o.2W(i--,1),15.2z=o=o.3U(l.1Z(s,0))):(15.2Y[i]=R(s,15,!1),1===a&&15.2Y[i].1c>1&&U(s,15,1d,1,15.2Y[i])):(s=o[i--]=O.3w(s),"1H"==1j s&&o.2W(i+1,1)):o.2W(i--,1);1m 15.3A={},15.2Y=R(t,15,!1),1===a&&15.2Y.1c>1&&U(t,15,1d,1,15.2Y);(15.1o.1V||0===n&&0===15.2J&&15.1o.1V!==!1)&&15.1B(-15.2J,!1,!0)},!0),M=17(t){18 t.1c&&t!==e&&t[0]&&(t[0]===e||t[0].3o&&t[0].1v&&!t.3o)},2q=17(e,t){19 n,r={};1b(n 1w e)j[n]||n 1w t&&"x"!==n&&"y"!==n&&"3M"!==n&&"3B"!==n&&"39"!==n&&"3X"!==n||!(!P[n]||P[n]&&P[n].9D)||(r[n]=e[n],3L e[n]);e.4s=r};i=O.1x=1g k,i.2M=O,i.4c().1I=!1,i.3i=0,i.1r=i.2z=i.3f=i.29=1d,i.4I=!1,O.3Z="1.11.2",O.6n=i.2H=1g b(1d,1d,1,1),O.8i="2n",O.8h=s,O.8J=!0,O.3w=e.$||e.9C||17(t){18 e.$?(O.3w=e.$,e.$(t)):e.69?e.69.9G("#"===t.1u(0)?t.1t(1):t):t};19 D=O.4p={7T:h,7U:M},P=O.9R={},H=O.a2={},B=0,j=D.7i={3Q:1,4y:1,4L:1,4i:1,61:1,62:1,5Q:1,4C:1,38:1,5q:1,67:1,6b:1,4B:1,5D:1,63:1,4j:1,7b:1,7o:1,a3:1,a4:1,a6:1,5p:1,a5:1,1V:1,a0:1,9Z:1,1z:1,34:1,43:1,5A:1},F={3r:0,3Y:1,2n:2,9U:3,9T:4,9S:5,"9V":1,"5O":0},I=k.6Y=1g A,q=k.9W=1g A;q.1i=s.3u,I.1i=s.41,q.2c=I.2c=!0,k.86=17(){1a(q.1B((s.3u-q.1i)*q.1y,!1,!1),I.1B((s.41-I.1i)*I.1y,!1,!1),!(s.41%9Y)){19 e,t,n;1b(n 1w H){1b(t=H[n].3x,e=t.1c;--e>-1;)t[e].1I&&t.2W(e,1);0===t.1c&&3L H[n]}1a(n=q.27,(!n||n.1A)&&O.8J&&!I.27&&1===s.40.5y.1c){1b(;n&&n.1A;)n=n.1f;n||s.4X()}}},s.8M("5y",k.86);19 R=17(e,t,n){19 r,i,s=e.7h;1a(H[s||(e.7h=s="t"+B++)]||(H[s]={2v:e,3x:[]}),t&&(r=H[s].3x,r[i=r.1c]=t,n))1b(;--i>-1;)r[i]===t&&r.2W(i,1);18 H[s].3x},U=17(e,t,n,r,i){19 s,o,u,a;1a(1===r||r>=4){1b(a=i.1c,s=0;a>s;s++)1a((u=i[s])!==t)u.1I||u.1M(!1,!1)&&(o=!0);1m 1a(5===r)7p;18 o}19 l,c=t.1i+f,h=[],p=0,d=0===t.1N;1b(s=i.1c;--s>-1;)(u=i[s])===t||u.1I||u.1A||(u.1p!==t.1p?(l=l||z(t,0,d),0===z(u,l,d)&&(h[p++]=u)):c>=u.1i&&u.1i+u.26()/u.1y+f>c&&((d||!u.2w)&&2e-10>=c-u.1i||(h[p++]=u)));1b(s=p;--s>-1;)u=h[s],2===r&&u.2p(n,e)&&(o=!0),(2!==r||!u.1r&&u.2w)&&u.1M(!1,!1)&&(o=!0);18 o},z=17(e,t,n){1b(19 r=e.1p,i=r.1y,s=e.1i;r.1p;){1a(s+=r.1i,i*=r.1y,r.1A)18-23;r=r.1p}18 s/=i,s>t?s-t:n&&s===t||!e.2w&&2*f>s-t?f:(s+=e.26()/e.1y/i)>t+f?0:s-t-f};i.7c=17(){19 e,t,n,r,i=15.1o,s=15.3f,o=15.1N,u=i.1V,a=i.3Q;1a(i.38){1a(15.29&&15.29.1B(-1,!0),i.38.4L=0,i.38.1V=!0,15.29=O.3v(15.2v,0,i.38),u)1a(15.1n>0)15.29=1d;1m 1a(0!==o)18}1m 1a(i.4C&&0!==o)1a(15.29)15.29.1B(-1,!0),15.29=1d;1m{n={};1b(r 1w i)j[r]&&"5A"!==r||(n[r]=i[r]);1a(n.4L=0,n.1z="7G",15.29=O.3v(15.2v,0,n),i.1V){1a(0===15.1n)18}1m 15.29.1B(-1,!0)}1a(15.2H=a?a 2a b?i.5p 2a 3K?a.3t.36(a,i.5p):a:"17"==1j a?1g b(a,i.5p):w[a]||O.6n:O.6n,15.5P=15.2H.6j,15.7f=15.2H.6g,15.1r=1d,15.2z)1b(e=15.2z.1c;--e>-1;)15.4o(15.2z[e],15.3A[e]={},15.2Y[e],s?s[e]:1d)&&(t=!0);1m t=15.4o(15.2v,15.3A,15.2Y,s);1a(t&&O.4U("4Z",15),s&&(15.1r||"17"!=1j 15.2v&&15.1M(!1,!1)),i.4C)1b(n=15.1r;n;)n.s+=n.c,n.c=-n.c,n=n.1f;15.32=i.5q,15.2w=!0},i.4o=17(t,n,r,i){19 s,o,u,a,f,l;1a(1d==t)18!1;15.1o.4s||t.1v&&t!==e&&t.3o&&P.4s&&15.1o.5A!==!1&&2q(15.1o,t);1b(s 1w 15.1o){1a(l=15.1o[s],j[s])l&&(l 2a 3K||l.28&&h(l))&&-1!==l.1G("").1k("{4t}")&&(15.1o[s]=l=15.5o(l,15));1m 1a(P[s]&&(a=1g P[s]).6M(t,15.1o[s],15)){1b(15.1r=f={1f:15.1r,t:a,p:"1X",s:0,c:1,f:!0,n:s,4M:!0,2s:a.5T},o=a.2E.1c;--o>-1;)n[a.2E[o]]=15.1r;(a.5T||a.4Z)&&(u=!0),(a.6q||a.89)&&(15.4I=!0)}1m 15.1r=n[s]=f={1f:15.1r,t:t,p:s,f:"17"==1j t[s],n:s,4M:!1,2s:0},f.s=f.f?t[s.1k("4h")||"17"!=1j t["7g"+s.1t(3)]?s:"7g"+s.1t(3)]():1q(t[s]),f.c="1H"==1j l&&"="===l.1u(1)?3q(l.1u(0)+"1",10)*1C(l.1t(2)):1C(l)-f.s||0;f&&f.1f&&(f.1f.1l=f)}18 i&&15.2p(i,t)?15.4o(t,n,r,i):15.5S>1&&15.1r&&r.1c>1&&U(t,15,n,15.5S,r)?(15.2p(n,t),15.4o(t,n,r,i)):u},i.1B=17(e,t,n){19 r,i,s,o,u=15.1n,a=15.1N;1a(e>=a)15.1K=15.1n=a,15.3i=15.2H.3m?15.2H.2x(1):1,15.2G||(r=!0,i="4i"),0===a&&(o=15.1O,(0===e||0>o||o===f)&&o!==e&&(n=!0,o>f&&(i="4j")),15.1O=o=!t||e?e:f);1m 1a(1e-7>e)15.1K=15.1n=0,15.3i=15.2H.3m?15.2H.2x(0):0,(0!==u||0===a&&15.1O>f)&&(i="4j",r=15.2G),0>e?(15.2c=!1,0===a&&(15.1O>=0&&(n=!0),15.1O=o=!t||e?e:f)):15.2w||(n=!0);1m 1a(15.1K=15.1n=e,15.5P){19 l=e/a,c=15.5P,h=15.7f;(1===c||3===c&&l>=.5)&&(l=1-l),3===c&&(l*=2),1===h?l*=l:2===h?l*=l*l:3===h?l*=l*l*l:4===h&&(l*=l*l*l*l),15.3i=1===c?1-l:2===c?l:.5>e/a?l/2:1-l/2}1m 15.3i=15.2H.2x(e/a);1a(15.1n!==u||n){1a(!15.2w){1a(15.7c(),!15.2w||15.1I)18;15.1n&&!r?15.3i=15.2H.2x(15.1n/a):r&&15.2H.3m&&(15.3i=15.2H.2x(0===15.1n?0:1))}1b(15.2c||!15.1A&&15.1n!==u&&e>=0&&(15.2c=!0),0===u&&(15.29&&(e>=0?15.29.1B(e,t,n):i||(i="a1")),15.1o.4B&&(0!==15.1n||0===a)&&(t||15.1o.4B.36(15.1o.63||15,15.1o.5D||y))),s=15.1r;s;)s.f?s.t[s.p](s.c*15.3i+s.s):s.t[s.p]=s.c*15.3i+s.s,s=s.1f;15.32&&(0>e&&15.29&&15.1i&&15.29.1B(e,t,n),t||n&&0===15.1n&&0===u||15.32.36(15.1o.6b||15,15.1o.67||y)),i&&(15.1I||(0>e&&15.29&&!15.32&&15.1i&&15.29.1B(e,t,n),r&&(15.1p.4P&&15.1M(!1,!1),15.2c=!1),!t&&15.1o[i]&&15.1o[i].36(15.1o[i+"6l"]||15,15.1o[i+"6o"]||y),0===a&&15.1O===f&&o!==f&&(15.1O=0)))}},i.2p=17(e,t){1a("3Y"===e&&(e=1d),1d==e&&(1d==t||t===15.2v))18 15.1M(!1,!1);t="1H"!=1j t?t||15.2z||15.2v:O.3w(t)||t;19 n,r,i,s,o,u,a,f;1a((h(t)||M(t))&&"2t"!=1j t[0])1b(n=t.1c;--n>-1;)15.2p(e,t[n])&&(u=!0);1m{1a(15.2z){1b(n=15.2z.1c;--n>-1;)1a(t===15.2z[n]){o=15.3A[n]||{},15.3f=15.3f||[],r=15.3f[n]=e?15.3f[n]||{}:"3Y";7p}}1m{1a(t!==15.2v)18!1;o=15.3A,r=15.3f=e?15.3f||{}:"3Y"}1a(o){a=e||o,f=e!==r&&"3Y"!==r&&e!==o&&("3T"!=1j e||!e.9Q);1b(i 1w a)(s=o[i])&&(s.4M&&s.t.2p(a)&&(u=!0),s.4M&&0!==s.t.2E.1c||(s.1l?s.1l.1f=s.1f:s===15.1r&&(15.1r=s.1f),s.1f&&(s.1f.1l=s.1l),s.1f=s.1l=1d),3L o[i]),f&&(r[i]=1);!15.1r&&15.2w&&15.1M(!1,!1)}}18 u},i.5i=17(){18 15.4I&&O.4U("6q",15),15.1r=1d,15.3f=1d,15.32=1d,15.29=1d,15.2w=15.2c=15.4I=!1,15.3A=15.2z?{}:[],15},i.1M=17(e,t){1a(o||s.3a(),e&&15.1I){19 n,r=15.2z;1a(r)1b(n=r.1c;--n>-1;)15.2Y[n]=R(r[n],15,!0);1m 15.2Y=R(15.2v,15,!0)}18 k.1x.1M.1Z(15,e,t),15.4I&&15.1r?O.4U(e?"89":"6q",15):!1},O.3v=17(e,t,n){18 1g O(e,t,n)},O.68=17(e,t,n){18 n.4C=!0,n.1V=0!=n.1V,1g O(e,t,n)},O.66=17(e,t,n,r){18 r.38=n,r.1V=0!=r.1V&&0!=n.1V,1g O(e,t,r)},O.6k=17(e,t,n,r,i){18 1g O(t,0,{4y:e,4i:t,61:n,62:r,4j:t,7b:n,7o:r,1V:!1,5Q:i,4L:0})},O.4h=17(e,t){18 1g O(e,0,t)},O.3W=17(e,t){1a(1d==e)18[];e="1H"!=1j e?e:O.3w(e)||e;19 n,r,i,s;1a((h(e)||M(e))&&"2t"!=1j e[0]){1b(n=e.1c,r=[];--n>-1;)r=r.3U(O.3W(e[n],t));1b(n=r.1c;--n>-1;)1b(s=r[n],i=n;--i>-1;)s===r[i]&&r.2W(n,1)}1m 1b(r=R(e).3U(),n=r.1c;--n>-1;)(r[n].1I||t&&!r[n].4O())&&r.2W(n,1);18 r},O.9J=O.9O=17(e,t,n){"3T"==1j t&&(n=t,t=!1);1b(19 r=O.3W(e,t),i=r.1c;--i>-1;)r[i].2p(n,e)};19 W=m("4z.7Q",17(e,t){15.2E=(e||"").1s(","),15.4N=15.2E[0],15.5T=t||0,15.9M=W.1x},!0);1a(i=W.1x,W.3Z="1.10.1",W.3J=2,i.1r=1d,i.9K=17(e,t,n,r,i,s){19 o,u;18 1d!=r&&(o="2t"==1j r||"="!==r.1u(1)?1C(r)-n:3q(r.1u(0)+"1",10)*1C(r.1t(2)))?(15.1r=u={1f:15.1r,t:e,p:t,s:n,c:o,f:"17"==1j e[t],n:i||t,r:s},u.1f&&(u.1f.1l=u),u):2u 0},i.1X=17(e){1b(19 t,n=15.1r,r=1e-6;n;)t=n.c*e+n.s,n.r?t=0|t+(t>0?.5:-.5):r>t&&t>-r&&(t=0),n.f?n.t[n.p](t):n.t[n.p]=t,n=n.1f},i.2p=17(e){19 t,n=15.2E,r=15.1r;1a(1d!=e[15.4N])15.2E=[];1m 1b(t=n.1c;--t>-1;)1d!=e[n[t]]&&n.2W(t,1);1b(;r;)1d!=e[r.n]&&(r.1f&&(r.1f.1l=r.1l),r.1l?(r.1l.1f=r.1f,r.1l=1d):15.1r===r&&(15.1r=r.1f)),r=r.1f;18!1},i.71=17(e,t){1b(19 n=15.1r;n;)(e[15.4N]||1d!=n.n&&e[n.n.1s(15.4N+"2q").1G("")])&&(n.r=t),n=n.1f},O.4U=17(e,t){19 n,r,i,s,o,u=t.1r;1a("4Z"===e){1b(;u;){1b(o=u.1f,r=i;r&&r.2s>u.2s;)r=r.1f;(u.1l=r?r.1l:s)?u.1l.1f=u:i=u,(u.1f=r)?r.1l=u:s=u,u=o}u=t.1r=i}1b(;u;)u.4M&&"17"==1j u.t[e]&&u.t[e]()&&(n=!0),u=u.1f;18 n},W.6P=17(e){1b(19 t=e.1c;--t>-1;)e[t].3J===W.3J&&(P[(1g e[t]).4N]=e[t]);18!0},v.2A=17(e){1a(!(e&&e.7a&&e.78&&e.3J))5W"9L 2A a7.";19 t,n=e.7a,r=e.5H||0,i=e.av,s={78:"6M",4h:"1X",4c:"2p",59:"71",au:"4Z"},o=m("4z."+n.1u(0).5h()+n.1t(1)+"8j",17(){W.1Z(15,n,r),15.2E=i||[]},e.aq===!0),u=o.1x=1g W(n);u.2M=o,o.3J=e.3J;1b(t 1w s)"17"==1j e[t]&&(u[s[t]]=e[t]);18 o.3Z=e.3Z,W.6P([o]),o},n=e.3b){1b(r=0;n.1c>r;r++)n[r]();1b(i 1w p)p[i].76||e.65.6U("ax ay aD aE: 4F.4A."+i)}o=!1}})(1T);(1T.3b||(1T.3b=[])).28(17(){"5v 5u";1T.3R("aC",["5k.72","5k.7n","5c"],17(e,t,n){19 r=17(e){t.1Z(15,e),15.2L={},15.4P=15.1o.4P===!0,15.2F=15.1o.2F===!0,15.4J=!0,15.32=15.1o.5q;19 n,r,i=15.1o;1b(r 1w i)n=i[r],o(n)&&-1!==n.1G("").1k("{4t}")&&(i[r]=15.5o(n));o(i.3x)&&15.1P(i.3x,0,i.aA,i.ap)},i=1e-10,s=n.4p.7U,o=n.4p.7T,u=[],a=17(e){19 t,n={};1b(t 1w e)n[t]=e[t];18 n},f=17(e,t,n,r){e.1p.6c(e.1i),t&&t.36(r||e.1p,n||u)},l=u.6G,c=r.1x=1g t;18 r.3Z="1.11.0",c.2M=r,c.4c().1I=!1,c.3v=17(e,t,r,i){18 t?15.1P(1g n(e,t,r),i):15.4h(e,r,i)},c.68=17(e,t,r,i){18 15.1P(n.68(e,t,r),i)},c.66=17(e,t,r,i,s){18 t?15.1P(n.66(e,t,r,i),s):15.4h(e,i,s)},c.5I=17(e,t,i,o,u,f,c,p){19 d,v=1g r({4i:f,61:c,62:p});1b("1H"==1j e&&(e=n.3w(e)||e),s(e)&&(e=l.1Z(e,0)),o=o||0,d=0;e.1c>d;d++)i.38&&(i.38=a(i.38)),v.3v(e[d],t,a(i),d*o);18 15.1P(v,u)},c.ac=17(e,t,n,r,i,s,o,u){18 n.1V=0!=n.1V,n.4C=!0,15.5I(e,t,n,r,i,s,o,u)},c.a9=17(e,t,n,r,i,s,o,u,a){18 r.38=n,r.1V=0!=r.1V&&0!=n.1V,15.5I(e,t,r,i,s,o,u,a)},c.1Z=17(e,t,r,i){18 15.1P(n.6k(0,e,t,r),i)},c.4h=17(e,t,r){18 r=15.3d(r,0,!0),1d==t.1V&&(t.1V=r===15.1n&&!15.1A),15.1P(1g n(e,0,t),r)},r.ab=17(e,t){e=e||{},1d==e.2F&&(e.2F=!0);19 i,s,o=1g r(e),u=o.1p;1b(1d==t&&(t=!0),u.3C(o,!0),o.1i=0,o.1O=o.1n=o.1K=u.1n,i=u.27;i;)s=i.1f,t&&i 2a n&&i.2v===i.1o.4i||o.1P(i,i.1i-i.2J),i=s;18 u.1P(o,0),o},c.1P=17(i,s,u,a){19 f,l,c,h,p,d;1a("2t"!=1j s&&(s=15.3d(s,0,!0,i)),!(i 2a e)){1a(i 2a 3K||i&&i.28&&o(i)){1b(u=u||"ag",a=a||0,f=s,l=i.1c,c=0;l>c;c++)o(h=i[c])&&(h=1g r({3x:h})),15.1P(h,f),"1H"!=1j h&&"17"!=1j h&&("9A"===u?f=h.1i+h.26()/h.1y:"ah"===u&&(h.1i-=h.4y())),f+=a;18 15.35(!0)}1a("1H"==1j i)18 15.80(i,s);1a("17"!=1j i)5W"87 1P "+i+" am an 1U; 3z al 8a a 6v, 1U, 17, ak 1H.";i=n.6k(0,i)}1a(t.1x.1P.1Z(15,i,s),15.1I&&!15.1A&&15.1N<15.2C())1b(p=15,d=p.3y()>i.1i;p.1I&&p.1p;)p.1p.2F&&d?p.2Z(p.1K,!0):p.1M(!0,!1),p=p.1p;18 15},c.51=17(t){1a(t 2a e)18 15.3C(t,!1);1a(t 2a 3K||t&&t.28&&o(t)){1b(19 n=t.1c;--n>-1;)15.51(t[n]);18 15}18"1H"==1j t?15.7P(t):15.4c(1d,t)},c.3C=17(e,n){t.1x.3C.1Z(15,e,n);19 r=15.3h;18 r?15.1n>r.1i+r.2l/r.1y&&(15.1n=15.2C(),15.1K=15.2l):15.1n=15.1K=0,15},c.aF=17(e,t){18 15.1P(e,15.3d(1d,t,!0,e))},c.84=c.8R=17(e,t,n,r){18 15.1P(e,t||0,n,r)},c.8T=17(e,t,n,r){18 15.1P(e,15.3d(1d,t,!0,e),n,r)},c.80=17(e,t){18 15.2L[e]=15.3d(t),15},c.94=17(e,t,n,r){18 15.1Z(f,["{4t}",t,n,r],15,e)},c.7P=17(e){18 3L 15.2L[e],15},c.8X=17(e){18 1d!=15.2L[e]?15.2L[e]:-1},c.3d=17(t,n,r,i){19 s;1a(i 2a e&&i.1U===15)15.51(i);1m 1a(i&&(i 2a 3K||i.28&&o(i)))1b(s=i.1c;--s>-1;)i[s]2a e&&i[s].1U===15&&15.51(i[s]);1a("1H"==1j n)18 15.3d(n,r&&"2t"==1j t&&1d==15.2L[n]?t-15.2C():0,r);1a(n=n||0,"1H"!=1j t||!5X(t)&&1d==15.2L[t])1d==t&&(t=15.2C());1m{1a(s=t.1k("="),-1===s)18 1d==15.2L[t]?r?15.2L[t]=15.2C()+n:n:15.2L[t]+n;n=3q(t.1u(s-1)+"1",10)*1C(t.1t(s+1)),t=s>1?15.3d(t.1t(0,s-1),0,r):15.2C()}18 1C(t)+n},c.4e=17(e,t){18 15.2Z("2t"==1j e?e:15.3d(e),t!==!1)},c.8V=17(){18 15.34(!0)},c.9r=17(e,t){18 15.7w(e,t)},c.9q=17(e,t){18 15.6c(e,t)},c.1B=17(e,t,n){15.1I&&15.1M(!0,!1);19 r,s,o,a,f,l=15.2o?15.26():15.2l,c=15.1n,h=15.1i,p=15.1y,d=15.1A;1a(e>=l?(15.1K=15.1n=l,15.2G||15.5U()||(s=!0,a="4i",0===15.1N&&(0===e||0>15.1O||15.1O===i)&&15.1O!==e&&15.27&&(f=!0,15.1O>i&&(a="4j"))),15.1O=15.1N||!t||e?e:i,e=l+1e-6):1e-7>e?(15.1K=15.1n=0,(0!==c||0===15.1N&&(15.1O>i||0>e&&15.1O>=0))&&(a="4j",s=15.2G),0>e?(15.2c=!1,0===15.1N&&15.1O>=0&&15.27&&(f=!0),15.1O=e):(15.1O=15.1N||!t||e?e:i,e=0,15.2w||(f=!0))):15.1K=15.1n=15.1O=e,15.1n!==c&&15.27||n||f){1a(15.2w||(15.2w=!0),15.2c||!15.1A&&15.1n!==c&&e>0&&(15.2c=!0),0===c&&15.1o.4B&&0!==15.1n&&(t||15.1o.4B.36(15.1o.63||15,15.1o.5D||u)),15.1n>=c)1b(r=15.27;r&&(o=r.1f,!15.1A||d);)(r.2c||r.1i<=15.1n&&!r.1A&&!r.1I)&&(r.2G?r.1B((r.2o?r.26():r.2l)-(e-r.1i)*r.1y,t,n):r.1B((e-r.1i)*r.1y,t,n)),r=o;1m 1b(r=15.3h;r&&(o=r.1l,!15.1A||d);)(r.2c||c>=r.1i&&!r.1A&&!r.1I)&&(r.2G?r.1B((r.2o?r.26():r.2l)-(e-r.1i)*r.1y,t,n):r.1B((e-r.1i)*r.1y,t,n)),r=o;15.32&&(t||15.32.36(15.1o.6b||15,15.1o.67||u)),a&&(15.1I||(h===15.1i||p!==15.1y)&&(0===15.1n||l>=15.26())&&(s&&(15.1p.4P&&15.1M(!1,!1),15.2c=!1),!t&&15.1o[a]&&15.1o[a].36(15.1o[a+"6l"]||15,15.1o[a+"6o"]||u)))}},c.5U=17(){1b(19 e=15.27;e;){1a(e.1A||e 2a r&&e.5U())18!0;e=e.1f}18!1},c.5g=17(e,t,r,i){i=i||-4Y;1b(19 s=[],o=15.27,u=0;o;)i>o.1i||(o 2a n?t!==!1&&(s[u++]=o):(r!==!1&&(s[u++]=o),e!==!1&&(s=s.3U(o.5g(!0,t,r)),u=s.1c))),o=o.1f;18 s},c.3W=17(e,t){1b(19 r=n.3W(e),i=r.1c,s=[],o=0;--i>-1;)(r[i].1U===15||t&&15.7A(r[i]))&&(s[o++]=r[i]);18 s},c.7A=17(e){1b(19 t=e.1U;t;){1a(t===15)18!0;t=t.1U}18!1},c.7l=17(e,t,n){n=n||0;1b(19 r,i=15.27,s=15.2L;i;)i.1i>=n&&(i.1i+=e),i=i.1f;1a(t)1b(r 1w s)s[r]>=n&&(s[r]+=e);18 15.35(!0)},c.2p=17(e,t){1a(!e&&!t)18 15.1M(!1,!1);1b(19 n=t?15.3W(t):15.5g(!0,!0,!1),r=n.1c,i=!1;--r>-1;)n[r].2p(e,t)&&(i=!0);18 i},c.9b=17(e){19 t=15.5g(!1,!0,!0),n=t.1c;1b(15.1n=15.1K=0;--n>-1;)t[n].1M(!1,!1);18 e!==!1&&(15.2L={}),15.35(!0)},c.5i=17(){1b(19 e=15.27;e;)e.5i(),e=e.1f;18 15},c.1M=17(e,n){1a(e===15.1I)1b(19 r=15.27;r;)r.1M(e,!0),r=r.1f;18 t.1x.1M.1Z(15,e,n)},c.2C=17(e){18 22.1c?(0!==15.2C()&&0!==e&&15.5N(15.1N/e),15):(15.2o&&15.26(),15.1N)},c.26=17(e){1a(!22.1c){1a(15.2o){1b(19 t,n,r=0,i=15.3h,s=9g;i;)t=i.1l,i.2o&&i.26(),i.1i>s&&15.4J&&!i.1A?15.1P(i,i.1i-i.2J):s=i.1i,0>i.1i&&!i.1A&&(r-=i.1i,15.1p.2F&&(15.1i+=i.1i/15.1y),15.7l(-i.1i,!1,-4Y),s=0),n=i.1i+i.2l/i.1y,n>r&&(r=n),i=t;15.1N=15.2l=r,15.2o=!1}18 15.2l}18 0!==15.26()&&0!==e&&15.5N(15.2l/e),15},c.cW=17(){1b(19 t=15.1p;t.1p;)t=t.1p;18 t===e.6Y},c.3y=17(){18 15.1A?15.1K:(15.1p.3y()-15.1i)*15.1y},r},!0)}),1T.3R&&1T.3b.4G()();(1T.3b||(1T.3b=[])).28(17(){"5v 5u";1T.3R("2j.7F",["2j.7v"],17(e){19 t,n,r,i=1T.6h||1T,s=i.4F.4A,o=2*1h.4l,u=1h.4l/2,a=s.7W,f=17(t,n){19 r=a("2j."+t,17(){},!0),i=r.1x=1g e;18 i.2M=r,i.2x=n,r},l=e.7X||17(){},c=17(e,t,n,r){19 i=a("2j."+e,{5R:1g t,5s:1g n,5r:1g r},!0);18 l(i,e),i},h=17(e,t,n){15.t=e,15.v=t,n&&(15.5t=n,n.5x=15,15.c=n.v-t,15.7x=n.t-e)},p=17(t,n){19 r=a("2j."+t,17(e){15.1R=e||0===e?e:1.c7,15.2k=1.ci*15.1R},!0),i=r.1x=1g e;18 i.2M=r,i.2x=n,i.3t=17(e){18 1g r(e)},r},d=c("7F",p("d3",17(e){18(e-=1)*e*((15.1R+1)*e+15.1R)+1}),p("d6",17(e){18 e*e*((15.1R+1)*e-15.1R)}),p("cU",17(e){18 1>(e*=2)?.5*e*e*((15.2k+1)*e-15.2k):.5*((e-=2)*e*((15.2k+1)*e+15.2k)+2)})),v=a("2j.5Z",17(e,t,n){t=t||0===t?t:.7,1d==e?e=.7:e>1&&(e=1),15.7V=1!==e?t:0,15.1R=(1-e)/2,15.2k=e,15.3c=15.1R+15.2k,15.3m=n===!0},!0),m=v.1x=1g e;18 m.2M=v,m.2x=17(e){19 t=e+(.5-e)*15.7V;18 15.1R>e?15.3m?1-(e=1-e/15.1R)*e:t-(e=1-e/15.1R)*e*e*e*t:e>15.3c?15.3m?1-(e=(e-15.3c)/15.1R)*e:t+(e-t)*(e=(e-15.3c)/15.1R)*e*e*e:15.3m?1:t},v.3Q=1g v(.7,.7),m.3t=v.3t=17(e,t,n){18 1g v(e,t,n)},t=a("2j.7S",17(e){e=e||1,15.1R=1/e,15.2k=e+1},!0),m=t.1x=1g e,m.2M=t,m.2x=17(e){18 0>e?e=0:e>=1&&(e=.cH),(15.2k*e>>0)*15.1R},m.3t=t.3t=17(e){18 1g t(e)},n=a("2j.7Y",17(t){t=t||{};1b(19 n,r,i,s,o,u,a=t.cT||"3r",f=[],l=0,c=0|(t.d4||20),p=c,d=t.d1!==!1,v=t.cX===!0,m=t.7J 2a e?t.7J:1d,g="2t"==1j t.7K?.4*t.7K:.4;--p>-1;)n=d?1h.7L():1/c*p,r=m?m.2x(n):n,"3r"===a?i=g:"cC"===a?(s=1-n,i=s*s*g):"1w"===a?i=n*n*g:.5>n?(s=2*n,i=.5*s*s*g):(s=2*(1-n),i=.5*s*s*g),d?r+=1h.7L()*i-.5*i:p%2?r+=.5*i:r-=.5*i,v&&(r>1?r=1:0>r&&(r=0)),f[l++]={x:n,y:r};1b(f.ch(17(e,t){18 e.x-t.x}),u=1g h(1,1,1d),p=c;--p>-1;)o=f[p],u=1g h(o.x,o.y,u);15.1l=1g h(0,0,0!==u.t?u:u.5t)},!0),m=n.1x=1g e,m.2M=n,m.2x=17(e){19 t=15.1l;1a(e>t.t){1b(;t.5t&&e>=t.t;)t=t.5t;t=t.5x}1m 1b(;t.5x&&t.t>=e;)t=t.5x;18 15.1l=t,t.v+(e-t.t)/t.7x*t.c},m.3t=17(e){18 1g n(e)},n.3Q=1g n,c("cm",f("cA",17(e){18 1/2.75>e?7.2I*e*e:2/2.75>e?7.2I*(e-=1.5/2.75)*e+.75:2.5/2.75>e?7.2I*(e-=2.25/2.75)*e+.6i:7.2I*(e-=2.6d/2.75)*e+.6e}),f("cu",17(e){18 1/2.75>(e=1-e)?1-7.2I*e*e:2/2.75>e?1-(7.2I*(e-=1.5/2.75)*e+.75):2.5/2.75>e?1-(7.2I*(e-=2.25/2.75)*e+.6i):1-(7.2I*(e-=2.6d/2.75)*e+.6e)}),f("co",17(e){19 t=.5>e;18 e=t?1-2*e:2*e-1,e=1/2.75>e?7.2I*e*e:2/2.75>e?7.2I*(e-=1.5/2.75)*e+.75:2.5/2.75>e?7.2I*(e-=2.25/2.75)*e+.6i:7.2I*(e-=2.6d/2.75)*e+.6e,t?.5*(1-e):.5*e+.5})),c("cr",f("cs",17(e){18 1h.3l(1-(e-=1)*e)}),f("cp",17(e){18-(1h.3l(1-e*e)-1)}),f("cn",17(e){18 1>(e*=2)?-.5*(1h.3l(1-e*e)-1):.5*(1h.3l(1-(e-=2)*e)+1)})),r=17(t,n,r){19 i=a("2j."+t,17(e,t){15.1R=e||1,15.2k=t||r,15.3c=15.2k/o*(1h.cv(1/15.1R)||0)},!0),s=i.1x=1g e;18 s.2M=i,s.2x=n,s.3t=17(e,t){18 1g i(e,t)},i},c("cB",r("cz",17(e){18 15.1R*1h.3n(2,-10*e)*1h.2h((e-15.3c)*o/15.2k)+1},.3),r("cy",17(e){18-(15.1R*1h.3n(2,10*(e-=1))*1h.2h((e-15.3c)*o/15.2k))},.3),r("cw",17(e){18 1>(e*=2)?-.5*15.1R*1h.3n(2,10*(e-=1))*1h.2h((e-15.3c)*o/15.2k):.5*15.1R*1h.3n(2,-10*(e-=1))*1h.2h((e-15.3c)*o/15.2k)+1},.45)),c("cc",f("ca",17(e){18 1-1h.3n(2,-10*e)}),f("c8",17(e){18 1h.3n(2,10*(e-1))-.cd}),f("ce",17(e){18 1>(e*=2)?.5*1h.3n(2,10*(e-1)):.5*(2-1h.3n(2,-10*(e-1)))})),c("ck",f("cf",17(e){18 1h.2h(e*u)}),f("cJ",17(e){18-1h.2D(e*u)+1}),f("cZ",17(e){18-.5*(1h.2D(1h.4l*e)-1)})),a("2j.cV",{d0:17(t){18 e.7Z[t]}},!0),l(i.5Z,"5Z","3Q,"),l(n,"7Y","3Q,"),l(t,"7S","3Q,"),d},!0)}),1T.3R&&1T.3b.4G()();(1T.3b||(1T.3b=[])).28(17(){"5v 5u";1T.3R("4z.cE",["4z.7Q","5c"],17(e,t){19 n,r,i,s,o=17(){e.1Z(15,"4s"),15.2E.1c=0,15.1X=o.1x.1X},u={},a=o.1x=1g e("4s");a.2M=o,o.3Z="1.11.2",o.3J=2,o.8g=0,a="2d",o.6z={3k:a,7e:a,4x:a,4u:a,3M:a,3B:a,cP:a,6x:a,6w:a,33:a};19 f,l,c,h,p,d,v=/(?:\\d|\\-\\d|\\.\\d|\\-\\.\\d)+/g,m=/(?:\\d|\\-\\d|\\.\\d|\\-\\.\\d|\\+=\\d|\\-=\\d|\\+=.\\d|\\-=\\.\\d)+/g,g=/(?:\\+=|\\-=|\\-|\\b)[\\d\\-\\.]+[a-cN-cO-9]*(?:%|\\b)/3N,y=/[^\\d\\-\\.]/g,b=/(?:\\d|\\-|\\+|=|#|\\.)*/g,w=/1Y *= *([^)]*)/,E=/1Y:([^;]*)/,S=/3E\\(1Y *=.+?\\)/i,x=/^(5e|6m)/,T=/([A-Z])/g,N=/-([a-z])/3N,C=/(^(?:74\\(\\"|74\\())|(?:(\\"\\))$|\\)$)/3N,k=17(e,t){18 t.5h()},L=/(?:5Y|7s|7k)/i,A=/(8z|8O|8N|8L)=[\\d\\-\\.e]+/3N,O=/8x\\:5J\\.5L\\.5M\\(.+?\\)/i,M=/,(?=[^\\)]*(?:\\(|$))/3N,2q=1h.4l/31,D=31/1h.4l,P={},H=69,B=H.6a("77"),j=H.6a("ba"),F=o.4p={bb:u},I=b8.b7,q=17(){19 e,t=I.1k("b3"),n=H.6a("77");18 c=-1!==I.1k("b5")&&-1===I.1k("b6")&&(-1===t||1C(I.1t(t+8,1))>3),p=c&&6>1C(I.1t(I.1k("bc/")+8,1)),h=-1!==I.1k("bd"),/bk ([0-9]{1,}[\\.0-9]{0,})/.bl(I)&&(d=1q(4k.$1)),n.bm="<a 1v=\'3k:bj;1Y:.55;\'>a</a>",e=n.bi("a")[0],e?/^0.55/.2P(e.1v.1Y):!1}(),R=17(e){18 w.2P("1H"==1j e?e:(e.2R?e.2R.2i:e.1v.2i)||"")?1q(4k.$1)/23:1},U=17(e){1T.65&&65.6U(e)},z="",W="",X=17(e,t){t=t||B;19 n,r,i=t.1v;1a(2u 0!==i[e])18 e;1b(e=e.1u(0).5h()+e.1t(1),n=["O","be","64","bf","bg"],r=5;--r>-1&&2u 0===i[n[r]+e];);18 r>=0?(W=3===r?"64":n[r],z="-"+W.6R()+"-",W+e):1d},V=H.6Z?H.6Z.bh:17(){},$=o.c6=17(e,t,n,r,i){19 s;18 q||"1Y"!==t?(!r&&e.1v[t]?s=e.1v[t]:(n=n||V(e,1d))?(e=n.4m(t.1D(T,"-$1").6R()),s=e||n.1c?e:n[t]):e.2R&&(s=e.2R[t]),1d==i||s&&"3r"!==s&&"2n"!==s&&"2n 2n"!==s?s:i):R(e)},J=17(e,t,n,r,i){1a("2d"===r||!r)18 n;1a("2n"===r||!n)18 0;19 s,o=L.2P(t),u=e,a=B.1v,f=0>n;18 f&&(n=-n),"%"===r&&-1!==t.1k("3X")?s=n/23*(o?e.b2:e.b1):(a.37="3X:0 4S 8P;4q:"+$(e,"4q")+";aN-3B:0;","%"!==r&&u.7m?a[o?"aO":"70"]=n+r:(u=e.aP||H.aM,a[o?"3M":"3B"]=n+r),u.7m(B),s=1q(B[o?"4H":"4r"]),u.aL(B),0!==s||i||(s=J(e,t,n,r,!0))),f?-s:s},K=17(e,t,n){1a("8y"!==$(e,"4q",n))18 0;19 r="4u"===t?"5Y":"7r",i=$(e,"6w"+r,n);18 e["aH"+r]-(J(e,t,1q(i),i.1D(b,""))||0)},Q=17(e,t){19 n,r,i={};1a(t=t||V(e,1d))1a(n=t.1c)1b(;--n>-1;)i[t[n].1D(N,k)]=t.4m(t[n]);1m 1b(n 1w t)i[n]=t[n];1m 1a(t=e.2R||e.1v)1b(n 1w t)"1H"==1j n&&2u 0!==i[n]&&(i[n.1D(N,k)]=t[n]);18 q||(i.1Y=R(e)),r=44(e,t,!1),i.1F=r.1F,i.1S=r.1S,i.2f=r.2f,i.2g=r.2g,i.x=r.x,i.y=r.y,3j&&(i.z=r.z,i.1Q=r.1Q,i.21=r.21,i.2N=r.2N),i.7q&&3L i.7q,i},G=17(e,t,n,r,i){19 s,o,u,a={},f=e.1v;1b(o 1w n)"37"!==o&&"1c"!==o&&5X(o)&&(t[o]!==(s=n[o])||i&&i[o])&&-1===o.1k("aI")&&("2t"==1j s||"1H"==1j s)&&(a[o]="2n"!==s||"4u"!==o&&"3k"!==o?""!==s&&"2n"!==s&&"3r"!==s||"1H"!=1j t[o]||""===t[o].1D(y,"")?s:0:K(e,o),2u 0!==f[o]&&(u=1g ct(f,o,f[o],u)));1a(r)1b(o 1w r)"39"!==o&&(a[o]=r[o]);18{4T:a,42:u}},Y={3M:["5Y","7s"],3B:["7r","aK"]},Z=["7C","81","83","82"],3D=17(e,t,n){19 r=1q("3M"===t?e.4H:e.4r),i=Y[t],s=i.1c;1b(n=n||V(e,1d);--s>-1;)r-=1q($(e,"6x"+i[s],n,!0))||0,r-=1q($(e,"3X"+i[s]+"7k",n,!0))||0;18 r},3e=17(e,t){(1d==e||""===e||"2n"===e||"2n 2n"===e)&&(e="0 0");19 n=e.1s(" "),r=-1!==e.1k("4u")?"0%":-1!==e.1k("7e")?"23%":n[0],i=-1!==e.1k("3k")?"0%":-1!==e.1k("4x")?"23%":n[1];18 1d==i?i="0":"7d"===i&&(i="50%"),("7d"===r||5X(1q(r))&&-1===(r+"").1k("="))&&(r="50%"),t&&(t.8K=-1!==r.1k("%"),t.8H=-1!==i.1k("%"),t.aQ="="===r.1u(1),t.aR="="===i.1u(1),t.57=1q(r.1D(y,"")),t.5K=1q(i.1D(y,""))),r+" "+i+(n.1c>2?" "+n[2]:"")},3s=17(e,t){18"1H"==1j e&&"="===e.1u(1)?3q(e.1u(0)+"1",10)*1q(e.1t(2)):1q(e)-1q(t)},2B=17(e,t){18 1d==e?t:"1H"==1j e&&"="===e.1u(1)?3q(e.1u(0)+"1",10)*1C(e.1t(2))+t:1q(e)},3z=17(e,t,n,r){19 i,s,o,u,a=1e-6;18 1d==e?u=t:"2t"==1j e?u=e:(i=6r,s=e.1s("2q"),o=1C(s[0].1D(y,""))*(-1===e.1k("aY")?1:D)-("="===e.1u(1)?0:t),s.1c&&(r&&(r[n]=t+o),-1!==e.1k("aZ")&&(o%=i,o!==o%(i/2)&&(o=0>o?o+i:o-i)),-1!==e.1k("b0")&&0>o?o=(o+4Y*i)%i-(0|o/i)*i:-1!==e.1k("aX")&&o>0&&(o=(o-4Y*i)%i-(0|o/i)*i)),u=t+o),a>u&&u>-a&&(u=0),u},3G={aS:[0,1E,1E],aT:[0,1E,0],aU:[5j,5j,5j],8k:[0,0,0],aV:[2O,0,0],bn:[0,2O,2O],bo:[0,0,1E],bS:[0,0,2O],bT:[1E,1E,1E],bU:[1E,0,1E],bR:[2O,2O,0],bQ:[1E,1E,0],bM:[1E,bN,0],bO:[2O,2O,2O],bP:[2O,0,2O],bV:[0,2O,0],8P:[1E,0,0],c2:[1E,5j,c4],c1:[0,1E,1E],4a:[1E,1E,1E,0]},4W=17(e,t,n){18 e=0>e?e+1:e>1?e-1:e,0|1E*(1>6*e?t+6*(n-t)*e:.5>e?n:2>3*e?t+6*(n-t)*(2/3-e):t)+.5},5d=17(e){19 t,n,r,i,s,o;18 e&&""!==e?"2t"==1j e?[e>>16,1E&e>>8,1E&e]:(","===e.1u(e.1c-1)&&(e=e.1t(0,e.1c-1)),3G[e]?3G[e]:"#"===e.1u(0)?(4===e.1c&&(t=e.1u(1),n=e.1u(2),r=e.1u(3),e="#"+t+t+n+n+r+r),e=3q(e.1t(1),16),[e>>16,1E&e>>8,1E&e]):"6m"===e.1t(0,3)?(e=e.2K(v),i=1C(e[0])%6r/6r,s=1C(e[1])/23,o=1C(e[2])/23,n=.5>=o?o*(s+1):o+s-o*s,t=2*o-n,e.1c>3&&(e[3]=1C(e[3])),e[0]=4W(i+1/3,t,n),e[1]=4W(i,t,n),e[2]=4W(i-1/3,t,n),e):(e=e.2K(v)||3G.4a,e[0]=1C(e[0]),e[1]=1C(e[1]),e[2]=1C(e[2]),e.1c>3&&(e[3]=1C(e[3])),e)):3G.8k},at="(?:\\\\b(?:(?:5e|6N|6m|bZ)\\\\(.+?\\\\))|\\\\B#.+?\\\\b";1b(a 1w 3G)at+="|"+a+"\\\\b";at=4k(at+")","3N");19 6I=17(e,t,n,r){1a(1d==e)18 17(e){18 e};19 i,s=t?(e.2K(at)||[""])[0]:"",o=e.1s(s).1G("").2K(g)||[],u=e.1t(0,e.1k(o[0])),a=")"===e.1u(e.1c-1)?")":"",f=-1!==e.1k(" ")?" ":",",l=o.1c,c=l>0?o[0].1D(v,""):"";18 l?i=t?17(e){19 t,h,p,d;1a("2t"==1j e)e+=c;1m 1a(r&&M.2P(e)){1b(d=e.1D(M,"|").1s("|"),p=0;d.1c>p;p++)d[p]=i(d[p]);18 d.1G(",")}1a(t=(e.2K(at)||[s])[0],h=e.1s(t).1G("").2K(g)||[],p=h.1c,l>p--)1b(;l>++p;)h[p]=n?h[0|(p-1)/2]:o[p];18 u+h.1G(f)+f+t+a+(-1!==e.1k("6D")?" 6D":"")}:17(e){19 t,s,h;1a("2t"==1j e)e+=c;1m 1a(r&&M.2P(e)){1b(s=e.1D(M,"|").1s("|"),h=0;s.1c>h;h++)s[h]=i(s[h]);18 s.1G(",")}1a(t=e.2K(g)||[],h=t.1c,l>h--)1b(;l>++h;)t[h]=n?t[0|(h-1)/2]:o[h];18 u+t.1G(f)+a}:17(e){18 e}},6A=17(e){18 e=e.1s(","),17(t,n,r,i,s,o,u){19 a,f=(n+"").1s(" ");1b(u={},a=0;4>a;a++)u[e[a]]=f[a]=f[a]||f[(a-1)/2>>0];18 i.2S(t,u,s,o)}},ct=(F.bL=17(e){15.2A.1X(e);1b(19 t,n,r,i,s=15.1z,o=s.8t,u=s.42,a=1e-6;u;)t=o[u.v],u.r?t=t>0?0|t+.5:0|t-.5:a>t&&t>-a&&(t=0),u.t[u.p]=t,u=u.1f;1a(s.8c&&(s.8c.1F=o.1F),1===e)1b(u=s.42;u;){1a(n=u.t,n.2r){1a(1===n.2r){1b(i=n.1W+n.s+n.3V,r=1;n.l>r;r++)i+=n["3g"+r]+n["2X"+(r+1)];n.e=i}}1m n.e=n.s+n.1W;u=u.1f}},17(e,t,n,r,i){15.t=e,15.p=t,15.v=n,15.r=i,r&&(r.1l=15,15.1f=r)}),24=(F.bK=17(e,t,n,r,i,s){19 o,u,a,f,l,c=r,h={},p={},d=n.3p,v=P;1b(n.3p=1d,P=t,r=l=n.2S(e,t,r,i),P=v,s&&(n.3p=d,c&&(c.1l=1d,c.1l&&(c.1l.1f=1d)));r&&r!==c;){1a(1>=r.2r&&(u=r.p,p[u]=r.s+r.c,h[u]=r.s,s||(f=1g ct(r,"s",u,f,r.r),r.c=0),1===r.2r))1b(o=r.l;--o>0;)a="3g"+o,u=r.p+"2q"+a,p[u]=r.1z[a],h[u]=r[a],s||(f=1g ct(r,a,u,f,r.5f[a]));r=r.1f}18{8t:h,bw:p,42:f,4f:l}},F.bx=17(e,t,r,i,o,u,a,f,l,c,h){15.t=e,15.p=t,15.s=r,15.c=i,15.n=a||t,e 2a 24||s.28(15.n),15.r=f,15.2r=u||0,l&&(15.2s=l,n=!0),15.b=2u 0===c?r:c,15.e=2u 0===h?r+i:h,o&&(15.1f=o,o.1l=15)}),4f=o.46=17(e,t,n,r,i,s,o,u,a,l){n=n||s||"",o=1g 24(e,t,0,0,o,l?2:1,1d,!1,u,n,r),r+="";19 c,h,p,d,g,y,b,w,E,S,T,N,C=n.1s(", ").1G(",").1s(" "),k=r.1s(", ").1G(",").1s(" "),L=C.1c,A=f!==!1;1b((-1!==r.1k(",")||-1!==n.1k(","))&&(C=C.1G(" ").1D(M,", ").1s(" "),k=k.1G(" ").1D(M,", ").1s(" "),L=C.1c),L!==k.1c&&(C=(s||"").1s(" "),L=C.1c),o.2A=a,o.1X=l,c=0;L>c;c++)1a(d=C[c],g=k[c],w=1q(d),w||0===w)o.3I("",w,3s(g,w),g.1D(m,""),A&&-1!==g.1k("2d"),!0);1m 1a(i&&("#"===d.1u(0)||3G[d]||x.2P(d)))N=","===g.1u(g.1c-1)?"),":")",d=5d(d),g=5d(g),E=d.1c+g.1c>6,E&&!q&&0===g[3]?(o["2X"+o.l]+=o.l?" 4a":"4a",o.e=o.e.1s(k[c]).1G("4a")):(q||(E=!1),o.3I(E?"6N(":"5e(",d[0],g[0]-d[0],",",!0,!0).3I("",d[1],g[1]-d[1],",",!0).3I("",d[2],g[2]-d[2],E?",":N,!0),E&&(d=4>d.1c?1:d[3],o.3I("",d,(4>g.1c?1:g[3])-d,N,!1)));1m 1a(y=d.2K(v)){1a(b=g.2K(m),!b||b.1c!==y.1c)18 o;1b(p=0,h=0;y.1c>h;h++)T=y[h],S=d.1k(T,p),o.3I(d.1t(p,S-p),1C(T),3s(b[h],T),"",A&&"2d"===d.1t(S+T.1c,2),0===h),p=S+T.1c;o["2X"+o.l]+=d.1t(p)}1m o["2X"+o.l]+=o.l?" "+d:d;1a(-1!==r.1k("=")&&o.1z){1b(N=o.1W+o.1z.s,c=1;o.l>c;c++)N+=o["2X"+c]+o.1z["3g"+c];o.e=N+o["2X"+c]}18 o.l||(o.2r=-1,o.1W=o.e),o.3H||o},2m=9;1b(a=24.1x,a.l=a.2s=0;--2m>0;)a["3g"+2m]=0,a["2X"+2m]="";a.1W="",a.1f=a.1l=a.3H=a.1z=a.2A=a.1X=a.5f=1d,a.3I=17(e,t,n,r,i,s){19 o=15,u=o.l;18 o["2X"+u]+=s&&u?" "+e:e||"",n||0===u||o.2A?(o.l++,o.2r=o.1X?2:1,o["2X"+o.l]=r||"",u>0?(o.1z["3g"+u]=t+n,o.5f["3g"+u]=i,o["3g"+u]=t,o.2A||(o.3H=1g 24(o,"3g"+u,t,n,o.3H||o,0,o.n,i,o.2s),o.3H.1W=0),o):(o.1z={s:t+n},o.5f={},o.s=t,o.c=n,o.r=i,o)):(o["2X"+u]+=t+(r||""),o)};19 5G=17(e,t){t=t||{},15.p=t.2T?X(e)||e:e,u[e]=u[15.p]=15,15.2U=t.4R||6I(t.2y,t.4g,t.by,t.47),t.2b&&(15.2S=t.2b),15.8D=t.4g,15.47=t.47,15.4V=t.4V,15.49=t.2y,15.2s=t.5H||0},1L=F.bv=17(e,t,n){"3T"!=1j t&&(t={2b:n});19 r,i,s=e.1s(","),o=t.2y;1b(n=n||[o],r=0;s.1c>r;r++)t.2T=0===r&&t.2T,t.2y=n[r]||o,i=1g 5G(s[r],t)},7H=17(e){1a(!u[e]){19 t=e.1u(0).5h()+e.1t(1)+"8j";1L(e,{2b:17(e,n,r,i,s,o,a){19 f=(1T.6h||1T).4F.4A.4z[t];18 f?(f.bu(),u[r].2S(e,n,r,i,s,o,a)):(U("bp: "+t+" bq br 8a bs."),s)}})}};a=5G.1x,a.46=17(e,t,n,r,i,s){19 o,u,a,f,l,c,h=15.4V;1a(15.47&&(M.2P(n)||M.2P(t)?(u=t.1D(M,"|").1s("|"),a=n.1D(M,"|").1s("|")):h&&(u=[t],a=[n])),a){1b(f=a.1c>u.1c?a.1c:u.1c,o=0;f>o;o++)t=u[o]=u[o]||15.49,n=a[o]=a[o]||15.49,h&&(l=t.1k(h),c=n.1k(h),l!==c&&(n=-1===c?a:u,n[o]+=" "+h));t=u.1G(", "),n=a.1G(", ")}18 4f(e,15.p,t,n,15.8D,15.49,r,15.2s,i,s)},a.2S=17(e,t,n,r,s,o){18 15.46(e.1v,15.2U($(e,15.p,i,!1,15.49)),15.2U(t),s,o)},o.bA=17(e,t,n){1L(e,{2b:17(e,r,i,s,o,u){19 a=1g 24(e,i,0,0,o,2,i,!1,n);18 a.2A=u,a.1X=t(e,r,s.2V,i),a},5H:n})};19 6K="2f,2g,2N,x,y,z,1S,1F,1Q,21,33".1s(","),bt=X("3P"),8B=z+"3P",5m=X("4Q"),3j=1d!==X("33"),44=17(e,t,n,r){1a(e.4b&&n&&!r)18 e.4b;19 i,s,u,a,f,l,c,h,p,d,v,m,g,y=n?e.4b||{30:0}:{30:0},b=0>y.2f,w=2e-5,E=54,S=bH.99,x=S*2q,T=3j?1q($(e,5m,t,!1,"0 0 0").1s(" ")[2])||y.2Q||0:0;1b(bt?i=$(e,8B,t,!0):e.2R&&(i=e.2R.2i.2K(A),i=i&&4===i.1c?[i[0].1t(4),1C(i[2].1t(4)),1C(i[1].1t(4)),i[3].1t(4),y.x||0,y.y||0].1G(","):""),s=(i||"").2K(/(?:\\-|\\b)[\\d\\-\\.e]+\\b/3N)||[],u=s.1c;--u>-1;)a=1C(s[u]),s[u]=(f=a-(a|=0))?(0|f*E+(0>f?-.5:.5))/E+a:a;1a(16===s.1c){19 N=s[8],C=s[9],k=s[10],L=s[12],O=s[13],M=s[14];1a(y.2Q&&(M=-y.2Q,L=N*M-s[12],O=C*M-s[13],M=k*M+y.2Q-s[14]),!n||r||1d==y.1Q){19 P,H,B,j,F,I,q,R=s[0],U=s[1],z=s[2],W=s[3],X=s[4],V=s[5],J=s[6],K=s[7],Q=s[11],G=1h.4w(J,k),Y=-x>G||G>x;y.1Q=G*D,G&&(j=1h.2D(-G),F=1h.2h(-G),P=X*j+N*F,H=V*j+C*F,B=J*j+k*F,N=X*-F+N*j,C=V*-F+C*j,k=J*-F+k*j,Q=K*-F+Q*j,X=P,V=H,J=B),G=1h.4w(N,R),y.21=G*D,G&&(I=-x>G||G>x,j=1h.2D(-G),F=1h.2h(-G),P=R*j-N*F,H=U*j-C*F,B=z*j-k*F,C=U*F+C*j,k=z*F+k*j,Q=W*F+Q*j,R=P,U=H,z=B),G=1h.4w(U,V),y.1F=G*D,G&&(q=-x>G||G>x,j=1h.2D(-G),F=1h.2h(-G),R=R*j+X*F,H=U*j+V*F,V=U*-F+V*j,J=z*-F+J*j,U=H),q&&Y?y.1F=y.1Q=0:q&&I?y.1F=y.21=0:I&&Y&&(y.21=y.1Q=0),y.2f=(0|1h.3l(R*R+U*U)*E+.5)/E,y.2g=(0|1h.3l(V*V+C*C)*E+.5)/E,y.2N=(0|1h.3l(J*J+k*k)*E+.5)/E,y.1S=0,y.33=Q?1/(0>Q?-Q:Q):0,y.x=L,y.y=O,y.z=M}}1m 1a(!(3j&&!r&&s.1c&&y.x===s[4]&&y.y===s[5]&&(y.1Q||y.21)||2u 0!==y.x&&"3r"===$(e,"6s",t))){19 Z=s.1c>=6,3D=Z?s[0]:1,3e=s[1]||0,3s=s[2]||0,2B=Z?s[3]:1;y.x=s[4]||0,y.y=s[5]||0,l=1h.3l(3D*3D+3e*3e),c=1h.3l(2B*2B+3s*3s),h=3D||3e?1h.4w(3e,3D)*D:y.1F||0,p=3s||2B?1h.4w(3s,2B)*D+h:y.1S||0,d=l-1h.56(y.2f||0),v=c-1h.56(y.2g||0),1h.56(p)>90&&bJ>1h.56(p)&&(b?(l*=-1,p+=0>=h?31:-31,h+=0>=h?31:-31):(c*=-1,p+=0>=p?31:-31)),m=(h-y.1F)%31,g=(p-y.1S)%31,(2u 0===y.1S||d>w||-w>d||v>w||-w>v||m>-S&&S>m&&5O|m*E||g>-S&&S>g&&5O|g*E)&&(y.2f=l,y.2g=c,y.1F=h,y.1S=p),3j&&(y.1Q=y.21=y.z=0,y.33=1q(o.8g)||0,y.2N=1)}y.2Q=T;1b(u 1w y)w>y[u]&&y[u]>-w&&(y[u]=0);18 n&&(e.4b=y),y},7O=17(e){19 t,n,r=15.1z,i=-r.1F*2q,s=i+r.1S*2q,o=54,u=(0|1h.2D(i)*r.2f*o)/o,a=(0|1h.2h(i)*r.2f*o)/o,f=(0|1h.2h(s)*-r.2g*o)/o,l=(0|1h.2D(s)*r.2g*o)/o,c=15.t.1v,h=15.t.2R;1a(h){n=a,a=-f,f=-n,t=h.2i,c.2i="";19 p,v,m=15.t.4H,g=15.t.4r,y="8y"!==h.4q,E="8x:5J.5L.5M(8z="+u+", 8O="+a+", 8N="+f+", 8L="+l,S=r.x,x=r.y;1a(1d!=r.57&&(p=(r.8K?.8I*m*r.57:r.57)-m/2,v=(r.8H?.8I*g*r.5K:r.5K)-g/2,S+=p-(p*u+v*a),x+=v-(p*f+v*l)),y?(p=m/2,v=g/2,E+=", 8E="+(p-(p*u+v*a)+S)+", 8G="+(v-(p*f+v*l)+x)+")"):E+=", bF=\'2n bB\')",c.2i=-1!==t.1k("5J.5L.5M(")?t.1D(O,E):E+" "+t,(0===e||1===e)&&1===u&&0===a&&0===f&&1===l&&(y&&-1===E.1k("8E=0, 8G=0")||w.2P(t)&&23!==1q(4k.$1)||-1===t.1k("bD("&&t.1k("bE"))&&c.6Q("2i")),!y){19 T,N,C,k=8>d?1:-1;1b(p=r.5l||0,v=r.58||0,r.5l=1h.59((m-((0>u?-u:u)*m+(0>a?-a:a)*g))/2+S),r.58=1h.59((g-((0>l?-l:l)*g+(0>f?-f:f)*m))/2+x),2m=0;4>2m;2m++)N=Z[2m],T=h[N],n=-1!==T.1k("2d")?1q(T):J(15.t,N,1q(T),T.1D(b,""))||0,C=n!==r[N]?2>2m?-r.5l:-r.58:2>2m?p-r.5l:v-r.58,c[N]=(r[N]=1h.59(n-C*(0===2m||2===2m?1:k)))+"2d"}}},7D=17(){19 e,t,n,r,i,s,o,u,a,f,l,c,p,d,v,m,g,y,b,w,E,S,x,T=15.1z,N=15.t.1v,C=T.1F*2q,k=T.2f,L=T.2g,A=T.2N,O=T.33;1a(h){19 M=1e-4;M>k&&k>-M&&(k=A=2e-5),M>L&&L>-M&&(L=A=2e-5),!O||T.z||T.1Q||T.21||(O=0)}1a(C||T.1S)y=1h.2D(C),b=1h.2h(C),e=y,i=b,T.1S&&(C-=T.1S*2q,y=1h.2D(C),b=1h.2h(C)),t=-b,s=y;1m{1a(!(T.21||T.1Q||1!==A||O))18 N[bt]="bC("+T.x+"2d,"+T.y+"2d,"+T.z+"2d)"+(1!==k||1!==L?" 48("+k+","+L+")":""),2u 0;e=s=1,t=i=0}l=1,n=r=o=u=a=f=c=p=d=0,v=O?-1/O:0,m=T.2Q,g=54,C=T.21*2q,C&&(y=1h.2D(C),b=1h.2h(C),a=l*-b,p=v*-b,n=e*b,o=i*b,l*=y,v*=y,e*=y,i*=y),C=T.1Q*2q,C&&(y=1h.2D(C),b=1h.2h(C),w=t*y+n*b,E=s*y+o*b,S=f*y+l*b,x=d*y+v*b,n=t*-b+n*y,o=s*-b+o*y,l=f*-b+l*y,v=d*-b+v*y,t=w,s=E,f=S,d=x),1!==A&&(n*=A,o*=A,l*=A,v*=A),1!==L&&(t*=L,s*=L,f*=L,d*=L),1!==k&&(e*=k,i*=k,a*=k,p*=k),m&&(c-=m,r=n*c,u=o*c,c=l*c+m),r=(w=(r+=T.x)-(r|=0))?(0|w*g+(0>w?-.5:.5))/g+r:r,u=(w=(u+=T.y)-(u|=0))?(0|w*g+(0>w?-.5:.5))/g+u:u,c=(w=(c+=T.z)-(c|=0))?(0|w*g+(0>w?-.5:.5))/g+c:c,N[bt]="bG("+[(0|e*g)/g,(0|i*g)/g,(0|a*g)/g,(0|p*g)/g,(0|t*g)/g,(0|s*g)/g,(0|f*g)/g,(0|d*g)/g,(0|n*g)/g,(0|o*g)/g,(0|l*g)/g,(0|v*g)/g,r,u,c,O?1+ -c/O:1].1G(",")+")"},7B=17(){19 e,t,n,r,i,s,o,u,a,f=15.1z,l=15.t,c=l.1v;h&&(e=c.3k?"3k":c.4x?"4x":1q($(l,"3k",1d,!1))?"4x":"3k",t=$(l,e,1d,!1),n=1q(t)||0,r=t.1t((n+"").1c)||"2d",f.6y=!f.6y,c[e]=(f.6y?n+.8v:n-.8v)+r),f.1F||f.1S?(i=f.1F*2q,s=i-f.1S*2q,o=54,u=f.2f*o,a=f.2g*o,c[bt]="8b("+(0|1h.2D(i)*u)/o+","+(0|1h.2h(i)*u)/o+","+(0|1h.2h(s)*-a)/o+","+(0|1h.2D(s)*a)/o+","+f.x+","+f.y+")"):c[bt]="8b("+f.2f+",0,0,"+f.2g+","+f.x+","+f.y+")"};1L("3P,48,2f,2g,2N,x,y,z,1F,1Q,21,6u,1S,30,6t,6B,6C,bI,4Q,8s,8n,8Q,4E",{2b:17(e,t,n,r,s,o,u){1a(r.3p)18 s;19 a,f,l,c,h,p,d,v=r.3p=44(e,i,!0,u.8Q),m=e.1v,g=1e-6,y=6K.1c,b=u,w={};1a("1H"==1j b.3P&&bt)l=m.37,m[bt]=b.3P,m.6s="bz",a=44(e,1d,!1),m.37=l;1m 1a("3T"==1j b){1a(a={2f:2B(1d!=b.2f?b.2f:b.48,v.2f),2g:2B(1d!=b.2g?b.2g:b.48,v.2g),2N:2B(1d!=b.2N?b.2N:b.48,v.2N),x:2B(b.x,v.x),y:2B(b.y,v.y),z:2B(b.z,v.z),33:2B(b.8s,v.33)},d=b.8n,1d!=d)1a("3T"==1j d)1b(l 1w d)b[l]=d[l];1m b.1F=d;a.1F=3z("1F"1w b?b.1F:"6t"1w b?b.6t+"6J":"6u"1w b?b.6u:v.1F,v.1F,"1F",w),3j&&(a.1Q=3z("1Q"1w b?b.1Q:"6B"1w b?b.6B+"6J":v.1Q||0,v.1Q,"1Q",w),a.21=3z("21"1w b?b.21:"6C"1w b?b.6C+"6J":v.21||0,v.21,"21",w)),a.1S=1d==b.1S?v.1S:3z(b.1S,v.1S),a.30=1d==b.30?v.30:3z(b.30,v.30),(f=a.30-v.30)&&(a.1S+=f,a.1F+=f)}1b(1d!=b.4E&&(v.4E=b.4E,p=!0),h=v.4E||v.z||v.1Q||v.21||a.z||a.1Q||a.21||a.33,h||1d==b.48||(a.2N=1);--y>-1;)n=6K[y],c=a[n]-v[n],(c>g||-g>c||1d!=P[n])&&(p=!0,s=1g 24(v,n,v[n],c,s),n 1w w&&(s.e=w[n]),s.1W=0,s.2A=o,r.2E.28(s.n));18 c=b.4Q,(c||3j&&h&&v.2Q)&&(bt?(p=!0,n=5m,c=(c||$(e,n,i,!1,"50% 50%"))+"",s=1g 24(m,n,0,0,s,-1,"4Q"),s.b=m[n],s.2A=o,3j?(l=v.2Q,c=c.1s(" "),v.2Q=(c.1c>2&&(0===l||"1J"!==c[2])?1q(c[2]):l)||0,s.1W=s.e=m[n]=c[0]+" "+(c[1]||"50%")+" 1J",s=1g 24(v,"2Q",0,0,s,-1,s.n),s.b=l,s.1W=s.e=v.2Q):s.1W=s.e=m[n]=c):3e(c+"",v)),p&&(r.3S=h||3===15.3S?3:2),s},2T:!0}),1L("bY",{2y:"1J 1J 1J 1J #6V",2T:!0,4g:!0,47:!0,4V:"6D"}),1L("bX",{2y:"1J",2b:17(e,t,n,s,o){t=15.2U(t);19 u,a,f,l,c,h,p,d,v,m,g,y,b,w,E,S,x=["c0","c3","bW","aW"],T=e.1v;1b(v=1q(e.4H),m=1q(e.4r),u=t.1s(" "),a=0;x.1c>a;a++)15.p.1k("3X")&&(x[a]=X(x[a])),c=l=$(e,x[a],i,!1,"1J"),-1!==c.1k(" ")&&(l=c.1s(" "),c=l[0],l=l[1]),h=f=u[a],p=1q(c),y=c.1t((p+"").1c),b="="===h.1u(1),b?(d=3q(h.1u(0)+"1",10),h=h.1t(2),d*=1q(h),g=h.1t((d+"").1c-(0>d?1:0))||""):(d=1q(h),g=h.1t((d+"").1c)),""===g&&(g=r[n]||y),g!==y&&(w=J(e,"6X",p,y),E=J(e,"aJ",p,y),"%"===g?(c=23*(w/v)+"%",l=23*(E/m)+"%"):"4d"===g?(S=J(e,"6X",1,"4d"),c=w/S+"4d",l=E/S+"4d"):(c=w+"2d",l=E+"2d"),b&&(h=1q(c)+d+g,f=1q(l)+d+g)),o=4f(T,x[a],c+" "+l,h+" "+f,!1,"1J",o);18 o},2T:!0,4R:6I("1J 1J 1J 1J",!1,!0)}),1L("b4",{2y:"0 0",2b:17(e,t,n,r,s,o){19 u,a,f,l,c,h,p="b9-4q",v=i||V(e,1d),m=15.2U((v?d?v.4m(p+"-x")+" "+v.4m(p+"-y"):v.4m(p):e.2R.c5+" "+e.2R.cQ)||"0 0"),g=15.2U(t);1a(-1!==m.1k("%")!=(-1!==g.1k("%"))&&(h=$(e,"cS").1D(C,""),h&&"3r"!==h)){1b(u=m.1s(" "),a=g.1s(" "),j.cM("cG",h),f=2;--f>-1;)m=u[f],l=-1!==m.1k("%"),l!==(-1!==a[f].1k("%"))&&(c=0===f?e.4H-j.3M:e.4r-j.3B,u[f]=l?1q(m)/23*c+"2d":23*(1q(m)/c)+"%");m=u.1G(" ")}18 15.46(e.1v,m,g,s,o)},4R:3e}),1L("cI",{2y:"0 0",4R:3e}),1L("33",{2y:"1J",2T:!0}),1L("cK",{2y:"50% 50%",2T:!0}),1L("cY",{2T:!0}),1L("cj",{2T:!0}),1L("cx",{2T:!0}),1L("6w",{2b:6A("83,81,82,7C")}),1L("6x",{2b:6A("cq,cl,cb,cF")}),1L("c9",{2y:"7R(1J,1J,1J,1J)",2b:17(e,t,n,r,s,o){19 u,a,f;18 9>d?(a=e.2R,f=8>d?" ":",",u="7R("+a.aG+f+a.cg+f+a.cD+f+a.d2+")",t=15.2U(t).1s(",").1G(f)):(u=15.2U($(e,15.p,i,!1,15.49)),t=15.2U(t)),15.46(e.1v,u,t,s,o)}}),1L("d5",{2y:"1J 1J 1J #6V",4g:!0,47:!0}),1L("7N,85",{2b:17(e,t,n,r,i){18 i}}),1L("3X",{2y:"1J 4S #6O",2b:17(e,t,n,r,s,o){18 15.46(e.1v,15.2U($(e,"70",i,!1,"1J")+" "+$(e,"cL",i,!1,"4S")+" "+$(e,"cR",i,!1,"#6O")),15.2U(t),s,o)},4g:!0,4R:17(e){19 t=e.1s(" ");18 t[0]+" "+(t[1]||"4S")+" "+(e.2K(at)||["#6O"])[0]}}),1L("9E,6S,6W",{2b:17(e,t,n,r,i){19 s=e.1v,o="6S"1w s?"6S":"6W";18 1g 24(s,o,0,0,i,-1,n,!1,0,s[o],t)}});19 73=17(e){19 t,n=15.t,r=n.2i||$(15.1z,"2i"),i=0|15.s+15.c*e;23===i&&(-1===r.1k("9k(")&&-1===r.1k("9e(")&&-1===r.1k("98(")?(n.6Q("2i"),t=!$(15.1z,"2i")):(n.2i=r.1D(S,""),t=!0)),t||(15.3O&&(n.2i=r=r||"3E(1Y="+i+")"),-1===r.1k("1Y")?0===i&&15.3O||(n.2i=r+" 3E(1Y="+i+")"):n.2i=r.1D(w,"1Y="+i))};1L("1Y,3E,5n",{2y:"1",2b:17(e,t,n,r,s,o){19 u=1q($(e,"1Y",i,!1,"1")),a=e.1v,f="5n"===n;18"1H"==1j t&&"="===t.1u(1)&&(t=("-"===t.1u(0)?-1:1)*1q(t.1t(2))+u),f&&1===u&&"5z"===$(e,"6E",i)&&0!==t&&(u=0),q?s=1g 24(a,"1Y",u,t-u,s):(s=1g 24(a,"1Y",23*u,23*(t-u),s),s.3O=f?1:0,a.7z=1,s.2r=2,s.b="3E(1Y="+s.s+")",s.e="3E(1Y="+(s.s+s.c)+")",s.1z=e,s.2A=o,s.1X=73),f&&(s=1g 24(a,"6E",0,0,s,-1,1d,!1,0,0!==u?"6T":"5z",0===t?"5z":"6T"),s.1W="6T",r.2E.28(s.n),r.2E.28(n)),s}});19 53=17(e,t){t&&(e.88?e.88(t.1D(T,"-$1").6R()):e.6Q(t))},7M=17(e){1a(15.t.4K=15,1===e||0===e){15.t.39=0===e?15.b:15.e;1b(19 t=15.1z,n=15.t.1v;t;)t.v?n[t.p]=t.v:53(n,t.p),t=t.1f;1===e&&15.t.4K===15&&(15.t.4K=1d)}1m 15.t.39!==15.e&&(15.t.39=15.e)};1L("39",{2b:17(e,t,r,s,o,u,a){19 f,l,c,h,p,d=e.39,v=e.1v.37;1a(o=s.6F=1g 24(e,r,0,0,o,2),o.1X=7M,o.2s=-11,n=!0,o.b=d,l=Q(e,i),c=e.4K){1b(h={},p=c.1z;p;)h[p.p]=1,p=p.1f;c.1X(1)}18 e.4K=o,o.e="="!==t.1u(1)?t:d.1D(4k("\\\\s*\\\\b"+t.1t(2)+"\\\\b"),"")+("+"===t.1u(0)?" "+t.1t(2):""),s.2V.1N&&(e.39=o.e,f=G(e,l,Q(e),a,h),e.39=d,o.1z=f.42,e.1v.37=v,o=o.3H=s.2S(e,f.4T,o,u)),o}});19 7I=17(e){1a((1===e||0===e)&&15.1z.1K===15.1z.2l&&"7G"!==15.1z.1z){19 t,n,r,i,s=15.t.1v,o=u.3P.2S;1a("3Y"===15.e)s.37="",i=!0;1m 1b(t=15.e.1s(","),r=t.1c;--r>-1;)n=t[r],u[n]&&(u[n].2S===o?i=!0:n="4Q"===n?5m:u[n].p),53(s,n);i&&(53(s,bt),15.t.4b&&3L 15.t.4b)}};1b(1L("9d",{2b:17(e,t,r,i,s){18 s=1g 24(e,r,0,0,s,2),s.1X=7I,s.e=t,s.2s=-10,s.1z=i.2V,n=!0,s}}),a="9m,9v,9u,9w".1s(","),2m=a.1c;2m--;)7H(a[2m]);a=o.1x,a.1r=1d,a.6M=17(e,t,u){1a(!e.3o)18!1;15.7t=e,15.2V=u,15.7E=t,f=t.7N,n=!1,r=t.6z||o.6z,i=V(e,""),s=15.2E;19 a,h,d,v,m,g,y,b,w,S=e.1v;1a(l&&""===S.3F&&(a=$(e,"3F",i),("2n"===a||""===a)&&(S.3F=0)),"1H"==1j t&&(v=S.37,a=Q(e,i),S.37=v+";"+t,a=G(e,a,Q(e)).4T,!q&&E.2P(t)&&(a.1Y=1q(4k.$1)),t=a,S.37=v),15.1r=h=15.2S(e,t,1d),15.3S){1b(w=3===15.3S,bt?c&&(l=!0,""===S.3F&&(y=$(e,"3F",i),("2n"===y||""===y)&&(S.3F=0)),p&&(S.7y=15.7E.7y||(w?"9p":"5z"))):S.7z=1,d=h;d&&d.1f;)d=d.1f;b=1g 24(e,"3P",0,0,1d,2),15.5w(b,1d,d),b.1X=w&&3j?7D:bt?7B:7O,b.1z=15.3p||44(e,i,!0),s.4G()}1a(n){1b(;h;){1b(g=h.1f,d=v;d&&d.2s>h.2s;)d=d.1f;(h.1l=d?d.1l:m)?h.1l.1f=h:v=h,(h.1f=d)?d.1l=h:m=h,h=g}15.1r=v}18!0},a.2S=17(e,t,n,s){19 o,a,l,c,h,p,d,v,m,g,y=e.1v;1b(o 1w t)p=t[o],a=u[o],a?n=a.2S(e,p,o,15,n,s,t):(h=$(e,o,i)+"",m="1H"==1j p,"4g"===o||"8Y"===o||"aj"===o||-1!==o.1k("ai")||m&&x.2P(p)?(m||(p=5d(p),p=(p.1c>3?"6N(":"5e(")+p.1G(",")+")"),n=4f(y,o,h,p,!0,"4a",n,0,s)):!m||-1===p.1k(" ")&&-1===p.1k(",")?(l=1q(h),d=l||0===l?h.1t((l+"").1c):"",(""===h||"2n"===h)&&("3M"===o||"3B"===o?(l=3D(e,o,i),d="2d"):"4u"===o||"3k"===o?(l=K(e,o,i),d="2d"):(l="1Y"!==o?0:1,d="")),g=m&&"="===p.1u(1),g?(c=3q(p.1u(0)+"1",10),p=p.1t(2),c*=1q(p),v=p.1D(b,"")):(c=1q(p),v=m?p.1t((c+"").1c)||"":""),""===v&&(v=r[o]||d),p=c||0===c?(g?c+l:c)+v:t[o],d!==v&&""!==v&&(c||0===c)&&(l||0===l)&&(l=J(e,o,l,d),"%"===v?(l/=J(e,o,23,"%")/23,l>23&&(l=23),t.85!==!0&&(h=l+"%")):"4d"===v?l/=J(e,o,1,"4d"):(c=J(e,o,c,v),v="2d"),g&&(c||0===c)&&(p=c+l+v)),g&&(c+=l),!l&&0!==l||!c&&0!==c?2u 0!==y[o]&&(p||"ad"!=p+""&&1d!=p)?(n=1g 24(y,o,c||l||0,0,n,-1,o,!1,0,h,p),n.1W="3r"!==p||"6s"!==o&&-1===o.1k("ae")?p:h):U("ao "+o+" 6v az: "+t[o]):(n=1g 24(y,o,l,c-l,n,0,o,f!==!1&&("2d"===v||"3F"===o),0,h,p),n.1W=v)):n=4f(y,o,h,p,!0,1d,n,0,s)),s&&n&&!n.2A&&(n.2A=s);18 n},a.1X=17(e){19 t,n,r,i=15.1r,s=1e-6;1a(1!==e||15.2V.1n!==15.2V.1N&&0!==15.2V.1n)1a(e||15.2V.1n!==15.2V.1N&&0!==15.2V.1n||15.2V.1O===-1e-6)1b(;i;){1a(t=i.c*e+i.s,i.r?t=t>0?0|t+.5:0|t-.5:s>t&&t>-s&&(t=0),i.2r)1a(1===i.2r)1a(r=i.l,2===r)i.t[i.p]=i.1W+t+i.3V+i.3O+i.5b;1m 1a(3===r)i.t[i.p]=i.1W+t+i.3V+i.3O+i.5b+i.6L+i.6H;1m 1a(4===r)i.t[i.p]=i.1W+t+i.3V+i.3O+i.5b+i.6L+i.6H+i.79+i.7u;1m 1a(5===r)i.t[i.p]=i.1W+t+i.3V+i.3O+i.5b+i.6L+i.6H+i.79+i.7u+i.9B+i.9F;1m{1b(n=i.1W+t+i.3V,r=1;i.l>r;r++)n+=i["3g"+r]+i["2X"+(r+1)];i.t[i.p]=n}1m-1===i.2r?i.t[i.p]=i.1W:i.1X&&i.1X(e);1m i.t[i.p]=t+i.1W;i=i.1f}1m 1b(;i;)2!==i.2r?i.t[i.p]=i.b:i.1X(e),i=i.1f;1m 1b(;i;)2!==i.2r?i.t[i.p]=i.e:i.1X(e),i=i.1f},a.9H=17(e){15.3S=e||3===15.3S?3:2,15.3p=15.3p||44(15.7t,i,!0)},a.5w=17(e,t,n,r){18 e&&(t&&(t.1l=e),e.1f&&(e.1f.1l=e.1l),e.1l?e.1l.1f=e.1f:15.1r===e&&(15.1r=e.1f,r=!0),n?n.1f=e:r||1d!==15.1r||(15.1r=e),e.1f=t,e.1l=n),e},a.2p=17(t){19 n,r,i,s=t;1a(t.5n||t.3E){s={};1b(r 1w t)s[r]=t[r];s.1Y=1,s.5n&&(s.6E=1)}18 t.39&&(n=15.6F)&&(i=n.3H,i&&i.1l?15.5w(i.1l,n.1f,i.1l.1l):i===15.1r&&(15.1r=n.1f),n.1f&&15.5w(n.1f,n.1f.1f,i.1l),15.6F=1d),e.1x.2p.1Z(15,s)};19 4n=17(e,t,n){19 r,i,s,o;1a(e.6G)1b(i=e.1c;--i>-1;)4n(e[i],t,n);1m 1b(r=e.7j,i=r.1c;--i>-1;)s=r[i],o=s.2r,s.1v&&(t.28(Q(s)),n&&n.28(s)),1!==o&&9!==o&&11!==o||!s.7j.1c||4n(s,t,n)};18 o.9X=17(e,n,r){19 i,s,o,u=t.3v(e,n,r),a=[u],f=[],l=[],c=[],h=t.4p.7i;1b(e=u.2z||u.2v,4n(e,f,c),u.1B(n,!0),4n(e,l),u.1B(0,!0),u.1M(!0),i=c.1c;--i>-1;)1a(s=G(c[i],f[i],l[i]),s.42){s=s.4T;1b(o 1w r)h[o]&&(s[o]=r[o]);a.28(t.3v(c[i],n,s))}18 a},e.6P([o]),o},!0)}),1T.3R&&1T.3b.4G()()', 62, 813, '|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||this||function|return|var|if|for|length|null||_next|new|Math|_startTime|typeof|indexOf|_prev|else|_time|vars|_timeline|parseFloat|_firstPT|split|substr|charAt|style|in|prototype|_timeScale|data|_paused|render|Number|replace|255|rotation|join|string|_gc|0px|_totalTime|mt|_enabled|_duration|_rawPrevTime|add|rotationX|_p1|skewX|window|timeline|immediateRender|xs0|setRatio|opacity|call||rotationY|arguments|100|ht||totalDuration|_first|push|_startAt|instanceof|parser|_active|px||scaleX|scaleY|sin|filter|easing|_p2|_totalDuration|dt|auto|_dirty|_kill|_|type|pr|number|void|target|_initted|getRatio|defaultValue|_targets|plugin|rt|duration|cos|_overwriteProps|smoothChildTiming|_reversed|_ease|5625|_delay|match|_labels|constructor|scaleZ|128|test|zOrigin|currentStyle|parse|prefix|format|_tween|splice|xs|_siblings|totalTime|skewY|180|_onUpdate|perspective|paused|_uncache|apply|cssText|startAt|className|wake|_gsQueue|_p3|_parseTimeOrLabel|tt|_overwrittenProps|xn|_last|ratio|St|top|sqrt|_calcEnd|pow|nodeType|_transform|parseInt|none|nt|config|time|to|selector|tweens|rawTime|it|_propLookup|height|_remove|et|alpha|zIndex|st|xfirst|appendXtra|API|Array|delete|width|gi|xn1|transform|ease|_gsDefine|_transformType|object|concat|xs1|getTweensOf|border|all|version|_listeners|frame|firstMPT|reversed|xt||parseComplex|multi|scale|dflt|transparent|_gsTransform|kill|em|seek|pt|color|set|onComplete|onReverseComplete|RegExp|PI|getPropertyValue|Mt|_initProps|_internals|position|offsetHeight|css|self|left|sc|atan2|bottom|delay|plugins|greensock|onStart|runBackwards|_pauseTime|force3D|com|pop|offsetWidth|_notifyPluginsOfEnabled|_sortChildren|_gsClassPT|overwrite|pg|_propName|isActive|autoRemoveChildren|transformOrigin|formatter|solid|difs|_onPluginEvent|keyword|ot|sleep|9999999999|_onInitAllProps||remove|Ticker|Lt|1e5||abs|ox|ieOffsetY|round|gsClass|xs2|TweenLite|ut|rgb|rxp|getChildren|toUpperCase|invalidate|192|core|ieOffsetX|Et|autoAlpha|_swapSelfInParams|easeParams|onUpdate|easeInOut|easeIn|next|strict|use|_linkCSSP|prev|tick|hidden|autoCSS|_func|_params|onStartParams|module|check|vt|priority|staggerTo|DXImageTransform|oy|Microsoft|Matrix|timeScale|false|_easeType|useFrames|easeOut|_overwrite|_priority|_hasPausedChild|define|throw|isNaN|Left|SlowMo||onCompleteParams|onCompleteScope|onStartScope|ms|console|fromTo|onUpdateParams|from|document|createElement|onUpdateScope|pause|625|984375|fps|_power|GreenSockGlobals|9375|_type|delayedCall|Scope|hsl|defaultEase|Params|setTimeout|_onDisable|360|display|shortRotation|rotationZ|tween|margin|padding|_ffFix|suffixMap|lt|shortRotationX|shortRotationY|inset|visibility|_classNamePT|slice|xs3|ft|_short|yt|xn2|_onInitTween|rgba|000|activate|removeAttribute|toLowerCase|cssFloat|inherit|log|999|styleFloat|borderLeft|_rootFramesTimeline|defaultView|borderTopWidth|_roundProps|Animation|kt|url||func|div|init|xn3|propName|onReverseCompleteParams|_init|center|right|_easePower|get|_gsTweenID|reservedProps|childNodes|Width|shiftChildren|appendChild|SimpleTimeline|onReverseCompleteScope|break|filters|Top|Right|_target|xs4|Ease|play|gap|WebkitBackfaceVisibility|zoom|_contains|Ct|marginLeft|Nt|_vars|Back|isFromStart|gt|Ot|template|strength|random|At|autoRound|Tt|removeLabel|TweenPlugin|rect|SteppedEase|isArray|isSelector|_p|_class|register|RoughEase|map|addLabel|marginRight|marginBottom|marginTop|insert|strictUnits|_updateRoot|Cannot|removeProperty|_onEnable|not|matrix|autoRotate|1e3|useRAF|startTime|defaultTransformPerspective|ticker|defaultOverwrite|Plugin|black|Date|events|directionalRotation|up|2e3|EventDispatcher|_eventTarget|transformPerspective|proxy|Linear|05|Quad|progid|absolute|M11|exports|wt|dispatchEvent|clrs|Dx|GreenSockAMDPath|Dy|oyp|01|autoSleep|oxp|M22|addEventListener|M21|M12|red|parseTransform|insertMultiple|cancelAnimationFrame|appendMultiple|CancelRequestAnimationFrame|stop|moz|getLabelTime|fill|RequestAnimationFrame||webkit|getTime|CancelAnimationFrame|addPause|now|easeNone|globals|oader||Cubic|clear|Quart|clearProps|radient|undefined|999999999999|Object|toString|amd|atrix|Quint|bezier|removeEventListener|swing|visible|gotoAndStop|gotoAndPlay|linear|004|physicsProps|throwProps|physics2D|Strong|Power|requestAnimationFrame|sequence|xn4|jQuery|_autoCSS|float|xs5|getElementById|_enableTransforms|jquery|killTweensOf|_addTween|illegal|_super|progress|killDelayedCallsTo|totalProgress|_tempKill|_plugins|preexisting|allOnStart|concurrent|true|_rootTimeline|cascadeTo|120|repeatDelay|repeat|_dummyGS|_tweenLookup|onRepeat|onRepeatParams|yoyo|onRepeatScope|definition|on|staggerFromTo|clearTimeout|exportRoot|staggerFrom|NaN|Style|1500|normal|start|Color|stroke|or|is|into|the|invalid|stagger|global|restart|reverse||initAll|overwriteProps|eventCallback|GSAP|encountered|value|align|resume|TimelineLite|missing|dependency|append|clipTop|offset|Origin|borderTop|Bottom|removeChild|body|line|borderLeftWidth|parentNode|oxr|oyr|aqua|lime|silver|maroon|borderBottomLeftRadius|ccw|rad|short|_cw|clientHeight|clientWidth|Android|backgroundPosition|Safari|Chrome|userAgent|navigator|background|img|_specialProps|Version|Firefox|Moz|Ms|Webkit|getComputedStyle|getElementsByTagName|1px|MSIE|exec|innerHTML|teal|blue|Error|js|file|loaded||_cssRegister|_registerComplexSpecialProp|end|CSSPropTween|collapsible|block|registerSpecialProp|expand|translate3d|gradient|Alpha|sizingMethod|matrix3d|179|shortRotationZ|270|_parseToProxy|_setPluginRatio|orange|165|gray|purple|yellow|olive|navy|white|fuchsia|green|borderBottomRightRadius|borderRadius|boxShadow|hsla|borderTopLeftRadius|cyan|pink|borderTopRightRadius|203|backgroundPositionX|getStyle|70158|ExpoIn|clip|ExpoOut|paddingBottom|Expo|001|ExpoInOut|SineOut|clipRight|sort|525|backfaceVisibility|Sine|paddingRight|Bounce|CircInOut|BounceInOut|CircIn|paddingTop|Circ|CircOut||BounceIn|asin|ElasticInOut|userSelect|ElasticIn|ElasticOut|BounceOut|Elastic|out|clipBottom|CSSPlugin|paddingLeft|src|999999999|backgroundSize|SineIn|perspectiveOrigin|borderTopStyle|setAttribute|zA|Z0|fontSize|backgroundPositionY|borderTopColor|backgroundImage|taper|BackInOut|EaseLookup|usesFrames|clamp|transformStyle|SineInOut|find|randomize|clipLeft|BackOut|points|textShadow|BackIn'.split('|'), 0, {}))

/*
	* 2D & 3D Transitions for LayerSlider
	*
	* (c) 2011-2013 George Krupa, John Gera & Kreatura Media
	*
	* Plugin web:			http://kreaturamedia.com/
	* Licenses: 			http://codecanyon.net/licenses/
*/

eval(function(p, a, c, k, e, d) {
    e = function(c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
    }
    ;
    while (c--) {
        if (k[c]) {
            p = p.replace(new RegExp('\\b' + e(c) + '\\b','g'), k[c])
        }
    }
    return p
}('20 1Z={27:[{j:"13 N E",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"1e",a:G,h:"r"}},{j:"13 N r",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"1e",a:G,h:"E"}},{j:"13 N L",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"1e",a:G,h:"J"}},{j:"13 N J",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"1e",a:G,h:"L"}},{j:"26",d:1,g:1,f:{e:0,i:"o"},c:{n:"14",b:"1e",a:G,h:"r"}},{j:"Z R o",d:[2,4],g:[4,7],f:{e:1k,i:"o"},c:{n:"14",b:"z",a:G,h:"r"}},{j:"Z R D",d:[2,4],g:[4,7],f:{e:1k,i:"D"},c:{n:"14",b:"z",a:G,h:"r"}},{j:"Z R 1j-o",d:[2,4],g:[4,7],f:{e:1k,i:"1j-o"},c:{n:"14",b:"z",a:G,h:"r"}},{j:"Z R 1j-D",d:[2,4],g:[4,7],f:{e:1k,i:"1j-D"},c:{n:"14",b:"z",a:G,h:"r"}},{j:"Z R (k)",d:[2,4],g:[4,7],f:{e:1k,i:"k"},c:{n:"14",b:"z",a:G,h:"r"}},{j:"1y 1H N E",d:1,g:1s,f:{e:25,i:"D"},c:{n:"14",b:"1X",a:V,h:"r"}},{j:"1y 1H N r",d:1,g:1s,f:{e:25,i:"o"},c:{n:"14",b:"w",a:V,h:"r"}},{j:"1y 1H N L",d:1s,g:1,f:{e:25,i:"1j-D"},c:{n:"14",b:"w",a:V,h:"r"}},{j:"1y 1H N J",d:1s,g:1,f:{e:25,i:"1j-o"},c:{n:"14",b:"w",a:V,h:"r"}},{j:"1y Y N E",d:1,g:25,f:{e:1k,i:"D"},c:{n:"W",b:"w",a:1g,h:"r"}},{j:"1y Y N r",d:1,g:25,f:{e:1k,i:"o"},c:{n:"W",b:"w",a:1g,h:"E"}},{j:"1y 1W N L",d:25,g:1,f:{e:1k,i:"1j-D"},c:{n:"W",b:"w",a:1g,h:"J"}},{j:"1y Y N J",d:25,g:1,f:{e:1k,i:"1j-o"},c:{n:"W",b:"w",a:1g,h:"L"}},{j:"13 R m E (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"W",b:"z",a:1m,h:"E"}},{j:"13 R m r (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"W",b:"z",a:1m,h:"r"}},{j:"13 R m L (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"W",b:"z",a:1m,h:"L"}},{j:"13 R m J (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"W",b:"z",a:1m,h:"J"}},{j:"13 k R m k 1S",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"W",b:"z",a:1m,h:"k"}},{j:"13 d m E (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"W",b:"w",a:p,h:"E"}},{j:"13 d m E (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"W",b:"w",a:p,h:"E"}},{j:"13 d m E (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"W",b:"w",a:p,h:"E"}},{j:"13 d m r (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"W",b:"w",a:p,h:"r"}},{j:"13 d m r (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"W",b:"w",a:p,h:"r"}},{j:"13 d m r (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"W",b:"w",a:p,h:"r"}},{j:"13 d N J m L (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"W",b:"w",a:p,h:"L"}},{j:"13 d N J m L (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"W",b:"w",a:p,h:"L"}},{j:"13 d N L m J (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"W",b:"w",a:p,h:"J"}},{j:"13 d N L m J (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"W",b:"w",a:p,h:"J"}},{j:"13 P m L (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"W",b:"w",a:p,h:"L"}},{j:"13 P m L (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"W",b:"w",a:p,h:"L"}},{j:"13 P m L (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"W",b:"w",a:p,h:"L"}},{j:"13 P m J (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"W",b:"w",a:p,h:"J"}},{j:"13 P m J (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"W",b:"w",a:p,h:"J"}},{j:"13 P m J (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"W",b:"w",a:p,h:"J"}},{j:"13 P N r m E (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"W",b:"w",a:p,h:"E"}},{j:"13 P N r m E (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"W",b:"w",a:p,h:"E"}},{j:"13 P N E m r (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"W",b:"w",a:p,h:"r"}},{j:"13 P N E m r (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"W",b:"w",a:p,h:"r"}},{j:"Z v Y R m E (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"E"}},{j:"Z v Y R m r (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"r"}},{j:"Z v Y R m L (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"L"}},{j:"Z v Y R m J (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"J"}},{j:"Z v Y k R m k 1S",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"k"}},{j:"Z v Y R N J-r (o)",d:[2,4],g:[4,7],f:{e:1f,i:"o"},c:{n:"Q",b:"z",a:1m,h:"1V"}},{j:"Z v Y R N L-E (D)",d:[2,4],g:[4,7],f:{e:1f,i:"D"},c:{n:"Q",b:"z",a:1m,h:"21"}},{j:"Z v Y R N J-E (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"1T"}},{j:"Z v Y R N L-r (k)",d:[2,4],g:[4,7],f:{e:1f,i:"k"},c:{n:"Q",b:"z",a:1m,h:"1U"}},{j:"Z v Y d m E (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"Q",b:"w",a:p,h:"E"}},{j:"Z v Y d m E (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"Q",b:"w",a:p,h:"E"}},{j:"Z v Y d m E (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"Q",b:"w",a:p,h:"E"}},{j:"Z v Y d m r (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"Q",b:"w",a:p,h:"r"}},{j:"Z v Y d m r (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"Q",b:"w",a:p,h:"r"}},{j:"Z v Y d m r (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"Q",b:"w",a:p,h:"r"}},{j:"Z v Y d N J m L (o)",d:[7,11],g:1,f:{e:1d,i:"o"},c:{n:"Q",b:"w",a:p,h:"L"}},{j:"Z v Y d N J m L (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"Q",b:"w",a:p,h:"L"}},{j:"Z v Y d N L m J (D)",d:[7,11],g:1,f:{e:1d,i:"D"},c:{n:"Q",b:"w",a:p,h:"J"}},{j:"Z v Y d N L m J (k)",d:[7,11],g:1,f:{e:1d,i:"k"},c:{n:"Q",b:"w",a:p,h:"J"}},{j:"Z v Y P m L (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"Q",b:"w",a:p,h:"L"}},{j:"Z v Y P m L (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"Q",b:"w",a:p,h:"L"}},{j:"Z v Y P m L (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"Q",b:"w",a:p,h:"L"}},{j:"Z v Y P m J (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"Q",b:"w",a:p,h:"J"}},{j:"Z v Y P m J (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"Q",b:"w",a:p,h:"J"}},{j:"Z v Y P m J (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"Q",b:"w",a:p,h:"J"}},{j:"Z v Y P N r m E (o)",d:1,g:[12,16],f:{e:q,i:"o"},c:{n:"Q",b:"w",a:p,h:"E"}},{j:"Z v Y P N r m E (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"Q",b:"w",a:p,h:"E"}},{j:"Z v Y P N E m r (D)",d:1,g:[12,16],f:{e:q,i:"D"},c:{n:"Q",b:"w",a:p,h:"r"}},{j:"Z v Y P N E m r (k)",d:1,g:[12,16],f:{e:q,i:"k"},c:{n:"Q",b:"w",a:p,h:"r"}},{j:"1u",d:1,g:1,f:{e:0,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5}},{j:"1u d",d:4,g:1,f:{e:1f,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5}},{j:"1u g",d:1,g:4,f:{e:1f,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5}},{j:"1u R A",d:3,g:4,f:{e:1s,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5,y:x}},{j:"1u R F",d:3,g:4,f:{e:1s,i:"o"},c:{n:"Q",b:"1e",a:V,h:"J",1h:.5,u:-x}},{j:"1u-1I R A",d:3,g:4,f:{e:15,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5,y:x}},{j:"1u-1I R F",d:3,g:4,f:{e:15,i:"o"},c:{n:"Q",b:"1e",a:V,h:"J",1h:.5,u:-x}},{j:"1u 1I d",d:4,g:1,f:{e:1f,i:"o"},c:{n:"Q",b:"1e",a:V,h:"E",1h:.5}},{j:"1u 1I g",d:1,g:4,f:{e:1f,i:"o"},c:{n:"Q",b:"1e",a:V,h:"r",1h:.5}},{j:"1c f N r",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"z",a:V,h:"E",y:x}},{j:"1c f N E",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"z",a:V,h:"r",y:-x}},{j:"1c f N J",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"z",a:V,h:"L",u:-x}},{j:"1c f N L",d:1,g:1,f:{e:0,i:"o"},c:{n:"W",b:"z",a:V,h:"J",u:x}},{j:"1c R N r",d:[3,4],g:[3,4],f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",y:x}},{j:"1c R N E",d:[3,4],g:[3,4],f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",y:-x}},{j:"1c R N J",d:[3,4],g:[3,4],f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",u:-x}},{j:"1c R N L",d:[3,4],g:[3,4],f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",u:x}},{j:"1c d N J",d:[6,12],g:1,f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",u:x}},{j:"1c d N L",d:[6,12],g:1,f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",u:-x}},{j:"1c g N r",d:1,g:[6,12],f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",y:-x}},{j:"1c g N E",d:1,g:[6,12],f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",y:x}},{j:"1v d N r",d:[3,10],g:1,f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",y:x}},{j:"1v d N E",d:[3,10],g:1,f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",y:-x}},{j:"1v g N J",d:1,g:[3,10],f:{e:19,i:"o"},c:{n:"14",b:"z",a:V,h:"r",u:-x}},{j:"1v g N L",d:1,g:[3,10],f:{e:19,i:"D"},c:{n:"14",b:"z",a:V,h:"r",u:x}},{j:"1v v 1z f N r",d:1,g:1,f:{e:q,i:"o"},c:{n:"Q",b:"z",a:V,h:"E",1h:.1,1r:-x,y:x}},{j:"1v v 1z f N E",d:1,g:1,f:{e:q,i:"o"},c:{n:"Q",b:"z",a:V,h:"r",1h:.1,1r:x,y:-x}},{j:"1v v 1z R N r",d:[3,4],g:[3,4],f:{e:19,i:"o"},c:{n:"Q",b:"z",a:V,h:"E",1r:-1w}},{j:"1v v 1z R N E",d:[3,4],g:[3,4],f:{e:19,i:"o"},c:{n:"Q",b:"z",a:V,h:"r",1r:-1w}},{j:"1v v 1z R N k",d:[3,4],g:[3,4],f:{e:19,i:"k"},c:{n:"Q",b:"z",a:V,h:"k",1r:-1w}},{j:"B f 1O",d:1,g:1,f:{e:0,i:"o"},c:{n:"14",b:"z",a:1a,h:"r",1h:.8}},{j:"B f N 1L",d:1,g:1,f:{e:0,i:"o"},c:{n:"14",b:"w",a:1a,h:"r",1h:1.2}},{j:"B R k",d:[3,4],g:[3,4],f:{e:1s,i:"k"},c:{n:"14",b:"z",a:V,h:"r",1h:.1}},{j:"B R N 1L k",d:[3,4],g:[3,4],f:{e:1s,i:"k"},c:{n:"14",b:"z",a:V,h:"r",1h:2}},{j:"B 1O v 1z R k",d:[3,4],g:[3,4],f:{e:1s,i:"k"},c:{n:"14",b:"z",a:V,h:"r",1h:.1,1r:x}},{j:"B v 1z R N 1L k",d:[3,4],g:[3,4],f:{e:1s,i:"k"},c:{n:"14",b:"z",a:V,h:"r",1h:2,1r:-x}},{j:"1D-Y R 24",d:3,g:4,f:{e:15,i:"o"},c:{n:"W",b:"w",a:1Y,h:"1T"}},{j:"1D-Y d A",d:6,g:1,f:{e:0,i:"o"},c:{n:"Q",b:"z",a:V,h:"r"}},{j:"1D-Y d F",d:6,g:1,f:{e:0,i:"o"},c:{n:"Q",b:"z",a:V,h:"J"}},{j:"1D-Y g A",d:1,g:8,f:{e:0,i:"o"},c:{n:"Q",b:"z",a:V,h:"r"}},{j:"1D-Y g F",d:1,g:8,f:{e:0,i:"o"},c:{n:"Q",b:"z",a:V,h:"J"}}],23:[{j:"1b f m E (l&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{y:1E},b:"1F",a:G,h:"A"},C:{c:{y:l},b:"z",a:G,h:"A"}},{j:"1b f m r (l&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{y:-1E},b:"1F",a:G,h:"A"},C:{c:{y:-l},b:"z",a:G,h:"A"}},{j:"1b f m L (l&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{u:-1E},b:"1F",a:1x,h:"F"},C:{c:{u:-l},b:"z",a:1x,h:"F"}},{j:"1b f m J (l&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{u:1E},b:"1F",a:1x,h:"F"},C:{c:{u:l},b:"z",a:1x,h:"F"}},{j:"1b R m E (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"o"},s:{c:{y:l},b:"w",a:G,h:"A"}},{j:"1b R m r (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"D"},s:{c:{y:-l},b:"w",a:G,h:"A"}},{j:"1b R m L (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-o"},s:{c:{u:-l},b:"w",a:G,h:"F"}},{j:"1b R m J (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-D"},s:{c:{u:l},b:"w",a:G,h:"F"}},{j:"1B S R k (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},s:{c:{y:l},b:"w",a:1G,h:"A"}},{j:"1C S R k (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},s:{c:{u:l},b:"w",a:1G,h:"F"}},{j:"B v S R m E (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"o"},M:{c:{I:.1A},a:1l,b:"18"},s:{c:{y:l},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v S R m r (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"D"},M:{c:{I:.1A},a:1l,b:"18"},s:{c:{y:-l},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v S R m L (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-o"},M:{c:{I:.1A},a:1l,b:"18"},s:{c:{u:-l},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v S R m J (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-D"},M:{c:{I:.1A},a:1l,b:"18"},s:{c:{u:l},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v A S R k (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},M:{c:{I:.1A,u:1k},a:1l,b:"18"},s:{c:{y:l,u:-1k},b:"H",a:1G,h:"A"},C:{c:{u:0},a:1g,b:"H"}},{j:"B v F S R k (l&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},M:{c:{I:.1A,y:-15},a:1l,b:"18"},s:{c:{u:l,y:15},b:"H",a:1G,h:"F"},C:{c:{y:0},a:1g,b:"H"}},{j:"1b d m E (l&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},s:{c:{y:l},b:"w",a:1a,h:"A"}},{j:"1b d m r (l&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},s:{c:{y:-l},b:"w",a:1a,h:"A"}},{j:"1b d m L (l&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},s:{c:{u:-l},b:"w",a:G,h:"F"}},{j:"1b d m J (l&#t;)",d:[5,9],g:1,f:{e:q,i:"D"},s:{c:{u:l},b:"w",a:G,h:"F"}},{j:"1B S d k (l&#t;)",d:[5,9],g:1,f:{e:q,i:"k"},s:{c:{y:l},b:"w",a:1a,h:"A"}},{j:"1C S d k (l&#t;)",d:[5,9],g:1,f:{e:q,i:"k"},s:{c:{u:-l},b:"w",a:1a,h:"F"}},{j:"1C S d k (1J&#t;)",d:[3,7],g:1,f:{e:1Q,i:"k"},s:{c:{u:-1J},b:"w",a:1R,h:"F"}},{j:"B v S d m E (l&#t;)",d:[5,9],g:1,f:{e:19,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"H",a:1p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v S d m r (l&#t;)",d:[5,9],g:1,f:{e:19,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:-l},b:"H",a:1p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v S d m L (l&#t;)",d:[5,9],g:1,f:{e:19,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"w",a:p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v S d m J (l&#t;)",d:[5,9],g:1,f:{e:19,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:l},b:"w",a:p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v A S d k (l&#t;)",d:[5,9],g:1,f:{e:19,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"H",a:1p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v F S d k (l&#t;)",d:[5,9],g:1,f:{e:19,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"H",a:p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"1b P m E (l&#t;)",d:1,g:[5,9],f:{e:q,i:"o"},s:{c:{y:l},b:"w",a:1a,h:"A"}},{j:"1b P m r (l&#t;)",d:1,g:[5,9],f:{e:q,i:"o"},s:{c:{y:-l},b:"w",a:1a,h:"A"}},{j:"1b P m L (l&#t;)",d:1,g:[5,9],f:{e:q,i:"o"},s:{c:{u:-l},b:"w",a:G,h:"F"}},{j:"1b P m J (l&#t;)",d:1,g:[5,9],f:{e:q,i:"D"},s:{c:{u:l},b:"w",a:G,h:"F"}},{j:"1B S P k (l&#t;)",d:1,g:[5,9],f:{e:q,i:"k"},s:{c:{y:l},b:"w",a:1a,h:"A"}},{j:"1C S P k (l&#t;)",d:1,g:[5,9],f:{e:q,i:"k"},s:{c:{u:-l},b:"w",a:1a,h:"F"}},{j:"1B S P k (1J&#t;)",d:1,g:[4,9],f:{e:1Q,i:"k"},s:{c:{y:1J},b:"w",a:1R,h:"A"}},{j:"B v S P m E (l&#t;)",d:1,g:[7,11],f:{e:19,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"w",a:p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v S P m r (l&#t;)",d:1,g:[7,11],f:{e:19,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:-l},b:"w",a:p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v S P m L (l&#t;)",d:1,g:[7,11],f:{e:19,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"H",a:1p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v S P m J (l&#t;)",d:1,g:[7,11],f:{e:q,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:l},b:"H",a:1p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v A S P k (l&#t;)",d:1,g:[7,11],f:{e:q,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"H",a:p,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v F S P k (l&#t;)",d:1,g:[7,11],f:{e:q,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"H",a:1p,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"1N 1P 1M v S m E (l&#t;)",d:1,g:[7,11],f:{e:q,i:"o"},M:{c:{I:.O,u:-1k},a:p,b:"z"},s:{c:{u:-1k,y:l},b:"w",a:G,h:"A"},C:{c:{u:0,e:X},b:"z",a:p}},{j:"1N 1P 1M v S m r (l&#t;)",d:1,g:[7,11],f:{e:q,i:"D"},M:{c:{I:.O,u:-1k},a:p,b:"z"},s:{c:{u:1k,y:-l},b:"w",a:G,h:"A"},C:{c:{u:0,e:X},b:"z",a:p}},{j:"1c 1t m E (x&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{y:x},b:"w",a:1a,h:"A"}},{j:"1c 1t m r (x&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{y:-x},b:"w",a:1a,h:"A"}},{j:"1c 1t m L (x&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{u:-x},b:"w",a:1a,h:"F"}},{j:"1c 1t m J (x&#t;)",d:1,g:1,f:{e:q,i:"o"},s:{c:{u:x},b:"w",a:1a,h:"F"}},{j:"B v 17 1t m E (x&#t;)",d:1,g:1,f:{e:q,i:"k"},s:{c:{I:.8,1r:7,u:10,y:1w},b:"1e",a:1x,h:"A"},C:{c:{1r:0,u:0,y:x},a:1x,b:"1e"}},{j:"B v 17 1t m r (x&#t;)",d:1,g:1,f:{e:q,i:"k"},s:{c:{I:.8,1r:-7,u:10,y:-1w},b:"1e",a:1x,h:"A"},C:{c:{1r:0,u:0,y:-x},a:1x,b:"1e"}},{j:"B v 17 1n m E (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"o"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{y:x},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v 17 1n m r (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"D"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{y:-x},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v 17 1n m L (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-o"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{u:-x},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v 17 1n m J (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"1j-D"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{u:x},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v A 17 1n k (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},M:{c:{I:.1i,u:-15},a:1o,b:"18"},s:{c:{y:q,u:15},b:"H",a:1o,h:"A"},C:{c:{y:x,u:0},a:1o,b:"H"}},{j:"B v F 17 1n k (x&#t;)",d:[2,4],g:[4,7],f:{e:q,i:"k"},M:{c:{I:.1i,y:15},a:1o,b:"18"},s:{c:{u:q,y:-15},b:"H",a:1o,h:"F"},C:{c:{u:x,y:0},a:1o,b:"H"}},{j:"1c d m E (x&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},s:{c:{y:x},b:"w",a:1a,h:"A"}},{j:"1c d m r (x&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},s:{c:{y:-x},b:"w",a:1a,h:"A"}},{j:"1B 17 d k (x&#t;)",d:[5,9],g:1,f:{e:q,i:"k"},s:{c:{y:x},b:"w",a:1a,h:"A"}},{j:"B v 17 d m E (x&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:22,u:0},b:"H",a:G,h:"A"},C:{c:{e:X,y:x},b:"K",a:p}},{j:"B v 17 d m r (x&#t;)",d:[5,9],g:1,f:{e:q,i:"D"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:-x,u:0},b:"H",a:G,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v 17 d m L (x&#t;)",d:[5,9],g:1,f:{e:q,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v 17 d m J (x&#t;)",d:[5,9],g:1,f:{e:q,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v A 17 d k (x&#t;)",d:[5,9],g:1,f:{e:q,i:"k"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:x,u:0},b:"H",a:G,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v F 17 d k (x&#t;)",d:[5,9],g:1,f:{e:q,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v A 17 1K d m E (x&#t;)",d:[7,11],g:1,f:{e:q,i:"o"},s:{c:{I:.O,u:5,y:1w},b:"18",a:G,h:"A"},C:{c:{u:0,y:x},b:"18",a:G}},{j:"B v A 17 1K d m r (x&#t;)",d:[7,11],g:1,f:{e:q,i:"D"},s:{c:{I:.O,u:5,y:-1w},b:"18",a:G,h:"A"},C:{c:{u:0,y:-x},b:"18",a:G}},{j:"1c P m L (x&#t;)",d:1,g:[5,9],f:{e:q,i:"o"},s:{c:{u:-x},b:"w",a:G,h:"F"}},{j:"1c P m J (x&#t;)",d:1,g:[5,9],f:{e:q,i:"D"},s:{c:{u:x},b:"w",a:G,h:"F"}},{j:"1C 17 P k (x&#t;)",d:1,g:[5,9],f:{e:q,i:"k"},s:{c:{u:-x},b:"w",a:G,h:"F"}},{j:"B v 17 P m L (x&#t;)",d:1,g:[7,11],f:{e:q,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v 17 P m J (x&#t;)",d:1,g:[7,11],f:{e:q,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v 17 P m E (x&#t;)",d:1,g:[7,11],f:{e:q,i:"o"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:x},b:"H",a:G,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v 17 P m r (x&#t;)",d:1,g:[7,11],f:{e:q,i:"D"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:-x},b:"H",a:G,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v A 17 P k (x&#t;)",d:1,g:[7,11],f:{e:q,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:x},b:"H",a:G,h:"A"},C:{c:{e:X},b:"K",a:p}},{j:"B v F 17 P k (x&#t;)",d:1,g:[7,11],f:{e:q,i:"k"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-x},b:"H",a:G,h:"F"},C:{c:{e:X},b:"K",a:p}},{j:"B v F 17 1K P m E (x&#t;)",d:1,g:[7,11],f:{e:q,i:"o"},s:{c:{I:.O,u:1w,y:-5},b:"18",a:G,h:"F"},C:{c:{u:x,y:0},b:"18",a:G}},{j:"B v F 17 1K P m r (x&#t;)",d:1,g:[7,11],f:{e:q,i:"D"},s:{c:{I:.O,u:-1w,y:-5},b:"18",a:G,h:"F"},C:{c:{u:-x,y:0},b:"18",a:G}},{j:"1b 1t m E (l&#t;, T U)",d:1,g:1,f:{e:q,i:"o",U:"T"},s:{c:{y:l},b:"w",a:1a,h:"A"}},{j:"1b 1t m r (l&#t;, T U)",d:1,g:1,f:{e:q,i:"o",U:"T"},s:{c:{y:-l},b:"w",a:1a,h:"A"}},{j:"1b 1t m L (l&#t;, T U)",d:1,g:1,f:{e:q,i:"o",U:"T"},s:{c:{u:-l},b:"w",a:1a,h:"F"}},{j:"1b 1t m J (l&#t;, T U)",d:1,g:1,f:{e:q,i:"o",U:"T"},s:{c:{u:l},b:"w",a:1a,h:"F"}},{j:"B v S 1n m E (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"o",U:"T"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{y:l},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v S 1n m r (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"D",U:"T"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{y:-l},b:"H",a:G,h:"A"},C:{a:1g,b:"H"}},{j:"B v S 1n m L (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"1j-o",U:"T"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{u:-l},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v S 1n m J (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"1j-D",U:"T"},M:{c:{I:.O},a:1l,b:"18"},s:{c:{u:l},b:"H",a:G,h:"F"},C:{a:1g,b:"H"}},{j:"B v A S 1n k (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"k",U:"T"},M:{c:{I:.1i},a:1o,b:"18"},s:{c:{y:l},b:"H",a:1o,h:"A"},C:{a:1o,b:"H"}},{j:"B v F S 1n k (l&#t;, T U)",d:[2,4],g:[4,7],f:{e:q,i:"k",U:"T"},M:{c:{I:.1i},a:1o,b:"18"},s:{c:{u:l},b:"H",a:1o,h:"F"},C:{a:1o,b:"H"}},{j:"B v S d m E (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"o",U:"T"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:l,u:-3},b:"w",a:1p,h:"A"},C:{c:{e:X,u:0},b:"z",a:1q}},{j:"B v S d m r (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"D",U:"T"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:-l,u:-3},b:"w",a:1p,h:"A"},C:{c:{e:X,u:0},b:"z",a:1q}},{j:"B v S d m L (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"o",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"H",a:G,h:"F"},C:{c:{e:X},b:"z",a:1q}},{j:"B v S d m J (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"D",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:l},b:"H",a:G,h:"F"},C:{c:{e:X},b:"z",a:1q}},{j:"B v A S d k (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"k",U:"T"},M:{c:{I:.O,u:3},a:p,b:"K"},s:{c:{y:l,u:-3},b:"w",a:1p,h:"A"},C:{c:{e:X,u:0},b:"z",a:1q}},{j:"B v F S d k (l&#t;, T U)",d:[5,9],g:1,f:{e:1i,i:"k",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"H",a:G,h:"F"},C:{c:{e:X},b:"z",a:1q}},{j:"B v S P m L (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"o",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"w",a:1p,h:"F"},C:{c:{e:X},b:"z",a:1q}},{j:"B v S P m J (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"D",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:l},b:"w",a:1p,h:"F"},C:{c:{e:X},b:"z",a:1q}},{j:"B v S P m E (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"o",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"H",a:G,h:"A"},C:{c:{e:X},b:"z",a:1q}},{j:"B v S P m r (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"D",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:-l},b:"H",a:G,h:"A"},C:{c:{e:X},b:"z",a:1q}},{j:"B v A S P k (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"k",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{y:l},b:"H",a:G,h:"A"},C:{c:{e:X},b:"z",a:1q}},{j:"B v F S P k (l&#t;, T U)",d:1,g:[7,11],f:{e:1i,i:"k",U:"T"},M:{c:{I:.O},a:p,b:"K"},s:{c:{u:-l},b:"w",a:1p,h:"F"},C:{c:{e:X},b:"z",a:1q}}]}', 62, 132, '||||||||||duration|easing|transition|rows|delay|tile|cols|direction|sequence|name|random|180|to|type|forward|600|75|left|animation|176|rotateX|and|easeInOutQuart|90|rotateY|easeOutQuart|horizontal|Scaling|after|reverse|right|vertical|1e3|easeInOutBack|scale3d|top|easeOutBack|bottom|before|from|85|columns|mixed|tiles|spinning|large|depth|750|slide|200|sliding|Fading||||Sliding|fade|||turning|easeInOutQuint|55|1500|Spinning|Turning|100|easeInOutQuad|50|350|scale|65|col|30|450|500|cuboids|700|1200|400|rotate|35|cuboid|Carousel|Flying|45|800|Smooth|rotating|95|Horizontal|Vertical|Mirror|91|easeInQuart|1300|fading|mirror|540|drunk|out|scaling|Drunk|in|colums|150|2e3|directions|topright|bottomleft|topleft|sliging|linear|850|layerSliderTransitions|var|bottomright|87|t3d|diagonal||Crossfading|t2d'.split('|')))

// Tyepd.js | Copyright (c) 2014 Matt Boldt | www.mattboldt.com
!function($) {

    "use strict";

    var Typed = function(el, options) {

        // chosen element to manipulate text
        this.el = $(el);
        // options
        this.options = $.extend({}, $.fn.typed.defaults, options);

        // text content of element
        this.text = this.el.text();

        // typing speed
        this.typeSpeed = this.options.typeSpeed;

        // add a delay before typing starts
        this.startDelay = this.options.startDelay;

        // backspacing speed
        this.backSpeed = this.options.backSpeed;

        // amount of time to wait before backspacing
        this.backDelay = this.options.backDelay;

        // input strings of text
        this.strings = this.options.strings;

        // character number position of current string
        this.strPos = 0;

        // current array position
        this.arrayPos = 0;

        // current string based on current values[] array position
        this.string = this.strings[this.arrayPos];

        // number to stop backspacing on.
        // default 0, can change depending on how many chars
        // you want to remove at the time
        this.stopNum = 0;

        // Looping logic
        this.loop = this.options.loop;
        this.loopCount = this.options.loopCount;
        this.curLoop = 1;
        if (this.loop === false) {
            // number in which to stop going through array
            // set to strings[] array (length - 1) to stop deleting after last string is typed
            this.stopArray = this.strings.length - 1;
        } else {
            this.stopArray = this.strings.length;
        }

        // All systems go!
        this.build();
    }

    Typed.prototype = {

        constructor: Typed
        ,
        init: function() {
            // begin the loop w/ first current string (global self.string)
            // current string will be passed as an argument each time after this
            var self = this;
            setTimeout(function() {
                // Start typing
                self.typewrite(self.string, self.strPos)
            }, self.startDelay);
        }
        ,
        build: function() {
            // Insert cursor
            this.el.after("<span id=\"typed-cursor\">|</span>");
            this.init();
        }
        // pass current string state to each function
        ,
        typewrite: function(curString, curStrPos) {

            // varying values for setTimeout during typing
            // can't be global since number changes each time loop is executed
            var humanize = Math.round(Math.random() * (100 - 30)) + this.typeSpeed;
            var self = this;

            // ------------- optional ------------- //
            // backpaces a certain string faster
            // ------------------------------------ //
            // if (self.arrayPos == 1){
            // 	self.backDelay = 50;
            // }
            // else{ self.backDelay = 500; }

            // contain typing function in a timeout
            setTimeout(function() {

                // make sure array position is less than array length
                if (self.arrayPos < self.strings.length) {

                    // check for an escape character before a pause value
                    if (curString.substr(curStrPos, 1) === "^") {
                        var charPauseEnd = curString.substr(curStrPos + 1).indexOf(" ");
                        var charPause = curString.substr(curStrPos + 1, charPauseEnd);
                        // strip out the escape character and pause value so they're not printed
                        curString = curString.replace("^" + charPause, "");
                    } else {
                        var charPause = 0;
                    }

                    // timeout for any pause after a character
                    setTimeout(function() {

                        // start typing each new char into existing string
                        // curString is function arg
                        self.el.text(self.text + curString.substr(0, curStrPos));

                        // check if current character number is the string's length
                        // and if the current array position is less than the stopping point
                        // if so, backspace after backDelay setting
                        if (curStrPos > curString.length && self.arrayPos < self.stopArray) {
                            clearTimeout(clear);
                            var clear = setTimeout(function() {
                                self.backspace(curString, curStrPos);
                            }, self.backDelay);
                        }
                        // else, keep typing
                        else {
                            // add characters one by one
                            curStrPos++;
                            // loop the function
                            self.typewrite(curString, curStrPos);
                            // if the array position is at the stopping position
                            // finish code, on to next task
                            if (self.loop === false) {
                                if (self.arrayPos === self.stopArray && curStrPos === curString.length) {
                                    // animation that occurs on the last typed string
                                    // fires callback function
                                    var clear = self.options.callback();
                                    clearTimeout(clear);
                                }
                            }
                        }

                        // end of character pause
                    }, charPause);
                }// if the array position is greater than array length
                // and looping is active, reset array pos and start over.
                else if (self.loop === true && self.loopCount === false) {
                    self.arrayPos = 0;
                    self.init();
                } else if (self.loopCount !== false && self.curLoop < self.loopCount) {
                    self.arrayPos = 0;
                    self.curLoop = self.curLoop + 1;
                    self.init();
                }

                // humanized value for typing
            }, humanize);

        }
        ,
        backspace: function(curString, curStrPos) {

            // varying values for setTimeout during typing
            // can't be global since number changes each time loop is executed
            var humanize = Math.round(Math.random() * (100 - 30)) + this.backSpeed;
            var self = this;

            setTimeout(function() {

                // ----- this part is optional ----- //
                // check string array position
                // on the first string, only delete one word
                // the stopNum actually represents the amount of chars to
                // keep in the current string. In my case it's 14.
                // if (self.arrayPos == 1){
                //	self.stopNum = 14;
                // }
                //every other time, delete the whole typed string
                // else{
                //	self.stopNum = 0;
                // }

                // ----- continue important stuff ----- //
                // replace text with current text + typed characters
                self.el.text(self.text + curString.substr(0, curStrPos));

                // if the number (id of character in current string) is
                // less than the stop number, keep going
                if (curStrPos > self.stopNum) {
                    // subtract characters one by one
                    curStrPos--;
                    // loop the function
                    self.backspace(curString, curStrPos);
                }// if the stop number has been reached, increase
                // array position to next string
                else if (curStrPos <= self.stopNum) {
                    clearTimeout(clear);
                    var clear = self.arrayPos = self.arrayPos + 1;
                    // must pass new array position in this instance
                    // instead of using global arrayPos
                    self.typewrite(self.strings[self.arrayPos], curStrPos);
                }

                // humanized value for typing
            }, humanize);

        }

    }

    $.fn.typed = function(option) {
        return this.each(function() {
            var $this = $(this)
              , data = $this.data('typed')
              , options = typeof option == 'object' && option
            if (!data)
                $this.data('typed', (data = new Typed(this,options)))
            if (typeof option == 'string')
                data[option]()
        });
    }

    $.fn.typed.defaults = {
        strings: ["These are the default values...", "You know what you should do?", "Use your own!", "Have a great day!"],
        // typing speed
        typeSpeed: 0,
        // time before typing starts
        startDelay: 0,
        // backspacing speed
        backSpeed: 0,
        // time before backspacing
        backDelay: 500,
        // loop
        loop: false,
        // false = infinite
        loopCount: false,
        // ending callback function
        callback: function() {
            null
        }
    }

}(window.jQuery);

/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */
(function(r, G, f, v) {
    var J = f("html")
      , n = f(r)
      , p = f(G)
      , b = f.fancybox = function() {
        b.open.apply(this, arguments)
    }
      , I = navigator.userAgent.match(/msie/i)
      , B = null
      , s = G.createTouch !== v
      , t = function(a) {
        return a && a.hasOwnProperty && a instanceof f
    }
      , q = function(a) {
        return a && "string" === f.type(a)
    }
      , E = function(a) {
        return q(a) && 0 < a.indexOf("%")
    }
      , l = function(a, d) {
        var e = parseInt(a, 10) || 0;
        d && E(a) && (e *= b.getViewport()[d] / 100);
        return Math.ceil(e)
    }
      , w = function(a, b) {
        return l(a, b) + "px"
    };
    f.extend(b, {
        version: "2.1.5",
        defaults: {
            padding: 15,
            margin: 20,
            width: 800,
            height: 600,
            minWidth: 100,
            minHeight: 100,
            maxWidth: 9999,
            maxHeight: 9999,
            pixelRatio: 1,
            autoSize: !0,
            autoHeight: !1,
            autoWidth: !1,
            autoResize: !0,
            autoCenter: !s,
            fitToView: !0,
            aspectRatio: !1,
            topRatio: 0.5,
            leftRatio: 0.5,
            scrolling: "auto",
            wrapCSS: "",
            arrows: !0,
            closeBtn: !0,
            closeClick: !1,
            nextClick: !1,
            mouseWheel: !0,
            autoPlay: !1,
            playSpeed: 3E3,
            preload: 3,
            modal: !1,
            loop: !0,
            ajax: {
                dataType: "html",
                headers: {
                    "X-fancyBox": !0
                }
            },
            iframe: {
                scrolling: "auto",
                preload: !0
            },
            swf: {
                wmode: "transparent",
                allowfullscreen: "true",
                allowscriptaccess: "always"
            },
            keys: {
                next: {
                    13: "left",
                    34: "up",
                    39: "left",
                    40: "up"
                },
                prev: {
                    8: "right",
                    33: "down",
                    37: "right",
                    38: "down"
                },
                close: [27],
                play: [32],
                toggle: [70]
            },
            direction: {
                next: "left",
                prev: "right"
            },
            scrollOutside: !0,
            index: 0,
            type: null,
            href: null,
            content: null,
            title: null,
            tpl: {
                wrap: '<div class="fancybox-wrap" tabIndex="-1"><div class="fancybox-skin"><div class="fancybox-outer"><div class="fancybox-inner"></div></div></div></div>',
                image: '<img class="fancybox-image" src="{href}" alt="" />',
                iframe: '<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen' + (I ? ' allowtransparency="true"' : "") + "></iframe>",
                error: '<p class="fancybox-error">The requested content cannot be loaded.<br/>Please try again later.</p>',
                closeBtn: '<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>',
                next: '<a title="Next" class="fancybox-nav fancybox-next" href="javascript:;"><span></span></a>',
                prev: '<a title="Previous" class="fancybox-nav fancybox-prev" href="javascript:;"><span></span></a>'
            },
            openEffect: "fade",
            openSpeed: 250,
            openEasing: "swing",
            openOpacity: !0,
            openMethod: "zoomIn",
            closeEffect: "fade",
            closeSpeed: 250,
            closeEasing: "swing",
            closeOpacity: !0,
            closeMethod: "zoomOut",
            nextEffect: "elastic",
            nextSpeed: 250,
            nextEasing: "swing",
            nextMethod: "changeIn",
            prevEffect: "elastic",
            prevSpeed: 250,
            prevEasing: "swing",
            prevMethod: "changeOut",
            helpers: {
                overlay: !0,
                title: !0
            },
            onCancel: f.noop,
            beforeLoad: f.noop,
            afterLoad: f.noop,
            beforeShow: f.noop,
            afterShow: f.noop,
            beforeChange: f.noop,
            beforeClose: f.noop,
            afterClose: f.noop
        },
        group: {},
        opts: {},
        previous: null,
        coming: null,
        current: null,
        isActive: !1,
        isOpen: !1,
        isOpened: !1,
        wrap: null,
        skin: null,
        outer: null,
        inner: null,
        player: {
            timer: null,
            isActive: !1
        },
        ajaxLoad: null,
        imgPreload: null,
        transitions: {},
        helpers: {},
        open: function(a, d) {
            if (a && (f.isPlainObject(d) || (d = {}),
            !1 !== b.close(!0)))
                return f.isArray(a) || (a = t(a) ? f(a).get() : [a]),
                f.each(a, function(e, c) {
                    var k = {}, g, h, j, m, l;
                    "object" === f.type(c) && (c.nodeType && (c = f(c)),
                    t(c) ? (k = {
                        href: c.data("fancybox-href") || c.attr("href"),
                        title: c.data("fancybox-title") || c.attr("title"),
                        isDom: !0,
                        element: c
                    },
                    f.metadata && f.extend(!0, k, c.metadata())) : k = c);
                    g = d.href || k.href || (q(c) ? c : null);
                    h = d.title !== v ? d.title : k.title || "";
                    m = (j = d.content || k.content) ? "html" : d.type || k.type;
                    !m && k.isDom && (m = c.data("fancybox-type"),
                    m || (m = (m = c.prop("class").match(/fancybox\.(\w+)/)) ? m[1] : null));
                    q(g) && (m || (b.isImage(g) ? m = "image" : b.isSWF(g) ? m = "swf" : "#" === g.charAt(0) ? m = "inline" : q(c) && (m = "html",
                    j = c)),
                    "ajax" === m && (l = g.split(/\s+/, 2),
                    g = l.shift(),
                    l = l.shift()));
                    j || ("inline" === m ? g ? j = f(q(g) ? g.replace(/.*(?=#[^\s]+$)/, "") : g) : k.isDom && (j = c) : "html" === m ? j = g : !m && (!g && k.isDom) && (m = "inline",
                    j = c));
                    f.extend(k, {
                        href: g,
                        type: m,
                        content: j,
                        title: h,
                        selector: l
                    });
                    a[e] = k
                }),
                b.opts = f.extend(!0, {}, b.defaults, d),
                d.keys !== v && (b.opts.keys = d.keys ? f.extend({}, b.defaults.keys, d.keys) : !1),
                b.group = a,
                b._start(b.opts.index)
        },
        cancel: function() {
            var a = b.coming;
            a && !1 !== b.trigger("onCancel") && (b.hideLoading(),
            b.ajaxLoad && b.ajaxLoad.abort(),
            b.ajaxLoad = null,
            b.imgPreload && (b.imgPreload.onload = b.imgPreload.onerror = null),
            a.wrap && a.wrap.stop(!0, !0).trigger("onReset").remove(),
            b.coming = null,
            b.current || b._afterZoomOut(a))
        },
        close: function(a) {
            b.cancel();
            !1 !== b.trigger("beforeClose") && (b.unbindEvents(),
            b.isActive && (!b.isOpen || !0 === a ? (f(".fancybox-wrap").stop(!0).trigger("onReset").remove(),
            b._afterZoomOut()) : (b.isOpen = b.isOpened = !1,
            b.isClosing = !0,
            f(".fancybox-item, .fancybox-nav").remove(),
            b.wrap.stop(!0, !0).removeClass("fancybox-opened"),
            b.transitions[b.current.closeMethod]())))
        },
        play: function(a) {
            var d = function() {
                clearTimeout(b.player.timer)
            }
              , e = function() {
                d();
                b.current && b.player.isActive && (b.player.timer = setTimeout(b.next, b.current.playSpeed))
            }
              , c = function() {
                d();
                p.unbind(".player");
                b.player.isActive = !1;
                b.trigger("onPlayEnd")
            };
            if (!0 === a || !b.player.isActive && !1 !== a) {
                if (b.current && (b.current.loop || b.current.index < b.group.length - 1))
                    b.player.isActive = !0,
                    p.bind({
                        "onCancel.player beforeClose.player": c,
                        "onUpdate.player": e,
                        "beforeLoad.player": d
                    }),
                    e(),
                    b.trigger("onPlayStart")
            } else
                c()
        },
        next: function(a) {
            var d = b.current;
            d && (q(a) || (a = d.direction.next),
            b.jumpto(d.index + 1, a, "next"))
        },
        prev: function(a) {
            var d = b.current;
            d && (q(a) || (a = d.direction.prev),
            b.jumpto(d.index - 1, a, "prev"))
        },
        jumpto: function(a, d, e) {
            var c = b.current;
            c && (a = l(a),
            b.direction = d || c.direction[a >= c.index ? "next" : "prev"],
            b.router = e || "jumpto",
            c.loop && (0 > a && (a = c.group.length + a % c.group.length),
            a %= c.group.length),
            c.group[a] !== v && (b.cancel(),
            b._start(a)))
        },
        reposition: function(a, d) {
            var e = b.current, c = e ? e.wrap : null, k;
            c && (k = b._getPosition(d),
            a && "scroll" === a.type ? (delete k.position,
            c.stop(!0, !0).animate(k, 200)) : (c.css(k),
            e.pos = f.extend({}, e.dim, k)))
        },
        update: function(a) {
            var d = a && a.type
              , e = !d || "orientationchange" === d;
            e && (clearTimeout(B),
            B = null);
            b.isOpen && !B && (B = setTimeout(function() {
                var c = b.current;
                c && !b.isClosing && (b.wrap.removeClass("fancybox-tmp"),
                (e || "load" === d || "resize" === d && c.autoResize) && b._setDimension(),
                "scroll" === d && c.canShrink || b.reposition(a),
                b.trigger("onUpdate"),
                B = null)
            }, e && !s ? 0 : 300))
        },
        toggle: function(a) {
            b.isOpen && (b.current.fitToView = "boolean" === f.type(a) ? a : !b.current.fitToView,
            s && (b.wrap.removeAttr("style").addClass("fancybox-tmp"),
            b.trigger("onUpdate")),
            b.update())
        },
        hideLoading: function() {
            p.unbind(".loading");
            f("#fancybox-loading").remove()
        },
        showLoading: function() {
            var a, d;
            b.hideLoading();
            a = f('<div id="fancybox-loading"><div></div></div>').click(b.cancel).appendTo("body");
            p.bind("keydown.loading", function(a) {
                if (27 === (a.which || a.keyCode))
                    a.preventDefault(),
                    b.cancel()
            });
            b.defaults.fixed || (d = b.getViewport(),
            a.css({
                position: "absolute",
                top: 0.5 * d.h + d.y,
                left: 0.5 * d.w + d.x
            }))
        },
        getViewport: function() {
            var a = b.current && b.current.locked || !1
              , d = {
                x: n.scrollLeft(),
                y: n.scrollTop()
            };
            a ? (d.w = a[0].clientWidth,
            d.h = a[0].clientHeight) : (d.w = s && r.innerWidth ? r.innerWidth : n.width(),
            d.h = s && r.innerHeight ? r.innerHeight : n.height());
            return d
        },
        unbindEvents: function() {
            b.wrap && t(b.wrap) && b.wrap.unbind(".fb");
            p.unbind(".fb");
            n.unbind(".fb")
        },
        bindEvents: function() {
            var a = b.current, d;
            a && (n.bind("orientationchange.fb" + (s ? "" : " resize.fb") + (a.autoCenter && !a.locked ? " scroll.fb" : ""), b.update),
            (d = a.keys) && p.bind("keydown.fb", function(e) {
                var c = e.which || e.keyCode
                  , k = e.target || e.srcElement;
                if (27 === c && b.coming)
                    return !1;
                !e.ctrlKey && (!e.altKey && !e.shiftKey && !e.metaKey && (!k || !k.type && !f(k).is("[contenteditable]"))) && f.each(d, function(d, k) {
                    if (1 < a.group.length && k[c] !== v)
                        return b[d](k[c]),
                        e.preventDefault(),
                        !1;
                    if (-1 < f.inArray(c, k))
                        return b[d](),
                        e.preventDefault(),
                        !1
                })
            }),
            f.fn.mousewheel && a.mouseWheel && b.wrap.bind("mousewheel.fb", function(d, c, k, g) {
                for (var h = f(d.target || null), j = !1; h.length && !j && !h.is(".fancybox-skin") && !h.is(".fancybox-wrap"); )
                    j = h[0] && !(h[0].style.overflow && "hidden" === h[0].style.overflow) && (h[0].clientWidth && h[0].scrollWidth > h[0].clientWidth || h[0].clientHeight && h[0].scrollHeight > h[0].clientHeight),
                    h = f(h).parent();
                if (0 !== c && !j && 1 < b.group.length && !a.canShrink) {
                    if (0 < g || 0 < k)
                        b.prev(0 < g ? "down" : "left");
                    else if (0 > g || 0 > k)
                        b.next(0 > g ? "up" : "right");
                    d.preventDefault()
                }
            }))
        },
        trigger: function(a, d) {
            var e, c = d || b.coming || b.current;
            if (c) {
                f.isFunction(c[a]) && (e = c[a].apply(c, Array.prototype.slice.call(arguments, 1)));
                if (!1 === e)
                    return !1;
                c.helpers && f.each(c.helpers, function(d, e) {
                    if (e && b.helpers[d] && f.isFunction(b.helpers[d][a]))
                        b.helpers[d][a](f.extend(!0, {}, b.helpers[d].defaults, e), c)
                });
                p.trigger(a)
            }
        },
        isImage: function(a) {
            return q(a) && a.match(/(^data:image\/.*,)|(\.(jp(e|g|eg)|gif|png|bmp|webp|svg)((\?|#).*)?$)/i)
        },
        isSWF: function(a) {
            return q(a) && a.match(/\.(swf)((\?|#).*)?$/i)
        },
        _start: function(a) {
            var d = {}, e, c;
            a = l(a);
            e = b.group[a] || null;
            if (!e)
                return !1;
            d = f.extend(!0, {}, b.opts, e);
            e = d.margin;
            c = d.padding;
            "number" === f.type(e) && (d.margin = [e, e, e, e]);
            "number" === f.type(c) && (d.padding = [c, c, c, c]);
            d.modal && f.extend(!0, d, {
                closeBtn: !1,
                closeClick: !1,
                nextClick: !1,
                arrows: !1,
                mouseWheel: !1,
                keys: null,
                helpers: {
                    overlay: {
                        closeClick: !1
                    }
                }
            });
            d.autoSize && (d.autoWidth = d.autoHeight = !0);
            "auto" === d.width && (d.autoWidth = !0);
            "auto" === d.height && (d.autoHeight = !0);
            d.group = b.group;
            d.index = a;
            b.coming = d;
            if (!1 === b.trigger("beforeLoad"))
                b.coming = null;
            else {
                c = d.type;
                e = d.href;
                if (!c)
                    return b.coming = null,
                    b.current && b.router && "jumpto" !== b.router ? (b.current.index = a,
                    b[b.router](b.direction)) : !1;
                b.isActive = !0;
                if ("image" === c || "swf" === c)
                    d.autoHeight = d.autoWidth = !1,
                    d.scrolling = "visible";
                "image" === c && (d.aspectRatio = !0);
                "iframe" === c && s && (d.scrolling = "scroll");
                d.wrap = f(d.tpl.wrap).addClass("fancybox-" + (s ? "mobile" : "desktop") + " fancybox-type-" + c + " fancybox-tmp " + d.wrapCSS).appendTo(d.parent || "body");
                f.extend(d, {
                    skin: f(".fancybox-skin", d.wrap),
                    outer: f(".fancybox-outer", d.wrap),
                    inner: f(".fancybox-inner", d.wrap)
                });
                f.each(["Top", "Right", "Bottom", "Left"], function(a, b) {
                    d.skin.css("padding" + b, w(d.padding[a]))
                });
                b.trigger("onReady");
                if ("inline" === c || "html" === c) {
                    if (!d.content || !d.content.length)
                        return b._error("content")
                } else if (!e)
                    return b._error("href");
                "image" === c ? b._loadImage() : "ajax" === c ? b._loadAjax() : "iframe" === c ? b._loadIframe() : b._afterLoad()
            }
        },
        _error: function(a) {
            f.extend(b.coming, {
                type: "html",
                autoWidth: !0,
                autoHeight: !0,
                minWidth: 0,
                minHeight: 0,
                scrolling: "no",
                hasError: a,
                content: b.coming.tpl.error
            });
            b._afterLoad()
        },
        _loadImage: function() {
            var a = b.imgPreload = new Image;
            a.onload = function() {
                this.onload = this.onerror = null;
                b.coming.width = this.width / b.opts.pixelRatio;
                b.coming.height = this.height / b.opts.pixelRatio;
                b._afterLoad()
            }
            ;
            a.onerror = function() {
                this.onload = this.onerror = null;
                b._error("image")
            }
            ;
            a.src = b.coming.href;
            !0 !== a.complete && b.showLoading()
        },
        _loadAjax: function() {
            var a = b.coming;
            b.showLoading();
            b.ajaxLoad = f.ajax(f.extend({}, a.ajax, {
                url: a.href,
                error: function(a, e) {
                    b.coming && "abort" !== e ? b._error("ajax", a) : b.hideLoading()
                },
                success: function(d, e) {
                    "success" === e && (a.content = d,
                    b._afterLoad())
                }
            }))
        },
        _loadIframe: function() {
            var a = b.coming
              , d = f(a.tpl.iframe.replace(/\{rnd\}/g, (new Date).getTime())).attr("scrolling", s ? "auto" : a.iframe.scrolling).attr("src", a.href);
            f(a.wrap).bind("onReset", function() {
                try {
                    f(this).find("iframe").hide().attr("src", "//about:blank").end().empty()
                } catch (a) {}
            });
            a.iframe.preload && (b.showLoading(),
            d.one("load", function() {
                f(this).data("ready", 1);
                s || f(this).bind("load.fb", b.update);
                f(this).parents(".fancybox-wrap").width("100%").removeClass("fancybox-tmp").show();
                b._afterLoad()
            }));
            a.content = d.appendTo(a.inner);
            a.iframe.preload || b._afterLoad()
        },
        _preloadImages: function() {
            var a = b.group, d = b.current, e = a.length, c = d.preload ? Math.min(d.preload, e - 1) : 0, f, g;
            for (g = 1; g <= c; g += 1)
                f = a[(d.index + g) % e],
                "image" === f.type && f.href && ((new Image).src = f.href)
        },
        _afterLoad: function() {
            var a = b.coming, d = b.current, e, c, k, g, h;
            b.hideLoading();
            if (a && !1 !== b.isActive)
                if (!1 === b.trigger("afterLoad", a, d))
                    a.wrap.stop(!0).trigger("onReset").remove(),
                    b.coming = null;
                else {
                    d && (b.trigger("beforeChange", d),
                    d.wrap.stop(!0).removeClass("fancybox-opened").find(".fancybox-item, .fancybox-nav").remove());
                    b.unbindEvents();
                    e = a.content;
                    c = a.type;
                    k = a.scrolling;
                    f.extend(b, {
                        wrap: a.wrap,
                        skin: a.skin,
                        outer: a.outer,
                        inner: a.inner,
                        current: a,
                        previous: d
                    });
                    g = a.href;
                    switch (c) {
                    case "inline":
                    case "ajax":
                    case "html":
                        a.selector ? e = f("<div>").html(e).find(a.selector) : t(e) && (e.data("fancybox-placeholder") || e.data("fancybox-placeholder", f('<div class="fancybox-placeholder"></div>').insertAfter(e).hide()),
                        e = e.show().detach(),
                        a.wrap.bind("onReset", function() {
                            f(this).find(e).length && e.hide().replaceAll(e.data("fancybox-placeholder")).data("fancybox-placeholder", !1)
                        }));
                        break;
                    case "image":
                        e = a.tpl.image.replace("{href}", g);
                        break;
                    case "swf":
                        e = '<object id="fancybox-swf" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="100%" height="100%"><param name="movie" value="' + g + '"></param>',
                        h = "",
                        f.each(a.swf, function(a, b) {
                            e += '<param name="' + a + '" value="' + b + '"></param>';
                            h += " " + a + '="' + b + '"'
                        }),
                        e += '<embed src="' + g + '" type="application/x-shockwave-flash" width="100%" height="100%"' + h + "></embed></object>"
                    }
                    (!t(e) || !e.parent().is(a.inner)) && a.inner.append(e);
                    b.trigger("beforeShow");
                    a.inner.css("overflow", "yes" === k ? "scroll" : "no" === k ? "hidden" : k);
                    b._setDimension();
                    b.reposition();
                    b.isOpen = !1;
                    b.coming = null;
                    b.bindEvents();
                    if (b.isOpened) {
                        if (d.prevMethod)
                            b.transitions[d.prevMethod]()
                    } else
                        f(".fancybox-wrap").not(a.wrap).stop(!0).trigger("onReset").remove();
                    b.transitions[b.isOpened ? a.nextMethod : a.openMethod]();
                    b._preloadImages()
                }
        },
        _setDimension: function() {
            var a = b.getViewport(), d = 0, e = !1, c = !1, e = b.wrap, k = b.skin, g = b.inner, h = b.current, c = h.width, j = h.height, m = h.minWidth, u = h.minHeight, n = h.maxWidth, p = h.maxHeight, s = h.scrolling, q = h.scrollOutside ? h.scrollbarWidth : 0, x = h.margin, y = l(x[1] + x[3]), r = l(x[0] + x[2]), v, z, t, C, A, F, B, D, H;
            e.add(k).add(g).width("auto").height("auto").removeClass("fancybox-tmp");
            x = l(k.outerWidth(!0) - k.width());
            v = l(k.outerHeight(!0) - k.height());
            z = y + x;
            t = r + v;
            C = E(c) ? (a.w - z) * l(c) / 100 : c;
            A = E(j) ? (a.h - t) * l(j) / 100 : j;
            if ("iframe" === h.type) {
                if (H = h.content,
                h.autoHeight && 1 === H.data("ready"))
                    try {
                        H[0].contentWindow.document.location && (g.width(C).height(9999),
                        F = H.contents().find("body"),
                        q && F.css("overflow-x", "hidden"),
                        A = F.outerHeight(!0))
                    } catch (G) {}
            } else if (h.autoWidth || h.autoHeight)
                g.addClass("fancybox-tmp"),
                h.autoWidth || g.width(C),
                h.autoHeight || g.height(A),
                h.autoWidth && (C = g.width()),
                h.autoHeight && (A = g.height()),
                g.removeClass("fancybox-tmp");
            c = l(C);
            j = l(A);
            D = C / A;
            m = l(E(m) ? l(m, "w") - z : m);
            n = l(E(n) ? l(n, "w") - z : n);
            u = l(E(u) ? l(u, "h") - t : u);
            p = l(E(p) ? l(p, "h") - t : p);
            F = n;
            B = p;
            h.fitToView && (n = Math.min(a.w - z, n),
            p = Math.min(a.h - t, p));
            z = a.w - y;
            r = a.h - r;
            h.aspectRatio ? (c > n && (c = n,
            j = l(c / D)),
            j > p && (j = p,
            c = l(j * D)),
            c < m && (c = m,
            j = l(c / D)),
            j < u && (j = u,
            c = l(j * D))) : (c = Math.max(m, Math.min(c, n)),
            h.autoHeight && "iframe" !== h.type && (g.width(c),
            j = g.height()),
            j = Math.max(u, Math.min(j, p)));
            if (h.fitToView)
                if (g.width(c).height(j),
                e.width(c + x),
                a = e.width(),
                y = e.height(),
                h.aspectRatio)
                    for (; (a > z || y > r) && (c > m && j > u) && !(19 < d++); )
                        j = Math.max(u, Math.min(p, j - 10)),
                        c = l(j * D),
                        c < m && (c = m,
                        j = l(c / D)),
                        c > n && (c = n,
                        j = l(c / D)),
                        g.width(c).height(j),
                        e.width(c + x),
                        a = e.width(),
                        y = e.height();
                else
                    c = Math.max(m, Math.min(c, c - (a - z))),
                    j = Math.max(u, Math.min(j, j - (y - r)));
            q && ("auto" === s && j < A && c + x + q < z) && (c += q);
            g.width(c).height(j);
            e.width(c + x);
            a = e.width();
            y = e.height();
            e = (a > z || y > r) && c > m && j > u;
            c = h.aspectRatio ? c < F && j < B && c < C && j < A : (c < F || j < B) && (c < C || j < A);
            f.extend(h, {
                dim: {
                    width: w(a),
                    height: w(y)
                },
                origWidth: C,
                origHeight: A,
                canShrink: e,
                canExpand: c,
                wPadding: x,
                hPadding: v,
                wrapSpace: y - k.outerHeight(!0),
                skinSpace: k.height() - j
            });
            !H && (h.autoHeight && j > u && j < p && !c) && g.height("auto")
        },
        _getPosition: function(a) {
            var d = b.current
              , e = b.getViewport()
              , c = d.margin
              , f = b.wrap.width() + c[1] + c[3]
              , g = b.wrap.height() + c[0] + c[2]
              , c = {
                position: "absolute",
                top: c[0],
                left: c[3]
            };
            d.autoCenter && d.fixed && !a && g <= e.h && f <= e.w ? c.position = "fixed" : d.locked || (c.top += e.y,
            c.left += e.x);
            c.top = w(Math.max(c.top, c.top + (e.h - g) * d.topRatio));
            c.left = w(Math.max(c.left, c.left + (e.w - f) * d.leftRatio));
            return c
        },
        _afterZoomIn: function() {
            var a = b.current;
            a && (b.isOpen = b.isOpened = !0,
            b.wrap.css("overflow", "visible").addClass("fancybox-opened"),
            b.update(),
            (a.closeClick || a.nextClick && 1 < b.group.length) && b.inner.css("cursor", "pointer").bind("click.fb", function(d) {
                !f(d.target).is("a") && !f(d.target).parent().is("a") && (d.preventDefault(),
                b[a.closeClick ? "close" : "next"]())
            }),
            a.closeBtn && f(a.tpl.closeBtn).appendTo(b.skin).bind("click.fb", function(a) {
                a.preventDefault();
                b.close()
            }),
            a.arrows && 1 < b.group.length && ((a.loop || 0 < a.index) && f(a.tpl.prev).appendTo(b.outer).bind("click.fb", b.prev),
            (a.loop || a.index < b.group.length - 1) && f(a.tpl.next).appendTo(b.outer).bind("click.fb", b.next)),
            b.trigger("afterShow"),
            !a.loop && a.index === a.group.length - 1 ? b.play(!1) : b.opts.autoPlay && !b.player.isActive && (b.opts.autoPlay = !1,
            b.play()))
        },
        _afterZoomOut: function(a) {
            a = a || b.current;
            f(".fancybox-wrap").trigger("onReset").remove();
            f.extend(b, {
                group: {},
                opts: {},
                router: !1,
                current: null,
                isActive: !1,
                isOpened: !1,
                isOpen: !1,
                isClosing: !1,
                wrap: null,
                skin: null,
                outer: null,
                inner: null
            });
            b.trigger("afterClose", a)
        }
    });
    b.transitions = {
        getOrigPosition: function() {
            var a = b.current
              , d = a.element
              , e = a.orig
              , c = {}
              , f = 50
              , g = 50
              , h = a.hPadding
              , j = a.wPadding
              , m = b.getViewport();
            !e && (a.isDom && d.is(":visible")) && (e = d.find("img:first"),
            e.length || (e = d));
            t(e) ? (c = e.offset(),
            e.is("img") && (f = e.outerWidth(),
            g = e.outerHeight())) : (c.top = m.y + (m.h - g) * a.topRatio,
            c.left = m.x + (m.w - f) * a.leftRatio);
            if ("fixed" === b.wrap.css("position") || a.locked)
                c.top -= m.y,
                c.left -= m.x;
            return c = {
                top: w(c.top - h * a.topRatio),
                left: w(c.left - j * a.leftRatio),
                width: w(f + j),
                height: w(g + h)
            }
        },
        step: function(a, d) {
            var e, c, f = d.prop;
            c = b.current;
            var g = c.wrapSpace
              , h = c.skinSpace;
            if ("width" === f || "height" === f)
                e = d.end === d.start ? 1 : (a - d.start) / (d.end - d.start),
                b.isClosing && (e = 1 - e),
                c = "width" === f ? c.wPadding : c.hPadding,
                c = a - c,
                b.skin[f](l("width" === f ? c : c - g * e)),
                b.inner[f](l("width" === f ? c : c - g * e - h * e))
        },
        zoomIn: function() {
            var a = b.current
              , d = a.pos
              , e = a.openEffect
              , c = "elastic" === e
              , k = f.extend({
                opacity: 1
            }, d);
            delete k.position;
            c ? (d = this.getOrigPosition(),
            a.openOpacity && (d.opacity = 0.1)) : "fade" === e && (d.opacity = 0.1);
            b.wrap.css(d).animate(k, {
                duration: "none" === e ? 0 : a.openSpeed,
                easing: a.openEasing,
                step: c ? this.step : null,
                complete: b._afterZoomIn
            })
        },
        zoomOut: function() {
            var a = b.current
              , d = a.closeEffect
              , e = "elastic" === d
              , c = {
                opacity: 0.1
            };
            e && (c = this.getOrigPosition(),
            a.closeOpacity && (c.opacity = 0.1));
            b.wrap.animate(c, {
                duration: "none" === d ? 0 : a.closeSpeed,
                easing: a.closeEasing,
                step: e ? this.step : null,
                complete: b._afterZoomOut
            })
        },
        changeIn: function() {
            var a = b.current, d = a.nextEffect, e = a.pos, c = {
                opacity: 1
            }, f = b.direction, g;
            e.opacity = 0.1;
            "elastic" === d && (g = "down" === f || "up" === f ? "top" : "left",
            "down" === f || "right" === f ? (e[g] = w(l(e[g]) - 200),
            c[g] = "+=200px") : (e[g] = w(l(e[g]) + 200),
            c[g] = "-=200px"));
            "none" === d ? b._afterZoomIn() : b.wrap.css(e).animate(c, {
                duration: a.nextSpeed,
                easing: a.nextEasing,
                complete: b._afterZoomIn
            })
        },
        changeOut: function() {
            var a = b.previous
              , d = a.prevEffect
              , e = {
                opacity: 0.1
            }
              , c = b.direction;
            "elastic" === d && (e["down" === c || "up" === c ? "top" : "left"] = ("up" === c || "left" === c ? "-" : "+") + "=200px");
            a.wrap.animate(e, {
                duration: "none" === d ? 0 : a.prevSpeed,
                easing: a.prevEasing,
                complete: function() {
                    f(this).trigger("onReset").remove()
                }
            })
        }
    };
    b.helpers.overlay = {
        defaults: {
            closeClick: !0,
            speedOut: 200,
            showEarly: !0,
            css: {},
            locked: !s,
            fixed: !0
        },
        overlay: null,
        fixed: !1,
        el: f("html"),
        create: function(a) {
            a = f.extend({}, this.defaults, a);
            this.overlay && this.close();
            this.overlay = f('<div class="fancybox-overlay"></div>').appendTo(b.coming ? b.coming.parent : a.parent);
            this.fixed = !1;
            a.fixed && b.defaults.fixed && (this.overlay.addClass("fancybox-overlay-fixed"),
            this.fixed = !0)
        },
        open: function(a) {
            var d = this;
            a = f.extend({}, this.defaults, a);
            this.overlay ? this.overlay.unbind(".overlay").width("auto").height("auto") : this.create(a);
            this.fixed || (n.bind("resize.overlay", f.proxy(this.update, this)),
            this.update());
            a.closeClick && this.overlay.bind("click.overlay", function(a) {
                if (f(a.target).hasClass("fancybox-overlay"))
                    return b.isActive ? b.close() : d.close(),
                    !1
            });
            this.overlay.css(a.css).show()
        },
        close: function() {
            var a, b;
            n.unbind("resize.overlay");
            this.el.hasClass("fancybox-lock") && (f(".fancybox-margin").removeClass("fancybox-margin"),
            a = n.scrollTop(),
            b = n.scrollLeft(),
            this.el.removeClass("fancybox-lock"),
            n.scrollTop(a).scrollLeft(b));
            f(".fancybox-overlay").remove().hide();
            f.extend(this, {
                overlay: null,
                fixed: !1
            })
        },
        update: function() {
            var a = "100%", b;
            this.overlay.width(a).height("100%");
            I ? (b = Math.max(G.documentElement.offsetWidth, G.body.offsetWidth),
            p.width() > b && (a = p.width())) : p.width() > n.width() && (a = p.width());
            this.overlay.width(a).height(p.height())
        },
        onReady: function(a, b) {
            var e = this.overlay;
            f(".fancybox-overlay").stop(!0, !0);
            e || this.create(a);
            a.locked && (this.fixed && b.fixed) && (e || (this.margin = p.height() > n.height() ? f("html").css("margin-right").replace("px", "") : !1),
            b.locked = this.overlay.append(b.wrap),
            b.fixed = !1);
            !0 === a.showEarly && this.beforeShow.apply(this, arguments)
        },
        beforeShow: function(a, b) {
            var e, c;
            b.locked && (!1 !== this.margin && (f("*").filter(function() {
                return "fixed" === f(this).css("position") && !f(this).hasClass("fancybox-overlay") && !f(this).hasClass("fancybox-wrap")
            }).addClass("fancybox-margin"),
            this.el.addClass("fancybox-margin")),
            e = n.scrollTop(),
            c = n.scrollLeft(),
            this.el.addClass("fancybox-lock"),
            n.scrollTop(e).scrollLeft(c));
            this.open(a)
        },
        onUpdate: function() {
            this.fixed || this.update()
        },
        afterClose: function(a) {
            this.overlay && !b.coming && this.overlay.fadeOut(a.speedOut, f.proxy(this.close, this))
        }
    };
    b.helpers.title = {
        defaults: {
            type: "float",
            position: "bottom"
        },
        beforeShow: function(a) {
            var d = b.current
              , e = d.title
              , c = a.type;
            f.isFunction(e) && (e = e.call(d.element, d));
            if (q(e) && "" !== f.trim(e)) {
                d = f('<div class="fancybox-title fancybox-title-' + c + '-wrap">' + e + "</div>");
                switch (c) {
                case "inside":
                    c = b.skin;
                    break;
                case "outside":
                    c = b.wrap;
                    break;
                case "over":
                    c = b.inner;
                    break;
                default:
                    c = b.skin,
                    d.appendTo("body"),
                    I && d.width(d.width()),
                    d.wrapInner('<span class="child"></span>'),
                    b.current.margin[2] += Math.abs(l(d.css("margin-bottom")))
                }
                d["top" === a.position ? "prependTo" : "appendTo"](c)
            }
        }
    };
    f.fn.fancybox = function(a) {
        var d, e = f(this), c = this.selector || "", k = function(g) {
            var h = f(this).blur(), j = d, k, l;
            !g.ctrlKey && (!g.altKey && !g.shiftKey && !g.metaKey) && !h.is(".fancybox-wrap") && (k = a.groupAttr || "data-fancybox-group",
            l = h.attr(k),
            l || (k = "rel",
            l = h.get(0)[k]),
            l && ("" !== l && "nofollow" !== l) && (h = c.length ? f(c) : e,
            h = h.filter("[" + k + '="' + l + '"]'),
            j = h.index(this)),
            a.index = j,
            !1 !== b.open(h, a) && g.preventDefault())
        };
        a = a || {};
        d = a.index || 0;
        !c || !1 === a.live ? e.unbind("click.fb-start").bind("click.fb-start", k) : p.undelegate(c, "click.fb-start").delegate(c + ":not('.fancybox-item, .fancybox-nav')", "click.fb-start", k);
        this.filter("[data-fancybox-start=1]").trigger("click");
        return this
    }
    ;
    p.ready(function() {
        var a, d;
        f.scrollbarWidth === v && (f.scrollbarWidth = function() {
            var a = f('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo("body")
              , b = a.children()
              , b = b.innerWidth() - b.height(99).innerWidth();
            a.remove();
            return b
        }
        );
        if (f.support.fixedPosition === v) {
            a = f.support;
            d = f('<div style="position:fixed;top:20px;"></div>').appendTo("body");
            var e = 20 === d[0].offsetTop || 15 === d[0].offsetTop;
            d.remove();
            a.fixedPosition = e
        }
        f.extend(b.defaults, {
            scrollbarWidth: f.scrollbarWidth(),
            fixed: f.support.fixedPosition,
            parent: f("body")
        });
        a = f(r).width();
        J.addClass("fancybox-lock-test");
        d = f(r).width();
        J.removeClass("fancybox-lock-test");
        f("<style type='text/css'>.fancybox-margin{margin-right:" + (d - a) + "px;}</style>").appendTo("head")
    })
}
)(window, document, jQuery);

/*!
 * Buttons helper for fancyBox
 * version: 1.0.5 (Mon, 15 Oct 2012)
 * @requires fancyBox v2.0 or later
 *
 * Usage:
 *     $(".fancybox").fancybox({
 *         helpers : {
 *             buttons: {
 *                 position : 'top'
 *             }
 *         }
 *     });
 *
 */
(function($) {
    //Shortcut for fancyBox object
    var F = $.fancybox;

    //Add helper object
    F.helpers.buttons = {
        defaults: {
            skipSingle: false,
            // disables if gallery contains single image
            position: 'top',
            // 'top' or 'bottom'
            tpl: '<div id="fancybox-buttons"><ul><li><a class="btnPrev" title="Previous" href="javascript:;"></a></li><li><a class="btnPlay" title="Start slideshow" href="javascript:;"></a></li><li><a class="btnNext" title="Next" href="javascript:;"></a></li><li><a class="btnToggle" title="Toggle size" href="javascript:;"></a></li><li><a class="btnClose" title="Close" href="javascript:;"></a></li></ul></div>'
        },

        list: null,
        buttons: null,

        beforeLoad: function(opts, obj) {
            //Remove self if gallery do not have at least two items

            if (opts.skipSingle && obj.group.length < 2) {
                obj.helpers.buttons = false;
                obj.closeBtn = true;

                return;
            }

            //Increase top margin to give space for buttons
            obj.margin[opts.position === 'bottom' ? 2 : 0] += 30;
        },

        onPlayStart: function() {
            if (this.buttons) {
                this.buttons.play.attr('title', 'Pause slideshow').addClass('btnPlayOn');
            }
        },

        onPlayEnd: function() {
            if (this.buttons) {
                this.buttons.play.attr('title', 'Start slideshow').removeClass('btnPlayOn');
            }
        },

        afterShow: function(opts, obj) {
            var buttons = this.buttons;

            if (!buttons) {
                this.list = $(opts.tpl).addClass(opts.position).appendTo('body');

                buttons = {
                    prev: this.list.find('.btnPrev').click(F.prev),
                    next: this.list.find('.btnNext').click(F.next),
                    play: this.list.find('.btnPlay').click(F.play),
                    toggle: this.list.find('.btnToggle').click(F.toggle),
                    close: this.list.find('.btnClose').click(F.close)
                }
            }

            //Prev
            if (obj.index > 0 || obj.loop) {
                buttons.prev.removeClass('btnDisabled');
            } else {
                buttons.prev.addClass('btnDisabled');
            }

            //Next / Play
            if (obj.loop || obj.index < obj.group.length - 1) {
                buttons.next.removeClass('btnDisabled');
                buttons.play.removeClass('btnDisabled');

            } else {
                buttons.next.addClass('btnDisabled');
                buttons.play.addClass('btnDisabled');
            }

            this.buttons = buttons;

            this.onUpdate(opts, obj);
        },

        onUpdate: function(opts, obj) {
            var toggle;

            if (!this.buttons) {
                return;
            }

            toggle = this.buttons.toggle.removeClass('btnDisabled btnToggleOn');

            //Size toggle button
            if (obj.canShrink) {
                toggle.addClass('btnToggleOn');

            } else if (!obj.canExpand) {
                toggle.addClass('btnDisabled');
            }
        },

        beforeClose: function() {
            if (this.list) {
                this.list.remove();
            }

            this.list = null;
            this.buttons = null;
        }
    };

}(jQuery));
